import { createClient as createSupabaseClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

  const XLSX_CDN_URL = 'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js';
  let xlsxLoadPromise = null;
  async function ensureXlsxReady() {
    if (window.XLSX) return window.XLSX;
    if (!xlsxLoadPromise) {
      xlsxLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = XLSX_CDN_URL;
        script.async = true;
        script.onload = () => window.XLSX ? resolve(window.XLSX) : reject(new Error('Library Excel gagal dimuat'));
        script.onerror = () => reject(new Error('Library Excel gagal dimuat. Cek koneksi internet.'));
        document.head.appendChild(script);
      });
    }
    return xlsxLoadPromise;
  }

  // === SUPABASE MIGRATION CONFIG ===
  // Jangan pernah taruh service_role / sb_secret di frontend. Browser cukup pakai anon public key.
  const SUPABASE_URL = 'https://ismjupxoiywttkrekmfg.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzbWp1cHhvaXl3dHRrcmVrbWZnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyNzc4MDEsImV4cCI6MjA5NDg1MzgwMX0.WVwqEdkPQ_x9NWR8QXTm85mIAvN8d9V2FaMJ2NiAMC0';
  const supabaseConfig = { projectId: 'ismjupxoiywttkrekmfg' };
  const supabase = createSupabaseClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  const db = { type: 'supabase', client: supabase };
  const app = db; // kompatibilitas untuk fungsi notifikasi lama.
  const firebaseConfig = supabaseConfig; // alias lama agar logika backup/UI tidak perlu diubah.

  // === FIRESTORE COMPAT LAYER DI ATAS SUPABASE ===
  // Tujuannya menjaga logika aplikasi tetap sama: doc(), collection(), query(), where(), limit(), orderBy(),
  // getDoc(), getDocs(), setDoc(), addDoc(), deleteDoc(), onSnapshot(), serverTimestamp(), Timestamp.fromMillis().
  const SUPABASE_TABLES = ['users','attendance','transactions','closings','manualBonuses','staff_leave_requests','dailyTargets','targetBonusRewards','targetNotifications','targetSettings','audit_logs','adminDeviceTokens'];
  const SUPABASE_FALLBACK_POLL_MS = 2 * 60 * 1000;
  const SUPABASE_REALTIME_DEBOUNCE_MS = 450;
  const SERVER_TIMESTAMP_SENTINEL = { __supabaseServerTimestamp: true };
  const Timestamp = {
    fromMillis(ms){
      return {
        seconds: Math.floor(Number(ms || 0) / 1000),
        nanoseconds: (Number(ms || 0) % 1000) * 1000000,
        toDate(){ return new Date(Number(ms || 0)); },
        toMillis(){ return Number(ms || 0); }
      };
    }
  };
  const serverTimestamp = () => SERVER_TIMESTAMP_SENTINEL;
  const doc = (_db, collectionName, id) => ({ kind: 'doc', collectionName, id: String(id || '') });
  const collection = (_db, collectionName) => ({ kind: 'collection', collectionName });
  const where = (field, op, value) => ({ kind: 'where', field, op, value });
  const orderBy = (field, direction = 'asc') => ({ kind: 'orderBy', field, direction });
  const limit = (count) => ({ kind: 'limit', count: Number(count || 0) });
  const query = (base, ...constraints) => ({ kind: 'query', collectionName: base.collectionName, constraints });

  function makeId(prefix = '') {
    return `${prefix}${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
  }
  function deepCloneCompat(value) {
    if (value === null || value === undefined) return value;
    if (value === SERVER_TIMESTAMP_SENTINEL || value?.__supabaseServerTimestamp) return new Date().toISOString();
    if (value instanceof Date) return value.toISOString();
    if (Array.isArray(value)) return value.map(deepCloneCompat);
    if (typeof value === 'object') {
      if (typeof value.toDate === 'function') return value.toDate().toISOString();
      const out = {};
      Object.entries(value).forEach(([k, v]) => { if (v !== undefined) out[k] = deepCloneCompat(v); });
      return out;
    }
    return value;
  }
  function normalizeRow(row) {
    const data = row?.data && typeof row.data === 'object' ? row.data : {};
    return { id: row?.id, ...data };
  }
  function docSnapshot(id, data) {
    return { id, exists: () => !!data, data: () => data ? { ...data } : undefined };
  }
  function querySnapshot(rows, changes = null) {
    const docs = rows.map((row) => ({ id: row.id, data: () => ({ ...row }) }));
    const docChanges = changes || docs.map((doc) => ({ type: 'added', doc }));
    return { docs, size: docs.length, empty: docs.length === 0, forEach(cb){ docs.forEach(cb); }, docChanges(){ return docChanges; } };
  }
  function querySnapshotFromDocs(docs, changes = []) {
    return {
      docs,
      size: docs.length,
      empty: docs.length === 0,
      forEach(cb){ docs.forEach(cb); },
      docChanges(){ return changes; }
    };
  }
  function getDocComparableData(docSnap) {
    try { return docSnap?.data ? docSnap.data() : {}; }
    catch (_) { return {}; }
  }
  function buildSnapshotChanges(previousDocsById, docs) {
    if (!previousDocsById) return [];
    const nextIds = new Set(docs.map((doc) => String(doc.id)));
    const changes = [];
    docs.forEach((doc) => {
      const id = String(doc.id);
      const currentData = getDocComparableData(doc);
      const previous = previousDocsById.get(id);
      if (!previous) {
        changes.push({ type: 'added', doc });
      } else if (JSON.stringify(previous) !== JSON.stringify(currentData)) {
        changes.push({ type: 'modified', doc });
      }
    });
    previousDocsById.forEach((data, id) => {
      if (nextIds.has(id)) return;
      changes.push({ type: 'removed', doc: { id, data: () => ({ ...data }) } });
    });
    return changes;
  }
  function getFieldValue(row, field) {
    return field.split('.').reduce((acc, key) => acc == null ? undefined : acc[key], row);
  }
  function normalizeComparable(value) {
    if (value === null || value === undefined) return value;
    if (typeof value === 'number') return Number.isFinite(value) ? value : String(value);
    const text = String(value);
    const trimmed = text.trim();
    if (trimmed !== '' && Number.isFinite(Number(trimmed))) return Number(trimmed);
    return text;
  }
  function compareWhere(row, c) {
    const rawA = getFieldValue(row, c.field);
    if (c.op === 'in') return Array.isArray(c.value) && c.value.map(String).includes(String(rawA));
    const a = normalizeComparable(rawA);
    const b = normalizeComparable(c.value);
    if (c.op === '==') return String(a) === String(b);
    if (c.op === '!=') return String(a) !== String(b);
    if (c.op === '>=') return a >= b;
    if (c.op === '<=') return a <= b;
    if (c.op === '>') return a > b;
    if (c.op === '<') return a < b;
    return true;
  }
  function snapshotIds(snap) {
    try {
      if (snap && Array.isArray(snap.docs)) return new Set(snap.docs.map((doc) => String(doc.id)));
      return snap?.id ? new Set([String(snap.id)]) : new Set();
    } catch (_) {
      return new Set();
    }
  }
  function rowMatchesQuery(row, refOrQuery) {
    if (!row) return false;
    if (refOrQuery.kind === 'doc') return String(row.id || '') === String(refOrQuery.id || '');
    const constraints = refOrQuery.constraints || [];
    return constraints.filter((c) => c.kind === 'where').every((c) => compareWhere(row, c));
  }
  function realtimePayloadRow(payload) {
    const raw = (payload?.new && Object.keys(payload.new).length) ? payload.new : payload?.old;
    return raw ? normalizeRow(raw) : null;
  }
  function realtimeChannelName(refOrQuery) {
    const table = String(refOrQuery.collectionName || 'data').replace(/[^a-zA-Z0-9_]/g, '_');
    const scope = refOrQuery.kind === 'doc' ? String(refOrQuery.id || 'doc') : Math.random().toString(36).slice(2, 10);
    return `server_${table}_${scope.replace(/[^a-zA-Z0-9_]/g, '_')}_${Date.now().toString(36)}`;
  }
  function realtimeFilter(refOrQuery) {
    if (refOrQuery.kind !== 'doc') return null;
    const id = String(refOrQuery.id || '');
    return id ? `id=eq.${id.replace(/[,()]/g, '')}` : null;
  }
  function isRealtimePayloadRelevant(refOrQuery, payload, lastIds) {
    const row = realtimePayloadRow(payload);
    if (!row) return true;
    if (refOrQuery.kind === 'doc') return String(row.id || '') === String(refOrQuery.id || '');
    if (lastIds && lastIds.has(String(row.id || ''))) return true;
    return rowMatchesQuery(row, refOrQuery);
  }
  function applySupabaseWhereFilters(req, constraints) {
    let applied = 0;
    let total = 0;
    let canServerFilter = true;
    for (const c of constraints.filter((item) => item.kind === 'where')) {
      total++;
      if (!/^[a-zA-Z0-9_]+$/.test(c.field || '')) {
        canServerFilter = false;
        continue;
      }
      const fieldPath = c.field === 'id' ? 'id' : `data->>${c.field}`;
      if (c.op === '==') {
        req = req.eq(fieldPath, String(c.value));
        applied++;
      } else if (c.op === '!=') {
        req = req.neq(fieldPath, String(c.value));
        applied++;
      } else if (c.op === '>=') {
        req = req.gte(fieldPath, String(c.value));
        applied++;
      } else if (c.op === '<=') {
        req = req.lte(fieldPath, String(c.value));
        applied++;
      } else if (c.op === '>') {
        req = req.gt(fieldPath, String(c.value));
        applied++;
      } else if (c.op === '<') {
        req = req.lt(fieldPath, String(c.value));
        applied++;
      } else if (c.op === 'in' && Array.isArray(c.value) && c.value.length) {
        const values = c.value.map((value) => String(value));
        req = req.in(fieldPath, values);
        applied++;
      } else {
        canServerFilter = false;
      }
    }
    return { req, applied, total, canServerFilter: total > 0 && canServerFilter && applied === total };
  }
  async function getDoc(ref) {
    const { data, error } = await supabase.from(ref.collectionName).select('id,data').eq('id', ref.id).maybeSingle();
    if (error) throw error;
    return docSnapshot(ref.id, data ? normalizeRow(data) : null);
  }
  const getDocFromServer = getDoc;
  async function getDocs(qy) {
    const collectionName = qy.collectionName;
    const constraints = qy.constraints || [];
    const hardLimit = constraints.find((c) => c.kind === 'limit')?.count || 1000;
    const filteredReq = applySupabaseWhereFilters(supabase.from(collectionName).select('id,data'), constraints);
    const fetchLimit = filteredReq.canServerFilter ? hardLimit : Math.min(Math.max(hardLimit * 3, hardLimit), 5000);
    const { data, error } = await filteredReq.req.limit(fetchLimit);
    if (error) throw error;
    let rows = (data || []).map(normalizeRow);
    constraints.filter((c) => c.kind === 'where').forEach((c) => { rows = rows.filter((row) => compareWhere(row, c)); });
    const ord = constraints.find((c) => c.kind === 'orderBy');
    if (ord) {
      rows.sort((x, y) => {
        const a = getFieldValue(x, ord.field);
        const b = getFieldValue(y, ord.field);
        const cmp = String(a ?? '').localeCompare(String(b ?? ''), undefined, { numeric: true });
        return ord.direction === 'desc' ? -cmp : cmp;
      });
    }
    return querySnapshot(rows.slice(0, hardLimit));
  }
  const getDocsFromServer = getDocs;
  async function setDoc(ref, payload, options = {}) {
    const nextData = deepCloneCompat(payload || {});
    let finalData = nextData;
    if (options?.merge) {
      const oldSnap = await getDoc(ref).catch(() => docSnapshot(ref.id, null));
      finalData = { ...(oldSnap.exists() ? oldSnap.data() : {}), ...nextData };
      delete finalData.id;
    }
    const { error } = await supabase.from(ref.collectionName).upsert({ id: ref.id, data: finalData }, { onConflict: 'id' });
    if (error) throw error;
    syncLocalCacheAfterWrite(ref.collectionName, ref.id, finalData);
    return ref;
  }
  async function bulkUpsertCompat(collectionName, entries, chunkSize = 200, label = '') {
    const cleanEntries = (entries || [])
      .filter((item) => item && item.id)
      .map((item) => ({
        id: String(item.id),
        data: deepCloneCompat(item.data || {})
      }));
    for (let i = 0; i < cleanEntries.length; i += chunkSize) {
      const chunk = cleanEntries.slice(i, i + chunkSize);
      const { error } = await supabase.from(collectionName).upsert(chunk, { onConflict: 'id' });
      if (error) throw error;
      if (label) showToast(`Restore ${label}: ${Math.min(i + chunk.length, cleanEntries.length)}/${cleanEntries.length}`);
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    return cleanEntries.length;
  }

  async function bulkUpsertIfPresent(collectionName, entries, chunkSize = 200, label = '') {
    try {
      return await bulkUpsertCompat(collectionName, entries, chunkSize, label);
    } catch (e) {
      if (isMissingSupabaseTableError(e)) {
        console.warn(`Tabel ${collectionName} belum ada, restore ${label || collectionName} dilewati`);
        return 0;
      }
      throw e;
    }
  }

  async function fastDeleteCollectionCompat(collectionName, options = {}) {
    const keepIds = Array.isArray(options.keepIds) ? options.keepIds.map(String).filter(Boolean) : [];
    let req = supabase.from(collectionName).delete({ count: 'exact' });
    if (keepIds.length) {
      keepIds.forEach((id) => { req = req.neq('id', id); });
    } else {
      // Supabase REST delete wajib punya filter; id primary key tidak mungkin null.
      req = req.not('id', 'is', null);
    }
    const { count, error } = await req;
    if (error) throw error;
    return Number(count || 0);
  }

  function stopRealtimeData() {
    if (unsubTransactions) { unsubTransactions(); unsubTransactions = null; }
    if (unsubAttendance) { unsubAttendance(); unsubAttendance = null; }
    if (unsubUsers) { unsubUsers(); unsubUsers = null; }
    if (unsubAuditLogs) { unsubAuditLogs(); unsubAuditLogs = null; }
    if (unsubClosings) { unsubClosings(); unsubClosings = null; }
    if (unsubBonusSettings) { unsubBonusSettings(); unsubBonusSettings = null; }
    if (unsubManualBonuses) { unsubManualBonuses(); unsubManualBonuses = null; }
    if (unsubUnlockRequests) { unsubUnlockRequests(); unsubUnlockRequests = null; }
    if (unsubRismaManualClosing) { unsubRismaManualClosing(); unsubRismaManualClosing = null; }
    if (unsubHeaderGuideNote) { unsubHeaderGuideNote(); unsubHeaderGuideNote = null; }
    if (unsubReceiptTextSettings) { unsubReceiptTextSettings(); unsubReceiptTextSettings = null; }
  }

  async function addDoc(colRef, payload) {
    const ref = doc(db, colRef.collectionName, makeId());
    await setDoc(ref, payload || {});
    return ref;
  }
  async function deleteDoc(ref) {
    const { error } = await supabase.from(ref.collectionName).delete().eq('id', ref.id);
    if (error) throw error;
    syncLocalCacheAfterDelete(ref.collectionName, ref.id);
  }

  function syncLocalCacheAfterWrite(collectionName, id, data = {}) {
    try {
      const rec = { id: String(id || ''), ...(data || {}) };
      if (!rec.id) return;
      if (collectionName === 'transactions') {
        cachedTransactions = sortByCreatedDesc([rec, ...(cachedTransactions || []).filter(t => String(t.id) !== rec.id)]);
      } else if (collectionName === 'attendance') {
        upsertAttendanceRecord(rec);
      } else if (collectionName === 'manualBonuses') {
        upsertManualBonusRecord(rec);
      } else if (collectionName === STAFF_UNLOCK_TABLE) {
        cachedUnlockRequests = sortByCreatedDesc([rec, ...(cachedUnlockRequests || []).filter(r => String(r.id) !== rec.id)]);
      } else if (collectionName === 'users') {
        upsertCachedUserFromServer(rec.id, rec);
      } else if (collectionName === 'audit_logs') {
        cachedAuditLogs = sortByCreatedDesc([rec, ...(cachedAuditLogs || []).filter(l => String(l.id) !== rec.id)]).slice(0, AUDIT_SYNC_LIMIT);
      } else if (collectionName === 'closings') {
        if (rec.id === '__bonus_settings') cachedBonusSettings = normalizeBonusSettings(rec);
        else if (rec.id === HEADER_GUIDE_NOTE_DOC_ID || rec.type === 'header_guide_note') cachedHeaderGuideNote = { id: rec.id, note: DEFAULT_HEADER_GUIDE_NOTE, ...rec };
        else if (rec.id === RECEIPT_TEXT_DOC_ID || rec.type === 'receipt_text_settings') cachedReceiptTextSettings = normalizeReceiptTextSettings({ id: rec.id, ...rec });
        else if (rec.id === RISMA_MANUAL_CLOSING_DOC_ID) cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {}, ...rec };
        else if (isClosingDataRecord(rec)) cachedClosings = sortByCreatedDesc([rec, ...(cachedClosings || []).filter(c => String(c.id) !== rec.id)]);
      }
    } catch (e) {
      console.warn('Update cache lokal gagal:', e?.message || e);
    }
  }

  function syncLocalCacheAfterDelete(collectionName, id) {
    try {
      const safeId = String(id || '');
      if (!safeId) return;
      if (collectionName === 'transactions') cachedTransactions = (cachedTransactions || []).filter(t => String(t.id) !== safeId);
      else if (collectionName === 'attendance') cachedAttendance = (cachedAttendance || []).filter(a => String(a.id) !== safeId);
      else if (collectionName === 'manualBonuses') cachedManualBonuses = (cachedManualBonuses || []).filter(b => String(b.id) !== safeId);
      else if (collectionName === STAFF_UNLOCK_TABLE) cachedUnlockRequests = (cachedUnlockRequests || []).filter(r => String(r.id) !== safeId);
      else if (collectionName === 'users') cachedUsers = (cachedUsers || []).filter(u => sanitizeUsername(u.username || u.id) !== sanitizeUsername(safeId));
      else if (collectionName === 'closings') cachedClosings = (cachedClosings || []).filter(c => String(c.id) !== safeId);
      else if (collectionName === 'audit_logs') cachedAuditLogs = (cachedAuditLogs || []).filter(l => String(l.id) !== safeId);
    } catch (e) {
      console.warn('Hapus cache lokal gagal:', e?.message || e);
    }
  }
  function onSnapshot(refOrQuery, next, errorCb) {
    let stopped = false;
    let previousDocsById = null;
    let previousDocState = null;
    let lastIds = new Set();
    let realtimeChannel = null;
    let queuedTimer = 0;
    const run = async ({ force = false } = {}) => {
      try {
        const snap = refOrQuery.kind === 'doc' ? await getDoc(refOrQuery) : await getDocs(refOrQuery);
        if (stopped) return;
        lastIds = snapshotIds(snap);
        if (refOrQuery.kind === 'doc') {
          const currentDocState = JSON.stringify({
            exists: snap.exists(),
            data: snap.exists() ? snap.data() : null
          });
          if (!force && previousDocState === currentDocState) return;
          previousDocState = currentDocState;
          next(snap);
          return;
        }
        const docs = snap.docs || [];
        const changes = buildSnapshotChanges(previousDocsById, docs);
        if (!force && previousDocsById && changes.length === 0) return;
        previousDocsById = new Map(docs.map((doc) => [String(doc.id), getDocComparableData(doc)]));
        next(querySnapshotFromDocs(docs, changes));
      } catch (e) {
        console.warn('Supabase snapshot error:', e.message || e);
        if (!stopped && errorCb) errorCb(e);
      }
    };
    const queueRun = () => {
      if (stopped) return;
      clearTimeout(queuedTimer);
      queuedTimer = setTimeout(() => run(), SUPABASE_REALTIME_DEBOUNCE_MS);
    };
    run({ force: true });
    try {
      const table = String(refOrQuery.collectionName || '');
      if (table && supabase?.channel) {
        const config = { event: '*', schema: 'public', table };
        const filter = realtimeFilter(refOrQuery);
        if (filter) config.filter = filter;
        realtimeChannel = supabase
          .channel(realtimeChannelName(refOrQuery))
          .on('postgres_changes', config, (payload) => {
            if (isRealtimePayloadRelevant(refOrQuery, payload, lastIds)) queueRun();
          })
          .subscribe((status) => {
            if (!stopped && (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT')) {
              console.warn('Supabase realtime fallback:', table, status);
            }
          });
      }
    } catch (e) {
      console.warn('Supabase realtime init skipped:', e?.message || e);
    }
    const timer = setInterval(run, SUPABASE_FALLBACK_POLL_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
      clearTimeout(queuedTimer);
      if (realtimeChannel) {
        try { supabase.removeChannel(realtimeChannel).catch(() => {}); } catch (_) {}
      }
    };
  }
  async function enableIndexedDbPersistence(){ console.log('Supabase mode: offline persistence Firebase dilewati.'); }
  async function isMessagingSupported(){ return false; }
  function getMessaging(){ return null; }
  async function getToken(){ return ''; }
  function onMessage(){ return () => {}; }

  // Sumber data Cash Fisik Hari Ini mengikuti aplikasi Risma Finance / catatan.html.
  // Omzet kasir diambil dari Supabase admin, sedangkan Ops Toko + QRIS + Tabungan
  // diambil dari tabel Supabase `transactions` owner `rocky-hijab`.
  const CASH_FISIK_SUPABASE_URL = 'https://myxrvipyodadnldtomzs.supabase.co';
  const CASH_FISIK_SUPABASE_ANON_KEY = 'sb_publishable_aG-kyasJNCEk2U9fN5T4qg_GfY0FpPH';
  const CASH_FISIK_OWNER_ID = 'rocky-hijab';
  const CASHOUT_PREFIX = '[CASHOUT:';
  const OPS_PREFIX = '[OPS] ';
  const CASH_DRAWER_TABLE = 'cash_drawer_audits';
  const CASH_DRAWER_ADJ_PREFIX = '[SELISIH_LACI:';
  const CASH_DRAWER_MINUS_CATEGORY_NAME = 'Selisih Kas Minus';
  const CASH_DRAWER_PLUS_CATEGORY_NAME = 'Selisih Kas Lebih';
  const cashFisikSupabase = createSupabaseClient(CASH_FISIK_SUPABASE_URL, CASH_FISIK_SUPABASE_ANON_KEY);
  let cachedFinanceCashRows = [];
  let cachedFinanceCashDateKey = '';
  let cachedFinanceCashFetchedAt = 0;
  let cachedFinanceCashAuditRows = [];
  let cachedFinanceCashAuditDateKey = '';
  let cachedFinanceCashAuditFetchedAt = 0;

  const TRANSACTION_PAYMENT_METHODS = { cash: 'Cash', qris_transfer: 'QRIS / Transfer' };
  let pendingTransactionPaymentDraft = null;
  let transactionEditTargetId = null;
  let transactionPaymentSubmitting = false;

  const OFFICE_LOC = { lat: -6.786168, lng: 106.780918 };
  const RADIUS_LIMIT = 200;
  const SESSION_KEY = 'rocky_supabase_session_v1';
  const PAGE_KEY = 'rocky_supabase_last_page_v1';
  const HEADER_GUIDE_HIDDEN = 'rocky_staff_header_guide_hidden_v1';
  const HEADER_GUIDE_NOTE_DOC_ID = '__header_icon_guide_note';
  const DEFAULT_HEADER_GUIDE_NOTE = 'Bonus adalah apresiasi tambahan dan dapat berubah sewaktu-waktu. Fokus utama tetap pada penjualan, kinerja, pelayanan, dan tanggung jawab kerja.';
  const STAFF_DAILY_NOTE_DOC_ID = '__staff_daily_home_note';
  const DEFAULT_STAFF_DAILY_NOTE = 'Semangat bekerja hari ini. Pastikan transaksi dicatat dengan benar dan refresh jika data belum masuk.';
  const RECEIPT_TEXT_DOC_ID = '__receipt_text_settings';
  const DEFAULT_RECEIPT_TEXT_SETTINGS = {
    storeName: 'ROCKY HIJAB',
    storeSubtext: '',
    dailyTitle: 'TRANSAKSI HARI INI',
    dateLabel: 'Tanggal',
    cashierLabel: 'Kasir',
    productLabel: 'Produk',
    totalLabel: 'Total',
    countLabel: 'Jumlah',
    footerText: 'Terima kasih',
    bottomFeedLines: 6
  };
  const RESTORABLE_PAGES = ['home','history','attendance','report','settings','closing','adminLogs'];
  const ADMIN_USERNAMES = ['admin'];
  const ADMIN_FCM_TOKEN_COLLECTION = 'adminDeviceTokens';
  const ROCKY_NOTIFY_WORKER_BASE_URL = 'https://rocky-notif-worker.alfajrihanif24.workers.dev';
  const ROCKY_NOTIFY_SECRET = 'rockyNotifRahasia2026';
  const ROCKY_SERVER_REGISTER_TOKEN_URL = ROCKY_NOTIFY_WORKER_BASE_URL + '/register-server-token';
  const ROCKY_STAFF_NOTIFY_MANUAL_BONUS_URL = ROCKY_NOTIFY_WORKER_BASE_URL + '/notify-staff-manual-bonus';
  const ROCKY_STAFF_NOTIFY_UNLOCK_REVIEW_URL = ROCKY_NOTIFY_WORKER_BASE_URL + '/notify-staff-unlock-review';
  const ROCKY_NOTIFY_TARGET_URL = ROCKY_NOTIFY_WORKER_BASE_URL + '/notify-target-achieved';
  // Web push Firebase tidak dipakai di mode Supabase. Untuk APK Android, token FCM native tetap bisa disimpan ke tabel adminDeviceTokens.
  const FCM_WEB_VAPID_KEY = '';
  const ADMIN_NOTIF_SEEN_KEY = 'rocky_admin_seen_transaction_notifications_v1';
  const ADMIN_NOTIF_RESTORE_MUTE_KEY = 'rocky_admin_restore_notification_mute_until_v1';
  const ADMIN_NOTIF_SEEN_LIMIT = 1000;
  let adminNotifRestoreMuteUntilMs = Number(localStorage.getItem(ADMIN_NOTIF_RESTORE_MUTE_KEY) || 0);
  let messaging = null;
  try { await enableIndexedDbPersistence(db); } catch (e) { console.log('Offline persistence skipped:', e.code || e.message); }

  let currentUser = null, currentPos = null, currentPage = 'login', historyFilter = 'daily', reportFilter = 'daily', reportMonthKey = '', selectedUserFilter = 'all';
  let appPageHistoryStack = [], appBackNavigating = false;
  let selectedRestoreProFile = null;
  let cachedTransactions = [], cachedAttendance = [], cachedUsers = [], cachedAuditLogs = [], cachedClosings = [], cachedManualBonuses = [], cachedUnlockRequests = [];
  let cachedDailyTarget = null, cachedTargetNotification = null, cachedTargetSettings = {}, cachedTargetSettingRows = [], serverTargetApplyTimer = 0, serverTargetApplying = false;
  let adminNotifBootstrapped = false;
  let adminNotifSeenIds = new Set();
  let cachedBonusSettings = { transactionBonusRate: 0.015, transactionBonusPercent: 1.5, closingBonusPerMinute: 100, closingDeadlineTime: '18:00', closingDeadlineHour: 18, closingDeadlineMinute: 0, closingDeadlineMinutes: 1080 };
  let cachedHeaderGuideNote = { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
  let cachedStaffDailyHomeNote = { id: STAFF_DAILY_NOTE_DOC_ID, note: DEFAULT_STAFF_DAILY_NOTE, enabled: true, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
  let cachedReceiptTextSettings = { id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
  let cachedRismaManualClosingConfig = { id: '__risma_manual_closing', enabled: true, allowedUsers: [], allowedNames: {} };
  let unsubTransactions = null, unsubAttendance = null, unsubUsers = null, unsubAuditLogs = null, unsubClosings = null, unsubBonusSettings = null, unsubManualBonuses = null, unsubUnlockRequests = null, unsubRismaManualClosing = null, unsubHeaderGuideNote = null, unsubReceiptTextSettings = null, rangeStartDate = null, rangeEndDate = null;
  let cachedUserSelectHtml = '';
  let attendanceReady = false, isBusy = false, auditLogLimit = 10, recycleBinLimit = 20, recycleSearch = '', recycleUserFilter = 'all', historyDisplayLimit = 30, inactiveUserLimit = 30, adminMoreOpen = false;
  let attendancePageUserFilter = 'all', attendancePageDateFilter = toDateKey(nowDate()), attendancePageShowDeleted = false, attendancePageLimit = 30;
  let adminProCurrentPageKey = '';
  const TX_SYNC_LIMIT_ADMIN = 800, ATT_SYNC_LIMIT_ADMIN = 800, AUDIT_SYNC_LIMIT = 40, CLOSING_SYNC_LIMIT = 120, MANUAL_BONUS_SYNC_LIMIT = 250, HISTORY_PAGE_STEP = 30, INACTIVE_USER_STEP = 30;
  const ATTENDANCE_PAGE_STEP = 30;
  const DEFAULT_CLOSING_DEADLINE_HOUR = 18, DEFAULT_CLOSING_DEADLINE_MINUTE = 0, DEFAULT_CLOSING_DEADLINE_TIME = '18:00', DEFAULT_CLOSING_BONUS_PER_MINUTE = 100, DEFAULT_TRANSACTION_BONUS_RATE = 0.015;
  const RISMA_MANUAL_CLOSING_DOC_ID = '__risma_manual_closing';
  const RISMA_MANUAL_CLOSING_COLLECTION = 'closings';
  const STAFF_UNLOCK_TABLE = 'staff_leave_requests';
  let appSwipeStartX = 0, appSwipeStartY = 0, appSwipeStartT = 0;
  let adminClosingPanelHash = '', adminDashboardPanelsHash = '';
  let clockInInFlight = false;
  let manualRefreshInFlight = false, lastManualRefreshAt = 0, forceCashFisikNextRender = false;
  let manualBonusSaveInFlight = false, lastManualBonusSubmitSignature = '', lastManualBonusSubmitAt = 0;

  const $ = (id) => document.getElementById(id);
  const setLoading = (s) => {
    isBusy = !!s;
    const el = $('loading');
    if (el) el.style.display = s ? 'flex' : 'none';
  };

  function askPin(message = 'Masukkan PIN:', title = 'Konfirmasi PIN') {
    return new Promise((resolve) => {
      const old = document.getElementById('pin-confirm-modal');
      if (old) old.remove();
      const safeText = String(message || 'Masukkan PIN:')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\n/g, '<br>');
      const safeTitle = String(title || 'Konfirmasi PIN')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      const wrap = document.createElement('div');
      wrap.id = 'pin-confirm-modal';
      wrap.className = 'modal-wrap show';
      wrap.style.zIndex = '900';
      wrap.style.alignItems = 'center';
      wrap.style.justifyContent = 'center';
      wrap.innerHTML = `
        <div class="modal-sheet modal-sheet-wide" style="max-width:400px;border-radius:22px;padding:20px">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
            <div style="width:38px;height:38px;border-radius:12px;background:var(--accent-dim);color:var(--accent);display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="fas fa-key"></i></div>
            <div style="min-width:0">
              <h3 style="font-size:15px;font-weight:900;letter-spacing:-.02em">${safeTitle}</h3>
              <p style="font-size:10.5px;color:var(--text-soft);margin-top:2px">Keyboard angka otomatis di Android</p>
            </div>
          </div>
          <div style="font-size:12px;line-height:1.45;color:var(--text-soft);margin-bottom:11px">${safeText}</div>
          <input id="pin-confirm-input" type="tel" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" class="g-input" placeholder="Masukkan PIN" style="font-size:18px;letter-spacing:.12em;text-align:center;-webkit-text-security:disc" />
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:13px">
            <button id="pin-confirm-cancel" class="btn btn-glass" style="padding:11px;font-size:12px">Batal</button>
            <button id="pin-confirm-ok" class="btn btn-primary" style="padding:11px;font-size:12px">Lanjut</button>
          </div>
        </div>`;
      document.body.appendChild(wrap);
      const input = document.getElementById('pin-confirm-input');
      const close = (value) => { wrap.remove(); resolve(value); };
      document.getElementById('pin-confirm-cancel')?.addEventListener('click', () => close(null));
      document.getElementById('pin-confirm-ok')?.addEventListener('click', () => close(String(input?.value || '').trim()));
      wrap.addEventListener('click', (e) => { if (e.target === wrap) close(null); });
      input?.addEventListener('keydown', (e) => { if (e.key === 'Enter') close(String(input.value || '').trim()); if (e.key === 'Escape') close(null); });
      setTimeout(() => input?.focus(), 80);
    });
  }

  // === SUCCESS TRANSACTION SOUND (ka-ching) ===
  let successAudioCtx = null;
  function getSuccessAudioCtx() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    if (!successAudioCtx) successAudioCtx = new AudioCtx();
    return successAudioCtx;
  }
  function unlockSuccessSound() {
    try {
      const ctx = getSuccessAudioCtx();
      if (ctx && ctx.state === 'suspended') ctx.resume();
    } catch (_) {}
  }
  function playSuccessTone(ctx, start, frequency, duration, gainValue) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(gainValue, start + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain).connect(ctx.destination);
    osc.start(start);
    osc.stop(start + duration + 0.03);
  }
  function playTransactionSuccessSound() {
    try {
      const ctx = getSuccessAudioCtx();
      if (!ctx) return;
      if (ctx.state === 'suspended') ctx.resume();
      const t = ctx.currentTime;
      playSuccessTone(ctx, t, 880, 0.11, 0.16);
      playSuccessTone(ctx, t + 0.1, 1320, 0.16, 0.13);
    } catch (e) {
      console.log('Suara transaksi tidak bisa diputar:', e.message || e);
    }
  }
  ['click', 'touchstart', 'keydown'].forEach((evt) => {
    window.addEventListener(evt, unlockSuccessSound, { once: true, passive: true });
  });
  const showToast = (msg, isError = false) => {
    const t = $('toast'); if (!t) return;
    t.textContent = msg;
    if (isError) { t.style.background='var(--red)'; t.style.color='white'; t.style.border='none'; }
    else { t.style.background='var(--bg2)'; t.style.color='var(--text)'; t.style.border='1px solid var(--border)'; }
    t.classList.add('show'); clearTimeout(window.__toastTimer); window.__toastTimer = setTimeout(()=>t.classList.remove('show'),3000);
  };

  function loadAdminNotifSeenIds() {
    try {
      const raw = JSON.parse(localStorage.getItem(ADMIN_NOTIF_SEEN_KEY) || '[]');
      adminNotifSeenIds = new Set(Array.isArray(raw) ? raw.slice(-ADMIN_NOTIF_SEEN_LIMIT) : []);
    } catch (_) {
      adminNotifSeenIds = new Set();
    }
  }
  function saveAdminNotifSeenIds() {
    try { localStorage.setItem(ADMIN_NOTIF_SEEN_KEY, JSON.stringify([...adminNotifSeenIds].slice(-ADMIN_NOTIF_SEEN_LIMIT))); } catch (_) {}
  }
  function isAdminNotificationMutedForRestore() {
    return Date.now() < Number(adminNotifRestoreMuteUntilMs || 0);
  }
  function muteAdminNotificationsForRestore(ms = 10 * 60 * 1000) {
    adminNotifRestoreMuteUntilMs = Date.now() + Number(ms || 0);
    try { localStorage.setItem(ADMIN_NOTIF_RESTORE_MUTE_KEY, String(adminNotifRestoreMuteUntilMs)); } catch (_) {}
  }
  function unmuteAdminNotificationsForRestore() {
    adminNotifRestoreMuteUntilMs = 0;
    try { localStorage.removeItem(ADMIN_NOTIF_RESTORE_MUTE_KEY); } catch (_) {}
  }
  function isAdminTransactionSource(tx = {}) {
    const user = sanitizeUsername(tx.user || tx.createdBy || '');
    const role = sanitizeUsername(tx.userRole || tx.role || tx.bonusGroup || '');
    const source = sanitizeUsername(tx.source || tx.appSource || '');
    return ADMIN_USERNAMES.includes(user) || role === 'admin' || source.includes('admin_manual');
  }
  function shouldNotifyAdminForTransaction(tx = {}) {
    if (!isAdmin()) return false;
    if (!tx || isRecordDeleted(tx)) return false;
    if (tx.notifyAdmin === false || tx.notificationStatus === 'skip') return false;
    if (isTrialRecord(tx)) return false;
    if (tx.restoredFromBackup === true || tx.source === 'restore_backup' || tx.restoreSource === 'backup') return false;
    if (tx.restoredAt || tx.restoredBy) return false;
    if (isAdminTransactionSource(tx)) return false;
    return Number(tx.amount || 0) > 0;
  }
  function normalizeTransactionPaymentMethod(value) {
    const raw = String(value || '').toLowerCase().trim();
    const compact = raw.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
    if (compact === 'cash' || compact === 'tunai') return 'cash';
    if (compact === 'qris' || compact === 'transfer' || compact === 'qris_transfer' || compact === 'qris_dan_transfer' || compact === 'qris_transfer_bank') return 'qris_transfer';
    if (/qris|qr\s*is|transfer|bank/.test(raw)) return 'qris_transfer';
    if (/cash|tunai/.test(raw)) return 'cash';
    return '';
  }
  function getTransactionPaymentInfo(method) {
    const normalized = normalizeTransactionPaymentMethod(method) || 'cash';
    return {
      method: normalized,
      label: TRANSACTION_PAYMENT_METHODS[normalized] || 'Cash',
      shortLabel: normalized === 'qris_transfer' ? 'QRIS' : 'Cash'
    };
  }
  function getTransactionPaymentLabel(tx = {}) {
    const method = normalizeTransactionPaymentMethod(tx.paymentMethod || tx.payment_method || tx.paymentLabel || tx.payment_label || tx.paymentType || tx.payment_type || tx.metodePembayaran || tx.metode_pembayaran);
    return TRANSACTION_PAYMENT_METHODS[method || 'cash'] || 'Cash';
  }
  function getTransactionPaymentBadge(tx = {}) {
    const method = normalizeTransactionPaymentMethod(tx.paymentMethod || tx.paymentLabel || tx.paymentType || tx.metodePembayaran) || 'cash';
    const label = getTransactionPaymentLabel(tx);
    let cls = '';
    if (method === 'qris_transfer') {
      cls = 'badge-blue'; // Menggunakan badge-blue yang sudah oranye
    } else if (method === 'cash') {
      cls = 'badge-green'; // Menggunakan badge-green yang baru dibuat
    }
    return `<span class="badge ${cls}" style="font-size:9px;padding:2px 7px;line-height:1;letter-spacing:.01em">${escapeHtml(label)}</span>`;
  }

  function getUserChipColorStyle(username) {
    const u = String(username || 'staff').toLowerCase();
    const palette = [
      { bg: 'rgba(211,107,53,.12)', text: 'var(--accent)' },
      { bg: 'rgba(46,138,94,.11)', text: 'var(--green)' },
      { bg: 'rgba(196,138,26,.13)', text: 'var(--amber)' },
      { bg: 'rgba(79,124,255,.11)', text: '#4f7cff' },
      { bg: 'rgba(168,85,247,.11)', text: '#a855f7' },
      { bg: 'rgba(236,72,153,.11)', text: '#ec4899' },
      { bg: 'rgba(20,184,166,.11)', text: '#14b8a6' }
    ];
    let hash = 0;
    for (let i = 0; i < u.length; i++) hash = u.charCodeAt(i) + ((hash << 5) - hash);
    const p = palette[Math.abs(hash) % palette.length];
    return `background:${p.bg};color:${p.text};border-color:${p.bg.replace(/0?\.\d+/, '0.25')}`;
  }

  function markAdminKnownTransactions(rows = []) {
    loadAdminNotifSeenIds();
    rows.forEach(t => { if (t?.id) adminNotifSeenIds.add(String(t.id)); });
    saveAdminNotifSeenIds();
  }
  function showForegroundAdminTransactionNotification(tx = {}) {
    const name = tx.name || tx.user || 'Staff';
    const amount = formatRupiah(tx.amount || 0);
    const note = String(tx.note || 'Transaksi').trim();
    playTransactionSuccessSound();
    showToast(`🔔 Transaksi baru: ${name} • Rp ${amount}`);
    try {
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Transaksi baru Rocky Hijab', {
          body: `${name} • Rp ${amount}${note ? ' • ' + note.slice(0, 42) : ''}`,
          tag: `trx-${tx.id || Date.now()}`,
          data: { transactionId: tx.id || '' }
        });
      }
    } catch (e) {
      console.log('Foreground notification skipped:', e?.message || e);
    }
  }
  function handleAdminTransactionSnapshotNotifications(snap) {
    if (!isAdmin() || !snap) return;
    const currentRows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (isAdminNotificationMutedForRestore()) {
      markAdminKnownTransactions(currentRows);
      adminNotifBootstrapped = true;
      return;
    }
    if (!adminNotifBootstrapped) {
      markAdminKnownTransactions(currentRows);
      adminNotifBootstrapped = true;
      return;
    }
    loadAdminNotifSeenIds();
    const added = snap.docChanges().filter(c => c.type === 'added').map(c => ({ id: c.doc.id, ...c.doc.data() }));
    added.reverse().forEach(tx => {
      const id = String(tx.id || '');
      if (!id || adminNotifSeenIds.has(id)) return;
      adminNotifSeenIds.add(id);
      if (shouldNotifyAdminForTransaction(tx)) showForegroundAdminTransactionNotification(tx);
    });
    saveAdminNotifSeenIds();
  }
  async function registerNativeServerFcmToken(token, platform = 'android') {
    const cleanToken = String(token || '').trim();
    if (!cleanToken || !isAdmin()) return false;
    try {
      const res = await fetch(ROCKY_SERVER_REGISTER_TOKEN_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Notify-Secret': ROCKY_NOTIFY_SECRET },
        body: JSON.stringify({
          token: cleanToken,
          platform: String(platform || 'android'),
          app: 'server_rocky',
          role: 'server',
          username: sanitizeUsername(currentUser.username || 'server'),
          name: currentUser.name || currentUser.username || 'Server Rocky',
          device: 'server-android',
          packageName: 'com.server.rocky',
          secret: ROCKY_NOTIFY_SECRET
        })
      });
      const data = await res.json().catch(() => null);
      if (!res.ok || data?.ok === false) throw new Error(data?.error || 'Gagal daftar server token Cloudflare');
      return true;
    } catch (e) {
      console.warn('Gagal daftar server token Cloudflare:', e?.message || e);
      return false;
    }
  }
  function notifyRockyWorker(url, payload = {}, label = 'Notif Cloudflare') {
    try {
      if (!url || !ROCKY_NOTIFY_SECRET) return Promise.resolve(null);
      return fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Notify-Secret': ROCKY_NOTIFY_SECRET },
        body: JSON.stringify({ ...payload, secret: ROCKY_NOTIFY_SECRET })
      }).then(async res => {
        const data = await res.json().catch(() => null);
        if (!res.ok || data?.ok === false) console.warn(`${label} gagal:`, data || res.status);
        return data;
      }).catch(e => {
        console.warn(`${label} gagal:`, e?.message || e);
        return null;
      });
    } catch (e) {
      console.warn(`${label} gagal:`, e?.message || e);
      return Promise.resolve(null);
    }
  }
  function notifyStaffManualBonusFromServer(row = {}, user = null) {
    const username = sanitizeUsername(row.user || row.username || '');
    const amount = Number(row.amount || 0);
    const action = String(row.action || (amount < 0 ? 'subtract' : 'add')).toLowerCase();
    if (!username || amount <= 0 || action === 'subtract') return Promise.resolve(null);
    const role = normalizeRole(row.userRole || row.role || user?.role || 'staff');
    const daily = isDailyRole(role);
    return notifyRockyWorker(ROCKY_STAFF_NOTIFY_MANUAL_BONUS_URL, {
      targetUsername: username,
      username,
      user: username,
      name: row.name || user?.name || username,
      amount,
      note: String(row.note || ''),
      action: 'add',
      dateKey: String(row.dateKey || ''),
      monthKey: String(row.monthKey || ''),
      bonusId: String(row.id || row.docId || row.clientRequestId || ''),
      type: String(row.type || ''),
      source: String(row.source || 'admin_manual_bonus'),
      role,
      userRole: role,
      actualRole: role,
      bonusGroup: daily ? 'harian' : 'staff',
      isDaily: daily,
      dailyMode: daily,
      actualDaily: daily,
      canReceiveStaffNotifications: true,
      notificationAudience: 'staff',
      createdByName: currentUser?.name || currentUser?.username || 'Server Rocky'
    }, 'Notif bonus staff');
  }
  function notifyStaffUnlockReviewFromServer(row = {}, status = 'approved') {
    const username = sanitizeUsername(row.user || row.username || '');
    if (!username) return Promise.resolve(null);
    return notifyRockyWorker(ROCKY_STAFF_NOTIFY_UNLOCK_REVIEW_URL, {
      targetUsername: username,
      username,
      user: username,
      name: row.name || getUserByUsername(username)?.name || username,
      status: String(status || row.status || ''),
      unlockId: String(row.id || row.docId || ''),
      lockId: String(row.lockId || row.parentLockId || ''),
      missedDate: String(row.missedDate || ''),
      targetDate: String(row.targetDate || row.dateKey || ''),
      dateKey: String(row.dateKey || ''),
      reason: String(row.reason || row.note || ''),
      updatedByName: currentUser?.name || currentUser?.username || 'Server Rocky'
    }, 'Notif review buka fitur staff');
  }
  async function saveNativeAdminFcmToken(token, platform = 'android') {
    const cleanToken = String(token || '').trim();
    if (!cleanToken || !isAdmin()) return false;
    try {
      await setDoc(doc(db, ADMIN_FCM_TOKEN_COLLECTION, cleanToken), {
        token: cleanToken,
        platform: String(platform || 'android'),
        app: 'rocky_admin',
        role: 'admin',
        user: sanitizeUsername(currentUser.username),
        name: currentUser.name || currentUser.username,
        active: true,
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        userAgent: navigator.userAgent || ''
      }, { merge: true });
      await registerNativeServerFcmToken(cleanToken, platform);
      showToast('Token notifikasi server tersimpan');
      return true;
    } catch (e) {
      console.warn('Gagal simpan token FCM admin:', e?.code || e?.message || e);
      return false;
    }
  }
  async function requestNativeAdminFcmToken() {
    try {
      if (window.RockyAdminBridge && typeof window.RockyAdminBridge.requestFcmToken === 'function') {
        window.RockyAdminBridge.requestFcmToken();
      }
    } catch (e) {
      console.log('Native FCM bridge belum tersedia:', e?.message || e);
    }
  }
  window.saveNativeAdminFcmToken = saveNativeAdminFcmToken;
  window.registerNativeServerFcmToken = registerNativeServerFcmToken;
  async function initAdminWebPush() {
    if (!isAdmin()) return;
    if (!('Notification' in window)) return;
    try {
      if (Notification.permission === 'default') await Notification.requestPermission();
      if (Notification.permission !== 'granted') return;
      if (!FCM_WEB_VAPID_KEY) {
        console.log('Web FCM VAPID key kosong. Untuk APK Android pakai token native.');
        return;
      }
      const supported = await isMessagingSupported();
      if (!supported || !('serviceWorker' in navigator)) return;
      const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js');
      messaging = getMessaging(app);
      const token = await getToken(messaging, { vapidKey: FCM_WEB_VAPID_KEY, serviceWorkerRegistration: registration });
      if (token) await saveNativeAdminFcmToken(token, 'web');
      onMessage(messaging, payload => {
        const title = payload?.notification?.title || 'Notifikasi Rocky Hijab';
        const body = payload?.notification?.body || 'Ada notifikasi baru';
        showToast(`🔔 ${title}: ${body}`);
      });
    } catch (e) {
      console.warn('Web FCM tidak aktif:', e?.code || e?.message || e);
    }
  }


  const sanitizeUsername = (u) => String(u || '').trim().toLowerCase();
  const isAdminAccount = (user, usernameFallback = '') => {
    const username = sanitizeUsername(user?.username || usernameFallback);
    const role = sanitizeUsername(user?.role || '');
    return ADMIN_USERNAMES.includes(username) || role === 'admin';
  };
  const isAdmin = () => !!currentUser && isAdminAccount(currentUser, currentUser.username);
  function toSessionUser(user = {}) {
    const { pin, password, ...safeUser } = user || {};
    return safeUser;
  }
  function persistCurrentSession() {
    if (!currentUser) return;
    localStorage.setItem(SESSION_KEY, JSON.stringify(toSessionUser(currentUser)));
  }
  async function verifyCurrentAdminPin(pin) {
    const username = sanitizeUsername(currentUser?.username || '');
    if (!username || !pin || !isAdmin()) return false;
    try {
      const snap = await getDocFromServer(doc(db, 'users', username));
      if (!snap.exists()) return false;
      const user = snap.data() || {};
      if (!isUserActive(user) || !isAdminAccount(user, username)) return false;
      currentUser = {
        ...currentUser,
        ...toSessionUser({
          username: sanitizeUsername(user.username || username),
          name: user.name || currentUser.name || username,
          role: user.role || currentUser.role || 'admin',
          transactionBonusRate: user.transactionBonusRate ?? currentUser.transactionBonusRate ?? null,
          transactionBonusPercent: user.transactionBonusPercent ?? currentUser.transactionBonusPercent ?? null,
          closingBonusPerMinute: user.closingBonusPerMinute ?? currentUser.closingBonusPerMinute ?? null,
          dailyBonusRate: Number(user.dailyBonusRate || currentUser.dailyBonusRate || 0),
          dailyBonusPercent: Number(user.dailyBonusPercent || currentUser.dailyBonusPercent || 0),
          active: isUserActive(user),
          deleted: false
        })
      };
      persistCurrentSession();
      return String(user.pin || '') === String(pin || '');
    } catch (e) {
      console.warn('Verifikasi PIN admin gagal:', e?.message || e);
      return false;
    }
  }
  async function requireCurrentAdminPin(pin, message = 'PIN salah!') {
    const ok = await verifyCurrentAdminPin(pin);
    if (!ok) {
      if (navigator.vibrate) navigator.vibrate(200);
      showToast(message, true);
    }
    return ok;
  }
  function stripCachedAttendance() {
    cachedAttendance = cachedAttendance.filter(a => !a.__cached);
  }
  function formatAttendanceTime(rec) {
    if (!rec) return '--:--';
    const ms = getRecordTimeMs(rec);
    if (!ms) return '--:--';
    return new Date(ms).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', second:'2-digit', timeZone:'Asia/Jakarta' });
  }

  function getAttendanceDocId(username, dateKey) {
    return `${sanitizeUsername(username)}_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}`;
  }

  function upsertAttendanceRecord(rec) {
    if (!rec) return;
    const user = sanitizeUsername(rec.user);
    const dateKey = extractDateKey(rec) || rec.dateKey || toDateKey(nowDate());
    const recId = rec.id ? String(rec.id) : '';
    cachedAttendance = sortByCreatedDesc([
      { ...rec, user, dateKey },
      ...cachedAttendance.filter(a => {
        if (recId && String(a.id) === recId) return false;
        return !(sanitizeUsername(a.user) === user && extractDateKey(a) === dateKey);
      })
    ]);
  }

  function dedupeAttendanceRecords(list) {
    const picked = new Map();
    for (const rec of sortByCreatedDesc(list || [])) {
      const user = sanitizeUsername(rec.user);
      const dateKey = extractDateKey(rec) || rec.dateKey || '';
      const key = user && dateKey ? `${user}_${dateKey}` : `id_${rec.id || Math.random()}`;
      if (!picked.has(key)) picked.set(key, { ...rec, user, dateKey });
    }
    return Array.from(picked.values());
  }


  function dedupeManualBonusRecords(list) {
    const byKey = new Map();
    for (const rec of sortByCreatedDesc(list || [])) {
      if (!rec || rec.deleted === true || rec.deleted === 'true') continue;
      const id = String(rec.id || '').trim();
      const req = String(rec.clientRequestId || '').trim();
      const key = id ? `id:${id}` : (req ? `req:${req}` : `tmp:${sanitizeUsername(rec.user)}:${rec.monthKey || extractDateKey(rec).slice(0,7)}:${Number(rec.amount || 0)}:${String(rec.note || '')}:${Number(rec.createdAtMs || 0)}`);
      if (!byKey.has(key)) byKey.set(key, rec);
    }
    return sortByCreatedDesc(Array.from(byKey.values()));
  }

  function upsertManualBonusRecord(rec) {
    if (!rec) return;
    cachedManualBonuses = dedupeManualBonusRecords([rec, ...(cachedManualBonuses || [])]);
  }

  function safeRestoreDocId(raw) {
    const cleaned = String(raw || '')
      .trim()
      .replace(/[\\/#?\[\]\s]+/g, '_')
      .replace(/[^a-zA-Z0-9_.-]/g, '_')
      .replace(/_+/g, '_')
      .slice(0, 140);
    return cleaned && cleaned !== '_' ? cleaned : '';
  }
  function stableRestoreHash(value) {
    const str = String(value || '');
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h ^= str.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return (h >>> 0).toString(36);
  }
  function getStableTransactionRestoreId(payload) {
    const existing = safeRestoreDocId(payload?.id);
    if (existing) return existing;
    const user = sanitizeUsername(payload?.user);
    const dateKey = String(payload?.dateKey || '').slice(0, 10) || toDateKey(new Date(Number(payload?.createdAtMs || Date.now())));
    const createdAtMs = payload?.restoreHasSourceTime === false ? 0 : (Number(payload?.createdAtMs || 0) || Date.now());
    const amount = Number(payload?.amount || 0);
    const note = String(payload?.note || 'Transaksi').trim();
    const hash = stableRestoreHash([user, dateKey, createdAtMs, amount, note].join('|'));
    return safeRestoreDocId(`restore_tx_${user}_${dateKey}_${createdAtMs}_${amount}_${hash}`);
  }
  async function findExistingTransactionForRestore(payload) {
    const directId = safeRestoreDocId(payload?.id);
    if (directId) {
      try {
        const directSnap = await getDocFromServer(doc(db, 'transactions', directId));
        if (directSnap.exists() && !isRecordDeleted(directSnap.data())) return directId;
      } catch (e) {
        console.warn('Cek transaksi restore by id gagal:', e?.message || e);
      }
    }
    const user = sanitizeUsername(payload?.user);
    const dateKey = String(payload?.dateKey || '').slice(0, 10);
    if (!user || !dateKey) return null;
    const amount = Number(payload?.amount || 0);
    const note = String(payload?.note || 'Transaksi').trim();
    const createdAtMs = payload?.restoreHasSourceTime === false ? 0 : Number(payload?.createdAtMs || 0);
    try {
      const snap = await getDocs(query(collection(db, 'transactions'), where('user', '==', user), where('dateKey', '==', dateKey), limit(500)));
      const same = snap.docs.map(d => ({ id: d.id, ...d.data() })).find(t => {
        if (isRecordDeleted(t)) return false;
        const sameAmount = Number(t.amount || 0) === amount;
        const sameNote = String(t.note || 'Transaksi').trim() === note;
        const tMs = getRecordTimeMs(t) || Number(t.createdAtMs || 0);
        const sameTime = createdAtMs ? Math.abs(Number(tMs || 0) - createdAtMs) <= 1000 : true;
        return sameAmount && sameNote && sameTime;
      });
      return same?.id || null;
    } catch (e) {
      console.warn('Cek transaksi restore legacy gagal:', e?.message || e);
      return null;
    }
  }

  const getRoleLabel = () => 'Admin';
  function getUserOptionsHtml(includeAll = true) {
    const opts = activeUsers().map(u => `<option value="${escapeHtml(u.username)}">${escapeHtml(u.name)} (@${escapeHtml(u.username)})</option>`).join('');
    return `${includeAll ? '<option value="all">Semua User</option>' : ''}${opts}`;
  }
  function getTransactionSelectableUsers() {
    const map = new Map();
    const pushUser = (u) => {
      if (!u) return;
      const username = sanitizeUsername(u.username || u.id || '');
      if (!username) return;
      const rec = { ...u, username, name: u.name || username, role: normalizeRole(u.role || 'staff') };
      if (!isUserActive(rec) && sanitizeUsername(currentUser?.username) !== username) return;
      map.set(username, rec);
    };
    activeUsers().forEach(pushUser);
    pushUser(currentUser);
    return sortUsers([...map.values()]);
  }
  function getTransactionUserOptionsHtml(selectedUsername = '') {
    if (!cachedUserSelectHtml) {
      let users = getTransactionSelectableUsers();
      if (!users.length && currentUser) {
        users = [{ ...currentUser, username: sanitizeUsername(currentUser.username), name: currentUser.name || currentUser.username, role: currentUser.role || 'staff' }];
      }
      cachedUserSelectHtml = users.map(u => {
        const username = sanitizeUsername(u.username || '');
        const label = `${u.name || username} (@${username})`;
        return `<option value="${escapeHtml(username)}">${escapeHtml(label)}</option>`;
      }).join('');
    }
    const selected = sanitizeUsername(selectedUsername || currentUser?.username || '');
    return cachedUserSelectHtml.replace(`value="${selected}"`, `value="${selected}" selected`);
  }
  function setTransactionUserSelect(selectedUsername = '') {
    const select = $('modal-pos-user');
    if (!select) return;
    const selected = sanitizeUsername(selectedUsername || currentUser?.username || '');
    select.innerHTML = getTransactionUserOptionsHtml(selected);
    if (selected) select.value = selected;
    select.disabled = false;
    select.style.opacity = '';
  }
  function getSelectedTransactionUser(fallbackUsername = '') {
    const selected = sanitizeUsername($('modal-pos-user')?.value || fallbackUsername || currentUser?.username || '');
    if (!selected) return null;
    const found = getUserByUsername(selected);
    const fallbackCurrent = sanitizeUsername(currentUser?.username) === selected ? currentUser : null;
    const user = found || fallbackCurrent || { username: selected, name: selected, role: 'staff', active: true };
    return { ...user, username: sanitizeUsername(user.username || selected), name: user.name || selected, role: normalizeRole(user.role || 'staff') };
  }
  function sortUsers(list) {
    return [...list].sort((a,b) => String(a.name || a.username || '').localeCompare(String(b.name || b.username || '')));
  }
  function getSelectedUserLabel() {
    if (selectedUserFilter === 'all') return 'Semua User';
    const found = cachedUsers.find(u => u.username === selectedUserFilter);
    return found ? `${found.name} (@${found.username})` : selectedUserFilter;
  }
  function getUserByUsername(username) {
    return cachedUsers.find(u => sanitizeUsername(u.username) === sanitizeUsername(username)) || null;
  }
  function getUserDataScopeLabel() {
    return getSelectedUserLabel();
  }
  function isRecordDeleted(rec) {
    return !!rec && (rec.deleted === true || rec.deleted === 'true');
  }
  function isUserActive(rec) {
    return !!rec && rec.active !== false && rec.active !== 'false' && rec.deleted !== true && rec.deleted !== 'true';
  }
  function activeUsers(list = cachedUsers) {
    return sortUsers((list || []).filter(isUserActive));
  }
  function isTruthyFlag(value) {
    return value === true || value === 1 || String(value || '').toLowerCase() === 'true' || String(value || '') === '1';
  }
  function isDummyUser(rec) {
    const value = String(rec?.accountType || rec?.mode || '').toLowerCase();
    return !!rec && (isTruthyFlag(rec.isDummy) || isTruthyFlag(rec.trialMode) || isTruthyFlag(rec.dummy) || value === 'dummy' || value === 'trial');
  }
  function getTrialFlags(user) {
    const dummy = isDummyUser(user);
    return dummy ? { isDummy: true, trialMode: true, accountType: 'dummy', excludeFromReports: true } : { isDummy: false, trialMode: false, accountType: 'normal', excludeFromReports: false };
  }
  function isTrialRecord(rec) {
    if (!rec) return false;
    if (isTruthyFlag(rec.isDummy) || isTruthyFlag(rec.trialMode) || isTruthyFlag(rec.excludeFromReports) || String(rec.accountType || '').toLowerCase() === 'dummy') return true;
    const username = sanitizeUsername(rec.user || rec.username || rec.targetUsername || '');
    return !!username && isDummyUser(getUserByUsername(username));
  }
  function realActiveUsers(list = cachedUsers) {
    return activeUsers(list).filter(u => !isDummyUser(u));
  }

  function normalizeRole(role = 'staff') {
    const value = sanitizeUsername(role || 'staff');
    if (['harian','daily','karyawan_harian'].includes(value)) return 'harian';
    if (value === 'admin') return 'admin';
    return 'staff';
  }
  function getRoleDisplayName(role = 'staff') {
    const normalized = normalizeRole(role);
    if (normalized === 'harian') return 'Karyawan Harian';
    if (normalized === 'admin') return 'Admin';
    return 'Staff';
  }
  function isDailyRole(role) { return normalizeRole(role) === 'harian'; }
  function isStaffRole(role) { return normalizeRole(role) === 'staff'; }
  function isBlockedStaffDailyRoleSwitch(oldRole, newRole) {
    const oldNormalized = normalizeRole(oldRole);
    const newNormalized = normalizeRole(newRole);
    return (oldNormalized === 'staff' && newNormalized === 'harian') || (oldNormalized === 'harian' && newNormalized === 'staff');
  }
  function isStaffBonusUser(userOrUsername) {
    const user = typeof userOrUsername === 'object' ? userOrUsername : getUserByUsername(userOrUsername);
    return !!user && isUserActive(user) && normalizeRole(user.role || 'staff') === 'staff' && !ADMIN_USERNAMES.includes(sanitizeUsername(user.username));
  }
  function getStaffBonusUsers() {
    return realActiveUsers().filter(isStaffBonusUser);
  }
  function isManualBonusUser(userOrUsername) {
    const user = typeof userOrUsername === 'object' ? userOrUsername : getUserByUsername(userOrUsername);
    const role = normalizeRole(user?.role || 'staff');
    return !!user && isUserActive(user) && ['staff','harian'].includes(role) && !ADMIN_USERNAMES.includes(sanitizeUsername(user.username));
  }
  function getManualBonusUsers() {
    return activeUsers().filter(isManualBonusUser);
  }
  function getTransactionBonusGroup(trx = null) {
    const storedGroup = sanitizeUsername(trx?.bonusGroup || trx?.bonusType || '');
    if (storedGroup === 'harian') return 'harian';
    if (storedGroup === 'staff') return 'staff';
    const storedRole = trx?.userRole || trx?.role || '';
    if (storedRole && isDailyRole(storedRole)) return 'harian';
    if (storedRole && !isDailyRole(storedRole)) return 'staff';
    return isDailyEmployee(trx?.user) ? 'harian' : 'staff';
  }
  function isDailyTransactionRecord(trx = null) {
    return getTransactionBonusGroup(trx) === 'harian';
  }
  function getTransactionBonusRateForRecord(trx = null) {
    const storedRate = Number(trx?.bonusRate ?? trx?.transactionBonusRate);
    if (Number.isFinite(storedRate) && storedRate >= 0) return storedRate;
    const storedPercent = Number(trx?.bonusPercent ?? trx?.transactionBonusPercent);
    if (Number.isFinite(storedPercent) && storedPercent >= 0) return storedPercent / 100;
    return getUserTransactionBonusRate(trx?.user);
  }
  async function logAudit(action, detail = {}) {
    try {
      await addDoc(collection(db, 'audit_logs'), {
        action,
        detail,
        actor: currentUser?.username || 'system',
        actorName: currentUser?.name || 'System',
        createdAt: serverTimestamp(),
        createdAtMs: Date.now()
      });
    } catch (e) {
      console.error('Audit log gagal:', e);
    }
  }
  function getVisibleTransactions() {
    return cachedTransactions.filter(t => !isRecordDeleted(t) && !isTrialRecord(t));
  }
  function getVisibleAttendance() {
    return cachedAttendance.filter(a => !isRecordDeleted(a) && !isTrialRecord(a));
  }
  function getDeletedTransactions() {
    return sortByCreatedDesc(cachedTransactions.filter(isRecordDeleted));
  }
  function getFilteredDeletedTransactions() {
    let items = getDeletedTransactions();
    if (recycleUserFilter !== 'all') items = items.filter(t => sanitizeUsername(t.user) === sanitizeUsername(recycleUserFilter));
    if (recycleSearch.trim()) {
      const q = recycleSearch.trim().toLowerCase();
      items = items.filter(t =>
        String(t.note || '').toLowerCase().includes(q) ||
        String(t.name || '').toLowerCase().includes(q) ||
        String(t.user || '').toLowerCase().includes(q) ||
        String(t.id || '').toLowerCase().includes(q)
      );
    }
    return items;
  }
  function setRecycleSearch(value) {
    recycleSearch = String(value || '');
    recycleBinLimit = 20;
    renderSettingsSummary();
    refreshCurrentPage();
  }
  function setRecycleUserFilter(value) {
    recycleUserFilter = value || 'all';
    recycleBinLimit = 20;
    renderSettingsSummary();
    refreshCurrentPage();
  }
  function resetRecycleFilters() {
    recycleSearch = '';
    recycleUserFilter = 'all';
    recycleBinLimit = 20;
    renderSettingsSummary();
    refreshCurrentPage();
  }
  function increaseRecycleBinLimit() {
    recycleBinLimit += 20;
    renderSettingsSummary();
    refreshCurrentPage();
  }
  function resetHistoryDisplayLimit() {
    historyDisplayLimit = HISTORY_PAGE_STEP;
  }
  function increaseHistoryDisplayLimit() {
    historyDisplayLimit += HISTORY_PAGE_STEP;
    renderHistory();
  }
  function resetInactiveUserLimit() {
    inactiveUserLimit = INACTIVE_USER_STEP;
  }
  function increaseInactiveUserLimit() {
    inactiveUserLimit += INACTIVE_USER_STEP;
    renderSettingsSummary();
  }
  function getFilteredAuditLogs() {
    return sortByCreatedDesc(cachedAuditLogs).slice(0, auditLogLimit);
  }
  function increaseAuditLogLimit() {
    auditLogLimit += 10;
    renderSettingsSummary();
  }
  function summarizeAuditLog(log) {
    const d = log?.detail || {};
    if (log.action === 'user_upsert') return `Simpan user ${d.username || '-'}`;
    if (log.action === 'user_soft_delete') return `Nonaktifkan user ${d.username || '-'}`;
    if (log.action === 'user_hard_delete') return `Hapus permanen user ${d.username || '-'}`;
    if (log.action === 'transaction_soft_delete') return `Hapus transaksi ${d.id || '-'}`;
    if (log.action === 'transaction_restore') return `Pulihkan transaksi ${d.id || '-'}`;
    if (log.action === 'transaction_hard_delete') return `Hapus permanen transaksi ${d.id || '-'}`;
    if (log.action === 'reset_all_data') return 'Reset semua data aplikasi';
    if (log.action === 'restore_data') return `Restore data ${d.format || ''}`.trim();
    if (log.action === 'normalize_legacy_data') return `Normalisasi ${d.updated || 0} data`;
    if (log.action === 'closing_day') return `Closing ${d.dateKey || '-'} · bonus Rp ${formatRupiah(d.totalBonus || 0)}`;
    if (log.action === 'closing_cancel') return `Batal closing ${d.dateKey || '-'}`;
    if (log.action === 'closing_cancel_user_from_global') return `Buka ${d.name || d.user || '-'} dari closing global ${d.dateKey || '-'}`;
    if (log.action === 'bonus_settings_update') return `Update bonus transaksi ${d.transactionBonusPercent || 0}% · closing Rp ${formatRupiah(d.closingBonusPerMinute || 0)}/menit`;
    if (log.action === 'user_bonus_control_update') return `Update bonus khusus ${d.name || d.username || '-'} · transaksi ${d.transactionBonusPercent || 0}% · closing Rp ${formatRupiah(d.closingBonusPerMinute || 0)}/menit`;
    if (log.action === 'manual_bonus_add') return `Bonus manual ${d.name || d.user || '-'} · Rp ${formatRupiah(d.amount || 0)}`;
    if (log.action === 'header_guide_note_update') return `Update catatan Panduan Header`;
    if (log.action === 'staff_daily_home_note_update') return `Update catatan Home Staff & Harian`;
    if (log.action === 'receipt_text_settings_update') return `Update setting tulisan struk`;
    return log.action || 'audit';
  }
  function formatAuditTime(log) {
    const ms = getRecordTimeMs(log);
    return ms ? new Date(ms).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-';
  }

  function renderAdminLogItems(logs, emptyText = 'Belum ada audit log.') {
    return logs.length ? logs.map(log => `
      <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 13px;border:1px solid var(--border);border-radius:14px;background:var(--bg2)">
        <div style="width:38px;height:38px;border-radius:12px;background:var(--accent-dim);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--accent)"><i class="fas fa-clock-rotate-left" style="font-size:13px"></i></div>
        <div style="min-width:0;flex:1">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start">
            <div style="font-size:13px;font-weight:800;line-height:1.35">${escapeHtml(summarizeAuditLog(log))}</div>
            <span class="badge badge-blue" style="flex-shrink:0">${escapeHtml((log.action || 'log').replaceAll('_',' ').slice(0,14))}</span>
          </div>
          <div style="font-size:10.5px;color:var(--text-soft);margin-top:5px">${escapeHtml(log.actorName || log.actor || '-')} · ${escapeHtml(formatAuditTime(log))}</div>
        </div>
      </div>`).join('') : `<div class="card" style="padding:18px;text-align:center;color:var(--text-soft);font-size:12px">${emptyText}</div>`;
  }

  function renderAdminLogsPage() {
    const box = $('admin-logs-list');
    if (!box) return;
    const logs = getFilteredAuditLogs();
    const hasMoreLogs = cachedAuditLogs.length > logs.length;
    box.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
        <div>
          <p class="label-xs" style="margin:0">Audit Log</p>
          <p style="font-size:11px;color:var(--text-soft);margin-top:4px">Riwayat aktivitas penting admin dan sistem.</p>
        </div>
        <span class="status-pill status-ok">${cachedAuditLogs.length} log</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">${renderAdminLogItems(logs)}</div>
      ${hasMoreLogs ? `<button onclick="increaseAuditLogLimit()" class="btn btn-glass" style="width:100%;margin-top:12px;padding:12px;font-size:12px">Muat 10 log lagi</button>` : ''}
    `;
  }
  function getAdminDashboardData() {
    // Mode ringan untuk Beranda Admin: ranking dan detail berat tetap di tab Global.
    const today = toDateKey(nowDate());
    const todayUsers = new Set();
    for (const a of getVisibleAttendance()) {
      if (extractDateKey(a) === today) todayUsers.add(sanitizeUsername(a.user));
    }
    return { activeToday: todayUsers.size, userCount: realActiveUsers().length };
  }
  function renderAdminClosingPanelMaybe(force = false) {
    if (!isAdmin()) return;
    const box = $('admin-closing-panel');
    if (!box) return;
    const targetValue = sanitizeUsername($('closing-target-user')?.value || 'global') || 'global';
    const targetUser = targetValue === 'global' ? null : getUserByUsername(targetValue);
    const closing = targetUser ? (getTodayUserClosing(targetUser.username) || getTodayGlobalClosingForUser(targetUser.username)) : getTodayGlobalClosing();
    const userBonusHash = getStaffClosingUsers().map(u => `${sanitizeUsername(u.username)}:${getUserClosingBonusPerMinute(u.username)}`).join(',');
    const manualClosingHash = getRismaManualClosingAllowedUsers().join(',') + '|' + (cachedRismaManualClosingConfig?.updatedAtMs || '');
    const hash = [targetValue, closing?.id || '', closing?.closed === true ? '1' : '0', closing?.closingTime || '', closing?.manualClosingTime || '', closing?.editedAtMs || '', closing?.canceledAtMs || '', cachedUsers.length, getClosingBonusPerMinute(), getClosingDeadlineTimeLabel(), userBonusHash, manualClosingHash].join('|');
    if (force || hash !== adminClosingPanelHash || !box.innerHTML.trim()) {
      adminClosingPanelHash = hash;
      renderAdminClosingPanel();
    }
  }
  function renderAdminDashboardPanels() {
    if (!isAdmin()) return;
    const board = $('admin-dashboard-panels');
    if (!board) return;
    const stats = getAdminDashboardData();
    const target = serverDailyTargetSummary();
    const hash = `${stats.activeToday}|${stats.userCount}|${target.totalAmount}|${target.progressPercent}|${target.reached}|${cachedTargetNotification?.read === false ? 'new' : 'seen'}`;
    if (hash === adminDashboardPanelsHash && board.innerHTML.trim()) return;
    adminDashboardPanelsHash = hash;
    board.innerHTML = `
      ${renderServerDailyTargetCard(target)}
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px" class="page-in s3">
        <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">User Aktif Hari Ini</p><p style="font-family:var(--num-font);font-size:18px;font-weight:850;color:var(--green);line-height:1">${stats.activeToday}</p></div>
        <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">User Sistem</p><p style="font-family:var(--num-font);font-size:18px;font-weight:850;color:var(--accent);line-height:1">${stats.userCount}</p></div>
      </div>
      <button onclick="router.navigate('report')" class="btn btn-glass page-in s4" style="width:100%;padding:10px 12px;font-size:12px;margin-bottom:8px"><i class="fas fa-ranking-star"></i> Lihat Ranking Omzet di Global</button>
`;
  }

  const SERVER_DAILY_TARGET_AMOUNT = 2500000;
  const SERVER_BONUS_TARGET_AMOUNT = 10000;
  const SERVER_TARGET_SETTINGS_TABLE = 'targetSettings';
  const SERVER_DAILY_TARGETS_TABLE = 'dailyTargets';
  const SERVER_TARGET_REWARDS_TABLE = 'targetBonusRewards';
  const SERVER_TARGET_NOTIFICATIONS_TABLE = 'targetNotifications';
  function serverTargetDocId(dateKey = toDateKey(nowDate())) { return `daily_target_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}`; }
  function serverTargetSettingDocId(dateKey = toDateKey(nowDate())) { return `daily_target_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}`; }
  function serverTargetBonusId(dateKey, username) { return `targetbonus_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}_${sanitizeUsername(username)}`; }
  function serverTargetRewardId(dateKey, username) { return `targetreward_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}_${sanitizeUsername(username)}`; }
  function serverTargetNotifId(dateKey = toDateKey(nowDate())) { return `targetnotif_${String(dateKey || toDateKey(nowDate())).slice(0, 10)}`; }
  function serverNormalizeTargetDateKey(value, fallback = toDateKey(nowDate())) {
    const raw = String(value || '').trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw.slice(0, 10))) return raw.slice(0, 10);
    let match = raw.match(/^(\d{1,2})$/);
    if (match) {
      const day = Number(match[1]);
      if (day >= 1 && day <= 31) return `${toDateKey(nowDate()).slice(0, 7)}-${String(day).padStart(2, '0')}`;
    }
    match = raw.match(/^(\d{1,2})[/-](\d{1,2})$/);
    if (match) {
      const day = Number(match[1]), month = Number(match[2]);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12) return `${toDateKey(nowDate()).slice(0, 4)}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
    return fallback;
  }
  function serverTargetSettingDate(row = {}) {
    const idDate = String(row.id || '').match(/^daily_target_(\d{4}-\d{2}-\d{2})$/);
    return serverNormalizeTargetDateKey(row.effectiveDate || row.dateKey || row.startDate || row.targetDate || (idDate ? idDate[1] : ''), '');
  }
  function serverIsDailyTargetSettingRow(row = {}) {
    const id = String(row.id || '');
    return id === 'daily_target'
      || id === '__daily_target'
      || id === 'default'
      || id.startsWith('daily_target_')
      || String(row.type || '') === 'daily_target_setting'
      || String(row.targetSettingType || '') === 'daily_target';
  }
  function isTargetAutoBonusRow(row = {}) {
    return String(row.source || '') === 'daily_target'
      || String(row.type || '') === 'daily_target_bonus'
      || String(row.id || '').startsWith('targetbonus_');
  }
  async function resetServerTargetAutoBonusAfterDelete(row = {}) {
    if (!isTargetAutoBonusRow(row)) return;
    const username = sanitizeUsername(row.user || row.targetUsername || row.username || '');
    const dateKey = String(row.dateKey || extractDateKey(row) || toDateKey(nowDate())).slice(0, 10);
    if (!username || !dateKey) return;
    const rewardId = serverTargetRewardId(dateKey, username);
    const targetId = serverTargetDocId(dateKey);
    const nowMs = Date.now();
    await setDoc(doc(db, SERVER_TARGET_REWARDS_TABLE, rewardId), {
      deleted: true,
      resetAt: serverTimestamp(),
      resetAtMs: nowMs,
      resetBy: currentUser?.username || 'server',
      resetByName: currentUser?.name || 'Server Rocky',
      staffNotificationSent: false,
      staffNotificationStatus: 'reset',
      staffNotifiedAtMs: 0,
      updatedAt: serverTimestamp(),
      updatedAtMs: nowMs
    }, { merge: true }).catch(() => {});
    const current = String(cachedDailyTarget?.dateKey || '') === dateKey ? (cachedDailyTarget || {}) : {};
    const rewardedUsers = (current.rewardedUsers || []).map(sanitizeUsername).filter(u => u && u !== username);
    const patch = {
      bonusApplied: false,
      rewardedUsers,
      resetAt: serverTimestamp(),
      resetAtMs: nowMs,
      resetBy: currentUser?.username || 'server',
      resetByName: currentUser?.name || 'Server Rocky',
      updatedAt: serverTimestamp(),
      updatedAtMs: nowMs
    };
    await setDoc(doc(db, SERVER_DAILY_TARGETS_TABLE, targetId), patch, { merge: true }).catch(() => {});
    if (String(cachedDailyTarget?.dateKey || '') === dateKey) cachedDailyTarget = { ...cachedDailyTarget, ...patch };
  }
  function mergeServerTargetUsers(...groups) {
    const set = new Set();
    groups.flat().forEach(u => { const k = sanitizeUsername(u); if (k) set.add(k); });
    return [...set];
  }
  async function revokeServerDailyTargetBonuses(summary, plan, previous = {}) {
    const dateKey = String(summary?.dateKey || toDateKey(nowDate())).slice(0, 10);
    const nowMs = Date.now();
    const users = mergeServerTargetUsers(plan?.rewardedUsers || [], previous?.rewardedUsers || [], cachedDailyTarget?.rewardedUsers || [], (plan?.users || []).map(u => u?.username || u?.id));
    for (const username of users) {
      const bonusId = serverTargetBonusId(dateKey, username);
      const rewardId = serverTargetRewardId(dateKey, username);
      try {
        const snap = await getDocFromServer(doc(db, 'manualBonuses', bonusId)).catch(() => null);
        const row = snap?.exists() ? { id: bonusId, ...(snap.data() || {}) } : null;
        if (row && !isRecordDeleted(row) && isTargetAutoBonusRow(row)) {
          const patch = { deleted: true, status: 'deleted', deletedAt: serverTimestamp(), deletedAtMs: nowMs, deletedBy: 'target_auto', deletedByName: 'Target Otomatis Rocky', deleteReason: 'Omzet turun di bawah target harian', updatedAt: serverTimestamp(), updatedAtMs: nowMs };
          await setDoc(doc(db, 'manualBonuses', bonusId), patch, { merge: true });
          upsertManualBonusRecord({ ...row, ...patch, id: bonusId });
        }
        await setDoc(doc(db, SERVER_TARGET_REWARDS_TABLE, rewardId), {
          deleted: true,
          resetAt: serverTimestamp(),
          resetAtMs: nowMs,
          resetBy: 'target_auto',
          resetByName: 'Target Otomatis Rocky',
          resetReason: 'Omzet turun di bawah target harian',
          staffNotificationSent: false,
          staffNotificationStatus: 'reset',
          staffNotifiedAtMs: 0,
          updatedAt: serverTimestamp(),
          updatedAtMs: nowMs
        }, { merge: true }).catch(() => {});
      } catch (e) {
        console.warn('rollback bonus target server gagal', username, e?.code || e?.message || e);
      }
    }
    await deleteDoc(doc(db, SERVER_TARGET_NOTIFICATIONS_TABLE, serverTargetNotifId(dateKey))).catch(() => {});
    cachedTargetNotification = null;
    await serverSaveTargetStatus(summary, plan, { bonusApplied: false, rewardedUsers: [] });
  }
  function serverTargetNumber(data, keys, fallback) {
    for (const key of keys) {
      const n = Number(data?.[key]);
      if (Number.isFinite(n) && n >= 0) return n;
    }
    return fallback;
  }
  function serverNormalizeTargetSettings(data = {}, fallbackDate = toDateKey(nowDate())) {
    const activeDate = serverTargetSettingDate(data) || serverNormalizeTargetDateKey(fallbackDate, toDateKey(nowDate()));
    return {
      id: String(data.id || ''),
      dateKey: activeDate,
      effectiveDate: activeDate,
      targetAmount: serverTargetNumber(data, ['targetAmount','dailyTargetAmount','dailyOmzetTarget','omzetTarget'], SERVER_DAILY_TARGET_AMOUNT),
      bonusAmount: serverTargetNumber(data, ['bonusAmount','bonusTargetAmount','dailyTargetBonusAmount','targetBonusAmount','BONUS_TARGET_AMOUNT'], SERVER_BONUS_TARGET_AMOUNT),
      updatedAtMs: Number(data.updatedAtMs || 0)
    };
  }
  function serverPickTargetSettings(rows = [], dateKey = toDateKey(nowDate())) {
    const targetDate = serverNormalizeTargetDateKey(dateKey, toDateKey(nowDate()));
    let best = null, bestDate = '', bestUpdated = 0;
    rows.filter(serverIsDailyTargetSettingRow).forEach((row) => {
      const rowDate = serverTargetSettingDate(row);
      if (rowDate && rowDate > targetDate) return;
      const scoreDate = rowDate || '0000-00-00';
      const updated = Number(row.updatedAtMs || 0);
      if (!best || scoreDate > bestDate || (scoreDate === bestDate && updated >= bestUpdated)) {
        best = row;
        bestDate = scoreDate;
        bestUpdated = updated;
      }
    });
    return best ? serverNormalizeTargetSettings(best, targetDate) : null;
  }
  function serverTargetScheduleRows() {
    const map = new Map();
    (cachedTargetSettingRows || []).filter(serverIsDailyTargetSettingRow).forEach((row) => {
      const normalized = serverNormalizeTargetSettings(row, serverTargetSettingDate(row) || toDateKey(nowDate()));
      const dk = normalized.effectiveDate || normalized.dateKey;
      if (!dk) return;
      const old = map.get(dk);
      if (!old || old.id === 'daily_target' || (normalized.id !== 'daily_target' && Number(normalized.updatedAtMs || 0) >= Number(old.updatedAtMs || 0))) map.set(dk, normalized);
    });
    return [...map.values()].sort((a, b) => String(b.effectiveDate || b.dateKey).localeCompare(String(a.effectiveDate || a.dateKey)));
  }
  function renderServerTargetScheduleList() {
    const rows = serverTargetScheduleRows().slice(0, 12);
    if (!rows.length) return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:12px 13px"><p class="label-xs">Jadwal Target Tersimpan</p><p style="font-size:10.5px;color:var(--text-soft);margin-top:6px;line-height:1.35">Belum ada jadwal target bertanggal.</p></div>`;
    return `<div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:12px 13px"><p class="label-xs">Jadwal Target Tersimpan</p><div style="display:grid;gap:7px;margin-top:8px">${rows.map((r) => { const dk = serverNormalizeTargetDateKey(r.effectiveDate || r.dateKey, ''); const rowId = String(r.id || serverTargetSettingDocId(dk)).replace(/[^a-zA-Z0-9_-]/g, ''); return `<div style="display:grid;grid-template-columns:minmax(72px,.85fr) minmax(0,1fr) minmax(0,1fr) auto;gap:7px;align-items:center;border:1px solid var(--border);border-radius:12px;padding:8px;background:var(--bg2)"><b style="font-size:11px;white-space:nowrap">${escapeHtml(formatDateLabel(dk))}</b><span style="font-size:10.5px;color:var(--text-soft);font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">Target Rp ${formatRupiah(r.targetAmount)}</span><span style="font-size:10.5px;color:var(--text-soft);font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">Bonus Rp ${formatRupiah(r.bonusAmount)}</span><button onclick="deleteServerTargetSchedule('${dk}','${rowId}')" class="btn btn-danger" title="Hapus target tanggal ini" style="width:34px;height:34px;min-height:34px;padding:0;border-radius:10px"><i class="fas fa-trash"></i></button></div>`; }).join('')}</div><p style="font-size:10.5px;color:var(--text-soft);margin-top:7px;line-height:1.35">Tanggal yang belum diset akan memakai target terakhir sebelumnya.</p></div>`;
  }
  function serverTargetSettings(dateKey = toDateKey(nowDate())) {
    return serverNormalizeTargetSettings(cachedTargetSettings || {}, dateKey);
  }
  function serverTargetTransactions(dateKey = toDateKey(nowDate())) {
    const d = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    const activeSet = new Set(realActiveUsers().filter(u => normalizeRole(u.role || 'staff') !== 'admin').map(u => sanitizeUsername(u.username || u.id)).filter(Boolean));
    return getVisibleTransactions().filter(t => getTransactionDateKey(t) === d && (!activeSet.size || activeSet.has(sanitizeUsername(t.user))));
  }
  function serverDailyTargetSummary(dateKey = toDateKey(nowDate())) {
    const d = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    const settings = serverTargetSettings(d);
    const targetAmount = Math.max(1, Number(settings.targetAmount || SERVER_DAILY_TARGET_AMOUNT));
    const totalAmount = serverTargetTransactions(d).reduce((sum, t) => sum + Number(t.amount || 0), 0);
    const progressPercent = Number(((totalAmount / targetAmount) * 100).toFixed(2));
    return { dateKey: d, targetSettingDate: settings.effectiveDate || settings.dateKey || d, targetAmount, totalAmount, progressPercent, reached: totalAmount >= targetAmount, remainingAmount: Math.max(0, targetAmount - totalAmount), bonusAmount: Number(settings.bonusAmount || 0) };
  }
  function serverTargetRewardPlan(dateKey = toDateKey(nowDate())) {
    const d = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    const attUsers = new Set(getVisibleAttendance().filter(a => extractDateKey(a) === d).map(a => sanitizeUsername(a.user)).filter(Boolean));
    const users = realActiveUsers().filter(u => normalizeRole(u.role || 'staff') !== 'admin').map(u => ({ ...u, username: sanitizeUsername(u.username || u.id) })).filter(u => u.username);
    const active = users.map(u => u.username);
    const hasRismaTx = hasRismaTransactionOnDate(d);
    const rewarded = users.filter(u => {
      if (u.username === 'risma') return hasRismaTx;
      return !isDailyRole(u.role || 'staff') && attUsers.has(u.username);
    }).map(u => u.username);
    const byUser = new Map(users.map(u => [u.username, u]));
    return { activeUsers: active, rewardedUsers: rewarded, users: rewarded.map(u => byUser.get(u)).filter(Boolean) };
  }
  async function serverLoadTargetSettings(dateKey = toDateKey(nowDate())) {
    const targetDate = serverNormalizeTargetDateKey(dateKey, toDateKey(nowDate()));
    try {
      const snap = await getDocsFromServer(query(collection(db, SERVER_TARGET_SETTINGS_TABLE), limit(1000)));
      const rows = snap.docs.map((x) => ({ id: x.id, ...x.data() }));
      cachedTargetSettingRows = rows.filter(serverIsDailyTargetSettingRow);
      const picked = serverPickTargetSettings(rows, targetDate);
      if (picked) {
        cachedTargetSettings = picked;
        return;
      }
    } catch (e) {
      console.warn('jadwal target server belum terbaca', e?.code || e?.message || e);
    }
    for (const id of ['daily_target','__daily_target','default']) {
      try {
        const snap = await getDocFromServer(doc(db, SERVER_TARGET_SETTINGS_TABLE, id));
        if (snap.exists()) {
          const data = { id: snap.id, ...(snap.data() || {}) };
          cachedTargetSettingRows = [...(cachedTargetSettingRows || []).filter((row) => String(row.id) !== String(data.id)), data];
          const rowDate = serverTargetSettingDate(data);
          if (!rowDate || rowDate <= targetDate) {
            cachedTargetSettings = serverNormalizeTargetSettings(data, targetDate);
            return;
          }
        }
      } catch (_) {
        return;
      }
    }
  }
  async function serverInsertIfAbsent(table, id, payload) {
    try {
      const { error } = await supabase.from(table).insert({ id, data: deepCloneCompat(payload || {}) });
      if (error) {
        if (error.code === '23505' || /duplicate/i.test(error.message || '')) return false;
        throw error;
      }
      return true;
    } catch (e) {
      console.warn(`${table} insert dilewati`, e?.code || e?.message || e);
      return false;
    }
  }
  async function serverNotifyTarget(summary, plan) {
    try {
      await fetch(ROCKY_NOTIFY_TARGET_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Notify-Secret': ROCKY_NOTIFY_SECRET },
        body: JSON.stringify({ secret: ROCKY_NOTIFY_SECRET, dateKey: summary.dateKey, targetAmount: summary.targetAmount, totalAmount: summary.totalAmount, bonusAmount: summary.bonusAmount, activeUsers: plan.activeUsers, rewardedUsers: plan.rewardedUsers })
      });
    } catch (e) {
      console.warn('notify target server gagal', e?.message || e);
    }
  }
  async function serverEnsureStaffTargetBonusNotification(summary, user, amount) {
    const username = sanitizeUsername(user?.username || user?.id || '');
    if (!username || Number(amount || 0) <= 0) return false;
    const bonusId = serverTargetBonusId(summary.dateKey, username);
    const rewardId = serverTargetRewardId(summary.dateKey, username);
    try {
      const rewardSnap = await getDocFromServer(doc(db, SERVER_TARGET_REWARDS_TABLE, rewardId)).catch(() => null);
      const reward = rewardSnap?.exists() ? (rewardSnap.data() || {}) : {};
      if (reward.staffNotificationSent === true || Number(reward.staffNotifiedAtMs || 0) > 0) return false;
      const role = normalizeRole(user.role || 'staff');
      const fallback = {
        id: bonusId,
        user: username,
        targetUsername: username,
        name: user.name || username,
        userRole: role,
        role,
        bonusGroup: 'staff',
        amount,
        dateKey: summary.dateKey,
        monthKey: summary.dateKey.slice(0, 7),
        type: 'daily_target_bonus',
        source: 'daily_target',
        note: 'Bonus target omzet harian tercapai',
        description: 'Bonus otomatis karena target omzet harian gabungan tercapai',
        action: 'add',
        deleted: false
      };
      const bonusSnap = await getDocFromServer(doc(db, 'manualBonuses', bonusId)).catch(() => null);
      const row = bonusSnap?.exists() ? { ...fallback, ...(bonusSnap.data() || {}), id: bonusId, docId: bonusId } : fallback;
      const notifyResult = await notifyStaffManualBonusFromServer(row, user);
      const sent = !!notifyResult && notifyResult.ok !== false;
      if (!sent) return false;
      await setDoc(doc(db, SERVER_TARGET_REWARDS_TABLE, rewardId), {
        id: rewardId,
        dateKey: summary.dateKey,
        user: username,
        targetUsername: username,
        amount,
        manualBonusId: bonusId,
        type: 'daily_target_bonus',
        source: 'daily_target',
        staffNotificationSent: true,
        staffNotificationStatus: 'sent',
        staffNotifiedAt: serverTimestamp(),
        staffNotifiedAtMs: Date.now()
      }, { merge: true }).catch(() => {});
      return true;
    } catch (e) {
      console.warn('ensure notif bonus target server gagal', e?.code || e?.message || e);
      return false;
    }
  }
  async function serverEnsureStaffTargetBonusNotifications(summary, plan, amount) {
    const rewarded = [];
    if (Number(amount || 0) <= 0) return rewarded;
    for (const user of plan.users || []) {
      const username = sanitizeUsername(user?.username || user?.id || '');
      if (!username) continue;
      const bonusId = serverTargetBonusId(summary.dateKey, username);
      const rewardId = serverTargetRewardId(summary.dateKey, username);
      const existing = await getDocFromServer(doc(db, 'manualBonuses', bonusId)).catch(() => null);
      const existingData = existing?.exists() ? (existing.data() || {}) : null;
      const existingActive = !!existingData && !isRecordDeleted(existingData);
      const role = normalizeRole(user.role || 'staff');
      let staffNotificationSent = false;
      const payload = {
        user: username,
        targetUsername: username,
        name: user.name || username,
        userRole: role,
        role,
        bonusGroup: 'staff',
        amount,
        dateKey: summary.dateKey,
        monthKey: summary.dateKey.slice(0, 7),
        type: 'daily_target_bonus',
        source: 'daily_target',
        note: 'Bonus target omzet harian tercapai',
        description: 'Bonus otomatis karena target omzet harian gabungan tercapai',
        action: 'add',
        deleted: false,
        createdAt: serverTimestamp(),
        createdAtMs: Date.now()
      };
      if (!existingActive) {
        await setDoc(doc(db, 'manualBonuses', bonusId), payload, { merge: false });
        upsertManualBonusRecord({ id: bonusId, ...payload });
        const notifyResult = await notifyStaffManualBonusFromServer({ id: bonusId, docId: bonusId, ...payload }, user);
        staffNotificationSent = !!notifyResult && notifyResult.ok !== false;
      } else {
        staffNotificationSent = await serverEnsureStaffTargetBonusNotification(summary, user, amount);
      }
      rewarded.push(username);
      await setDoc(doc(db, SERVER_TARGET_REWARDS_TABLE, rewardId), {
        id: rewardId,
        dateKey: summary.dateKey,
        user: username,
        targetUsername: username,
        amount,
        manualBonusId: bonusId,
        type: 'daily_target_bonus',
        source: 'daily_target',
        rewardedAt: serverTimestamp(),
        rewardedAtMs: Date.now(),
        ...(staffNotificationSent ? { staffNotificationSent: true, staffNotificationStatus: 'sent', staffNotifiedAt: serverTimestamp(), staffNotifiedAtMs: Date.now() } : {})
      }, { merge: true }).catch(() => {});
    }
    return rewarded;
  }
  async function serverSaveTargetStatus(summary, plan, extra = {}) {
    const current = cachedDailyTarget || {};
    const payload = {
      dateKey: summary.dateKey,
      targetAmount: summary.targetAmount,
      totalAmount: summary.totalAmount,
      progressPercent: summary.progressPercent,
      reached: summary.reached,
      reachedAt: summary.reached ? (current.reachedAt || serverTimestamp()) : null,
      reachedAtMs: summary.reached ? Number(current.reachedAtMs || Date.now()) : 0,
      bonusApplied: summary.reached ? Boolean(extra.bonusApplied ?? current.bonusApplied) : false,
      bonusAppliedAt: extra.bonusApplied ? (current.bonusAppliedAt || serverTimestamp()) : (current.bonusAppliedAt || null),
      bonusAppliedAtMs: extra.bonusApplied ? Number(current.bonusAppliedAtMs || Date.now()) : Number(current.bonusAppliedAtMs || 0),
      activeUsers: plan.activeUsers,
      rewardedUsers: extra.rewardedUsers || current.rewardedUsers || [],
      updatedAt: serverTimestamp(),
      updatedAtMs: Date.now()
    };
    cachedDailyTarget = { ...current, ...payload };
    try { await setDoc(doc(db, SERVER_DAILY_TARGETS_TABLE, serverTargetDocId(summary.dateKey)), payload, { merge: true }); }
    catch (e) { console.warn('daily target server gagal', e?.code || e?.message || e); }
  }
  async function serverEnsureTargetNotification(summary, plan) {
    const payload = {
      dateKey: summary.dateKey,
      type: 'daily_target_reached',
      title: 'Target omzet harian tercapai',
      message: `Target omzet harian sudah tercapai. Bonus target Rp ${formatRupiah(summary.bonusAmount)} otomatis masuk.`,
      targetAmount: summary.targetAmount,
      totalAmount: summary.totalAmount,
      bonusAmount: summary.bonusAmount,
      reachedAt: serverTimestamp(),
      reachedAtMs: Date.now(),
      read: false,
      createdAt: serverTimestamp(),
      createdAtMs: Date.now()
    };
    const inserted = await serverInsertIfAbsent(SERVER_TARGET_NOTIFICATIONS_TABLE, serverTargetNotifId(summary.dateKey), payload);
    if (inserted) {
      cachedTargetNotification = { id: serverTargetNotifId(summary.dateKey), ...payload };
      await serverNotifyTarget(summary, plan);
    }
  }
  async function serverApplyDailyTarget() {
    if (serverTargetApplying || !currentUser) return;
    serverTargetApplying = true;
    try {
      await serverLoadTargetSettings();
      const summary = serverDailyTargetSummary();
      const plan = serverTargetRewardPlan(summary.dateKey);
      const [targetSnap, notifSnap] = await Promise.all([
        getDocFromServer(doc(db, SERVER_DAILY_TARGETS_TABLE, serverTargetDocId(summary.dateKey))).catch(() => null),
        getDocFromServer(doc(db, SERVER_TARGET_NOTIFICATIONS_TABLE, serverTargetNotifId(summary.dateKey))).catch(() => null)
      ]);
      if (targetSnap?.exists()) cachedDailyTarget = targetSnap.data() || {};
      if (notifSnap?.exists()) cachedTargetNotification = { id: notifSnap.id, ...(notifSnap.data() || {}) };
      if (!summary.reached) {
        await revokeServerDailyTargetBonuses(summary, plan, cachedDailyTarget || {});
        return;
      }
      const amount = Number(summary.bonusAmount || 0);
      if (cachedDailyTarget?.bonusApplied === true) {
        const rewarded = await serverEnsureStaffTargetBonusNotifications(summary, plan, amount);
        const mergedRewarded = [...new Set([...(cachedDailyTarget.rewardedUsers || []).map(sanitizeUsername), ...rewarded.map(sanitizeUsername)].filter(Boolean))];
        await serverSaveTargetStatus(summary, plan, { bonusApplied: true, rewardedUsers: mergedRewarded });
        return;
      }
      await serverSaveTargetStatus(summary, plan, {});
      if (amount <= 0) return;
      const rewarded = await serverEnsureStaffTargetBonusNotifications(summary, plan, amount);
      await serverSaveTargetStatus(summary, plan, { bonusApplied: true, rewardedUsers: rewarded });
      await serverEnsureTargetNotification(summary, { ...plan, rewardedUsers: rewarded });
    } catch (e) {
      console.warn('server target harian gagal', e?.code || e?.message || e);
    } finally {
      serverTargetApplying = false;
      adminDashboardPanelsHash = '';
      renderAdminDashboardPanels();
    }
  }
  function serverScheduleDailyTargetCheck() {
    clearTimeout(serverTargetApplyTimer);
    serverTargetApplyTimer = setTimeout(() => serverApplyDailyTarget(), 700);
  }
  function renderServerDailyTargetCard(summary = serverDailyTargetSummary()) {
    const pct = Math.max(0, Math.min(100, summary.progressPercent || 0));
    const pctText = (Math.round((summary.progressPercent || 0) * 10) / 10).toLocaleString('id-ID');
    const reached = !!summary.reached;
    const unread = reached && cachedTargetNotification?.read === false;
    return `
      <div class="card page-in s2" style="padding:11px 12px;margin-bottom:8px;border-color:${reached ? 'rgba(82,216,158,.24)' : 'rgba(79,124,255,.22)'};background:linear-gradient(135deg,${reached ? 'var(--green-dim)' : 'var(--accent-dim)'},var(--bg2))">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px">
          <div style="min-width:0">
            <p class="label-xs" style="margin:0 0 4px;font-size:9px;color:${reached ? 'var(--green)' : 'var(--accent)'}">${reached ? 'Target omzet harian tercapai' : 'Target omzet harian'}</p>
            <p style="font-family:var(--num-font);font-size:21px;font-weight:900;color:var(--text);line-height:1">Rp ${formatRupiah(summary.totalAmount)}</p>
            <p style="font-size:10px;color:var(--text-soft);margin-top:5px;line-height:1.3">Target Rp ${formatRupiah(summary.targetAmount)} - Bonus Rp ${formatRupiah(summary.bonusAmount)} - Berlaku sejak ${formatDateLabel(summary.targetSettingDate)} - ${reached ? 'status tercapai' : 'sisa Rp ' + formatRupiah(summary.remainingAmount)}</p>
          </div>
          <span class="user-chip" style="font-size:10px;padding:3px 7px;color:${reached ? 'var(--green)' : 'var(--accent)'};background:${reached ? 'var(--green-dim)' : 'var(--accent-dim)'};white-space:nowrap">${unread ? 'Baru' : (reached ? 'Tercapai' : pctText + '%')}</span>
        </div>
        <div class="server-target-meter" style="--server-target-pct:${pct}%">
          <span class="server-target-meter-fill"></span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
          <button onclick="openServerDailyTargetSettings()" class="btn" style="width:100%;padding:9px 10px;font-size:11px"><i class="fas fa-sliders"></i> Atur Target</button>
          ${unread ? `<button onclick="markServerDailyTargetRead()" class="btn" style="width:100%;padding:9px 10px;font-size:11px;background:var(--green);color:#fff;border-color:var(--green)"><i class="fas fa-check"></i> Tandai dibaca</button>` : `<button onclick="manualRefreshData()" class="btn" style="width:100%;padding:9px 10px;font-size:11px"><i class="fas fa-rotate"></i> Refresh</button>`}
        </div>
      </div>`;
  }
  window.markServerDailyTargetRead = async function() {
    const dk = toDateKey(nowDate()), id = serverTargetNotifId(dk);
    try {
      await setDoc(doc(db, SERVER_TARGET_NOTIFICATIONS_TABLE, id), { read: true, readAt: serverTimestamp(), readAtMs: Date.now(), readBy: currentUser?.username || 'admin' }, { merge: true });
      cachedTargetNotification = { ...(cachedTargetNotification || {}), read: true };
      adminDashboardPanelsHash = '';
      renderAdminDashboardPanels();
    } catch (e) {
      showToast('Gagal tandai notifikasi target.', true);
    }
  };
  function parseServerTargetMoney(value) { return Number(String(value || '').replace(/[^0-9-]/g, '')) || 0; }
  function closeServerDailyTargetSettingsModal() {
    const old = document.getElementById('server-daily-target-settings-modal');
    if (old) old.remove();
  }
  window.closeServerDailyTargetSettingsModal = closeServerDailyTargetSettingsModal;
  window.openServerDailyTargetSettings = async function() {
    await serverLoadTargetSettings().catch((e) => console.warn('refresh jadwal target server gagal', e?.code || e?.message || e));
    const summary = serverDailyTargetSummary();
    closeServerDailyTargetSettingsModal();
    const wrap = document.createElement('div');
    wrap.id = 'server-daily-target-settings-modal';
    wrap.className = 'modal-wrap show';
    wrap.style.zIndex = '430';
    wrap.style.alignItems = 'center';
    wrap.style.justifyContent = 'center';
    wrap.innerHTML = `
      <div class="modal-sheet modal-sheet-wide" style="max-width:520px;border-radius:22px;padding:18px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
          <div style="min-width:0">
            <h3 style="font-size:15px;font-weight:900;letter-spacing:-.02em">Atur Target Harian</h3>
            <p style="font-size:10.5px;color:var(--text-soft);margin-top:3px">Bisa dijadwalkan untuk tanggal tertentu.</p>
          </div>
          <button onclick="closeServerDailyTargetSettingsModal()" class="btn btn-glass" style="width:36px;height:36px;padding:0;border-radius:12px"><i class="fas fa-xmark"></i></button>
        </div>
        <div style="display:grid;gap:10px">
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:12px 13px">
            <p class="label-xs">Tanggal Berlaku</p>
            <input id="serverTargetEffectiveDate" class="g-input" value="${escapeHtml(toDateKey(nowDate()))}" placeholder="Contoh: 21 atau ${escapeHtml(toDateKey(nowDate()))}" inputmode="numeric">
            <p style="font-size:10.5px;color:var(--text-soft);margin-top:6px;line-height:1.35">Isi 21 untuk tanggal 21 bulan ini. Jika tanggal belum tiba, target hari ini tetap memakai setting terakhir.</p>
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:12px 13px">
            <p class="label-xs">Target Omzet</p>
            <input id="serverTargetAmountInput" class="g-input" value="${escapeHtml(formatRupiah(summary.targetAmount))}" inputmode="numeric" placeholder="Target omzet">
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:12px 13px">
            <p class="label-xs">Bonus per Staff Hadir</p>
            <input id="serverTargetBonusInput" class="g-input" value="${escapeHtml(formatRupiah(summary.bonusAmount))}" inputmode="numeric" placeholder="Bonus target">
          </div>
          ${renderServerTargetScheduleList()}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:12px">
          <button onclick="closeServerDailyTargetSettingsModal()" class="btn btn-glass" style="padding:11px;font-size:12px">Batal</button>
          <button onclick="saveServerDailyTargetSettingsFromForm()" class="btn btn-primary" style="padding:11px;font-size:12px"><i class="fas fa-check"></i> Simpan</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    wrap.addEventListener('click', e => { if (e.target === wrap) closeServerDailyTargetSettingsModal(); });
    setTimeout(() => document.getElementById('serverTargetEffectiveDate')?.focus?.(), 80);
  };
  window.saveServerDailyTargetSettingsFromForm = async function() {
    const effectiveRaw = document.getElementById('serverTargetEffectiveDate')?.value || toDateKey(nowDate());
    const effectiveDate = serverNormalizeTargetDateKey(effectiveRaw, '');
    if (!effectiveDate) return showToast('Tanggal target tidak valid', true);
    const targetAmount = parseServerTargetMoney(document.getElementById('serverTargetAmountInput')?.value || '');
    const bonusAmount = parseServerTargetMoney(document.getElementById('serverTargetBonusInput')?.value || '');
    if (targetAmount <= 0) return showToast('Target harus lebih dari 0', true);
    if (bonusAmount < 0) return showToast('Bonus tidak boleh minus', true);
    const today = toDateKey(nowDate()), future = effectiveDate > today;
    const pin = await askPin(`Simpan target untuk ${effectiveDate}?\nTarget: Rp ${formatRupiah(targetAmount)}\nBonus staff hadir: Rp ${formatRupiah(bonusAmount)}\n${future ? '\nTarget hari ini tetap memakai setting terakhir sampai tanggal itu tiba.' : ''}\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const scheduleId = serverTargetSettingDocId(effectiveDate);
      const payload = {
        id: scheduleId,
        type: 'daily_target_setting',
        targetSettingType: 'daily_target',
        dateKey: effectiveDate,
        effectiveDate,
        targetAmount,
        bonusAmount,
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser?.username || 'admin',
        updatedByName: currentUser?.name || currentUser?.username || 'Admin'
      };
      await setDoc(doc(db, SERVER_TARGET_SETTINGS_TABLE, scheduleId), payload, { merge: true });
      if (effectiveDate === today) await setDoc(doc(db, SERVER_TARGET_SETTINGS_TABLE, 'daily_target'), { ...payload, id: 'daily_target' }, { merge: true });
      cachedDailyTarget = null;
      await serverApplyDailyTarget();
      adminDashboardPanelsHash = '';
      renderAdminDashboardPanels();
      closeServerDailyTargetSettingsModal();
      showToast(future ? `Target dijadwalkan untuk ${effectiveDate}` : 'Target dan bonus disimpan');
    } catch (e) {
      showToast('Gagal simpan target: ' + (e.code || e.message || 'cek koneksi'), true);
    }
    setLoading(false);
  };
  window.deleteServerTargetSchedule = async function(rawDate, rawId = '') {
    const effectiveDate = serverNormalizeTargetDateKey(rawDate, '');
    if (!effectiveDate) return showToast('Tanggal target tidak valid', true);
    const scheduleId = serverTargetSettingDocId(effectiveDate);
    const rowId = String(rawId || '').replace(/[^a-zA-Z0-9_-]/g, '');
    const pin = await askPin(`Hapus target untuk ${effectiveDate}?\nTanggal ini akan kembali mengikuti target terakhir sebelumnya.\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const ids = new Set([scheduleId]);
      if (rowId) ids.add(rowId);
      try {
        const snap = await getDocFromServer(doc(db, SERVER_TARGET_SETTINGS_TABLE, 'daily_target'));
        if (snap?.exists()) {
          const legacy = { id: 'daily_target', ...(snap.data() || {}) };
          const legacyDate = serverTargetSettingDate(legacy);
          if (rowId === 'daily_target' || legacyDate === effectiveDate || (!legacyDate && effectiveDate === toDateKey(nowDate()))) ids.add('daily_target');
        }
      } catch (_) {}
      for (const id of ids) if (id) await deleteDoc(doc(db, SERVER_TARGET_SETTINGS_TABLE, id));
      cachedTargetSettingRows = (cachedTargetSettingRows || []).filter((row) => !ids.has(String(row.id || '')));
      cachedTargetSettings = {};
      cachedDailyTarget = null;
      await serverLoadTargetSettings();
      const todayKey = toDateKey(nowDate());
      const active = serverPickTargetSettings(cachedTargetSettingRows || [], todayKey);
      if (active) {
        const legacy = {
          ...active,
          id: 'daily_target',
          updatedAt: serverTimestamp(),
          updatedAtMs: Date.now(),
          updatedBy: currentUser?.username || 'admin',
          updatedByName: currentUser?.name || currentUser?.username || 'Admin'
        };
        await setDoc(doc(db, SERVER_TARGET_SETTINGS_TABLE, 'daily_target'), legacy, { merge: true });
        cachedTargetSettings = active;
      } else {
        await deleteDoc(doc(db, SERVER_TARGET_SETTINGS_TABLE, 'daily_target')).catch(() => {});
        cachedTargetSettings = {};
      }
      await serverApplyDailyTarget();
      adminDashboardPanelsHash = '';
      renderAdminDashboardPanels();
      closeServerDailyTargetSettingsModal();
      showToast(`Target tanggal ${effectiveDate} dihapus`);
    } catch (e) {
      showToast('Gagal hapus target: ' + (e.code || e.message || 'cek koneksi'), true);
    }
    setLoading(false);
  };


  const getTheme = () => 'light';
  const applyTheme = (t) => { /* theme fixed - no dark mode */ };
  const toggleTheme = () => {
    const next = getTheme() === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    /* theme toggle disabled */
    document.querySelectorAll('input[type="date"].g-input').forEach(el => el.style.colorScheme = next);
  };
  /* theme is fixed, no dark mode */

  function nowDate() { return new Date(); }
  function getWIBDate(baseDate = new Date()) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    }).formatToParts(baseDate).reduce((acc, part) => {
      if (part.type !== 'literal') acc[part.type] = part.value;
      return acc;
    }, {});
    return {
      year: Number(parts.year),
      month: Number(parts.month),
      day: Number(parts.day),
      hour: Number(parts.hour),
      minute: Number(parts.minute),
      second: Number(parts.second)
    };
  }
  function getBusinessDateObject(baseDate = new Date()) {
    const wib = getWIBDate(baseDate);
    return new Date(Date.UTC(wib.year, wib.month - 1, wib.day));
  }
  function toDateKey(date = new Date()) {
    const wib = getWIBDate(date);
    const y = wib.year, m = String(wib.month).padStart(2,'0'), d = String(wib.day).padStart(2,'0');
    return `${y}-${m}-${d}`;
  }
  function toMonthKey(date = new Date()) {
    const wib = getWIBDate(date);
    const y = wib.year, m = String(wib.month).padStart(2,'0');
    return `${y}-${m}`;
  }
  function getBusinessYear(date = new Date()) {
    return String(getWIBDate(date).year);
  }
  function dateToTimeInput(date) {
    return new Intl.DateTimeFormat('id-ID', { dateStyle:'short', timeStyle:'medium', timeZone:'Asia/Jakarta' }).format(date);
  }
  function formatRupiah(n) { return new Intl.NumberFormat('id-ID').format(Number(n || 0)); }
  function formatDateLabel(key) {
    if (!key) return '-';
    const [y,m,d] = key.split('-').map(Number);
    return new Date(y, m-1, d).toLocaleDateString('id-ID', { day:'2-digit', month:'short', year:'numeric' });
  }
  function extractDateKey(item) {
    if (!item) return '';
    if (item.dateKey) return String(item.dateKey).slice(0, 10);
    if (typeof item.time === 'string' && item.time.length >= 10) return item.time.slice(0, 10);
    if (typeof item.createdAt === 'string' && item.createdAt.length >= 10) return item.createdAt.slice(0, 10);
    if (item.createdAt?.toDate) return toDateKey(item.createdAt.toDate());
    if (item.createdAtMs) return toDateKey(new Date(item.createdAtMs));
    return '';
  }
  function getRecordTimeMs(item) {
    if (!item) return 0;
    if (item.createdAt?.toDate) return item.createdAt.toDate().getTime();
    if (typeof item.createdAtMs === 'number' && Number.isFinite(item.createdAtMs)) return item.createdAtMs;
    if (typeof item.time === 'string') {
      const parsed = new Date(item.time.replace(' ', 'T') + '+07:20');
      if (!Number.isNaN(parsed.getTime())) return parsed.getTime();
    }
    if (typeof item.createdAt === 'string') {
      const parsed = new Date(item.createdAt.replace(' ', 'T') + '+07:20');
      if (!Number.isNaN(parsed.getTime())) return parsed.getTime();
    }
    return 0;
  }

  function getTransactionDateKey(item) {
    if (!item) return '';
    if (item.dateKey) return String(item.dateKey).slice(0, 10);
    return extractDateKey(item);
  }
  function getTransactionMonthKey(item) {
    if (!item) return '';
    if (item.monthKey) return String(item.monthKey).slice(0, 7);
    const dateKey = getTransactionDateKey(item);
    return dateKey ? dateKey.slice(0, 7) : '';
  }
  function sortByCreatedDesc(list) {
    return [...list].sort((a,b) => getRecordTimeMs(b) - getRecordTimeMs(a));
  }
  function getTransactionBonusRate() {
    const rate = Number(cachedBonusSettings?.transactionBonusRate);
    return Number.isFinite(rate) && rate >= 0 ? rate : DEFAULT_TRANSACTION_BONUS_RATE;
  }
  function getTransactionBonusPercent() {
    return Number((getTransactionBonusRate() * 100).toFixed(3));
  }
  function getClosingBonusPerMinute() {
    const amount = Number(cachedBonusSettings?.closingBonusPerMinute);
    return Number.isFinite(amount) && amount >= 0 ? amount : DEFAULT_CLOSING_BONUS_PER_MINUTE;
  }
  function getDefaultBonusSettings() {
    return {
      transactionBonusRate: DEFAULT_TRANSACTION_BONUS_RATE,
      transactionBonusPercent: Number((DEFAULT_TRANSACTION_BONUS_RATE * 100).toFixed(3)),
      closingBonusPerMinute: DEFAULT_CLOSING_BONUS_PER_MINUTE,
      closingDeadlineTime: DEFAULT_CLOSING_DEADLINE_TIME,
      closingDeadlineHour: DEFAULT_CLOSING_DEADLINE_HOUR,
      closingDeadlineMinute: DEFAULT_CLOSING_DEADLINE_MINUTE,
      closingDeadlineMinutes: (DEFAULT_CLOSING_DEADLINE_HOUR * 60) + DEFAULT_CLOSING_DEADLINE_MINUTE
    };
  }
  function normalizeClosingDeadlineParts(value = null, fallback = null) {
    const fb = fallback || { hour: DEFAULT_CLOSING_DEADLINE_HOUR, minute: DEFAULT_CLOSING_DEADLINE_MINUTE };
    if (value && typeof value === 'object') {
      const direct = value.deadlineTime ?? value.closingDeadlineTime ?? value.deadline ?? value.jamClosing ?? value.jam_closing ?? null;
      if (direct !== null && direct !== undefined && String(direct).trim() !== '') return normalizeClosingDeadlineParts(direct, fb);
      const rawHour = value.deadlineHour ?? value.closingDeadlineHour ?? value.hour ?? null;
      const rawMinute = value.deadlineMinute ?? value.closingDeadlineMinute ?? value.minute ?? null;
      const hour = Number(rawHour);
      const minute = Number(rawMinute);
      if (Number.isInteger(hour) && Number.isInteger(minute) && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) return { hour, minute };
      const total = Number(value.deadlineMinutes ?? value.closingDeadlineMinutes ?? NaN);
      if (Number.isFinite(total) && total >= 0) return { hour: Math.floor(total / 60) % 24, minute: Math.floor(total % 60) };
      return fb;
    }
    const raw = String(value ?? '').trim().replace('.', ':').replace(/\s*WIB$/i, '');
    const match = raw.match(/^(\d{1,2}):(\d{2})/);
    if (match) {
      const hour = Number(match[1]);
      const minute = Number(match[2]);
      if (Number.isInteger(hour) && Number.isInteger(minute) && hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) return { hour, minute };
    }
    return fb;
  }
  function getClosingDeadlineParts(source = null) {
    if (source && typeof source === 'object') {
      // Untuk data closing lama yang belum punya snapshot, fallback harus tetap 18:00
      // agar perubahan setting terbaru tidak mengubah hitungan/riwayat lama.
      return normalizeClosingDeadlineParts(source, { hour: DEFAULT_CLOSING_DEADLINE_HOUR, minute: DEFAULT_CLOSING_DEADLINE_MINUTE });
    }
    return normalizeClosingDeadlineParts(cachedBonusSettings || {}, { hour: DEFAULT_CLOSING_DEADLINE_HOUR, minute: DEFAULT_CLOSING_DEADLINE_MINUTE });
  }
  function getClosingDeadlineTimeLabel(source = null) {
    const parts = getClosingDeadlineParts(source);
    return `${String(parts.hour).padStart(2,'0')}:${String(parts.minute).padStart(2,'0')}`;
  }
  function getClosingDeadlineMinutes(source = null) {
    const parts = getClosingDeadlineParts(source);
    return (parts.hour * 60) + parts.minute;
  }
  function getClosingDeadlineSnapshot(source = null) {
    const parts = getClosingDeadlineParts(source);
    const label = `${String(parts.hour).padStart(2,'0')}:${String(parts.minute).padStart(2,'0')}`;
    return {
      deadline: `${label} WIB`,
      deadlineTime: label,
      deadlineHour: parts.hour,
      deadlineMinute: parts.minute,
      deadlineMinutes: (parts.hour * 60) + parts.minute,
      closingDeadlineTime: label,
      closingDeadlineHour: parts.hour,
      closingDeadlineMinute: parts.minute,
      closingDeadlineMinutes: (parts.hour * 60) + parts.minute
    };
  }
  function normalizeBonusSettings(data = {}) {
    const defaults = getDefaultBonusSettings();
    const parts = normalizeClosingDeadlineParts(data || {}, { hour: DEFAULT_CLOSING_DEADLINE_HOUR, minute: DEFAULT_CLOSING_DEADLINE_MINUTE });
    const deadlineLabel = `${String(parts.hour).padStart(2,'0')}:${String(parts.minute).padStart(2,'0')}`;
    const trxRate = Number.isFinite(Number(data.transactionBonusRate)) ? Number(data.transactionBonusRate) : defaults.transactionBonusRate;
    const trxPercent = Number.isFinite(Number(data.transactionBonusPercent)) ? Number(data.transactionBonusPercent) : Number((trxRate * 100).toFixed(3));
    const closingPerMinute = Number.isFinite(Number(data.closingBonusPerMinute)) ? Number(data.closingBonusPerMinute) : defaults.closingBonusPerMinute;
    return {
      transactionBonusRate: trxRate,
      transactionBonusPercent: trxPercent,
      closingBonusPerMinute: closingPerMinute,
      closingDeadlineTime: deadlineLabel,
      closingDeadlineHour: parts.hour,
      closingDeadlineMinute: parts.minute,
      closingDeadlineMinutes: (parts.hour * 60) + parts.minute,
      updatedAtMs: Number(data.updatedAtMs || 0),
      updatedBy: data.updatedBy || '',
      updatedByName: data.updatedByName || ''
    };
  }
  function calculateDistance(la1,lo1,la2,lo2){const R=6371e3,dL=(la2-la1)*Math.PI/180,dO=(lo2-lo1)*Math.PI/180,a=Math.sin(dL/2)**2+Math.cos(la1*Math.PI/180)*Math.cos(la2*Math.PI/180)*Math.sin(dO/2)**2;return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));}
  function isDailyEmployee(userOrUsername) {
    const user = typeof userOrUsername === 'object' ? userOrUsername : getUserByUsername(userOrUsername);
    return !!user && isDailyRole(user.role || 'staff');
  }
  function hasBonusValue(value) {
    return value !== undefined && value !== null && String(value).trim() !== '';
  }
  function getUserTransactionBonusRate(username) {
    const user = typeof username === 'object'
      ? username
      : (getUserByUsername(username) || (sanitizeUsername(currentUser?.username) === sanitizeUsername(username) ? currentUser : null));
    if (user) {
      if (hasBonusValue(user.transactionBonusRate)) {
        const customRate = Number(user.transactionBonusRate);
        if (Number.isFinite(customRate) && customRate >= 0) return customRate;
      }
      if (hasBonusValue(user.transactionBonusPercent)) {
        const customPercent = Number(user.transactionBonusPercent);
        if (Number.isFinite(customPercent) && customPercent >= 0) return customPercent / 100;
      }
      // Kompatibilitas data lama: karyawan harian versi sebelumnya memakai dailyBonus*.
      if (isDailyEmployee(user)) {
        const customRate = Number(user?.dailyBonusRate);
        if (Number.isFinite(customRate) && customRate >= 0) return customRate;
        const customPercent = Number(user?.dailyBonusPercent);
        if (Number.isFinite(customPercent) && customPercent >= 0) return customPercent / 100;
      }
    }
    return getTransactionBonusRate();
  }
  function getUserTransactionBonusPercent(username) {
    return Number((getUserTransactionBonusRate(username) * 100).toFixed(3));
  }
  function getUserClosingBonusPerMinute(username) {
    const user = typeof username === 'object'
      ? username
      : (getUserByUsername(username) || (sanitizeUsername(currentUser?.username) === sanitizeUsername(username) ? currentUser : null));
    if (user && isDailyEmployee(user)) return 0;
    if (user && hasBonusValue(user.closingBonusPerMinute)) {
      const customClosing = Number(user.closingBonusPerMinute);
      if (Number.isFinite(customClosing) && customClosing >= 0) return customClosing;
    }
    return getClosingBonusPerMinute();
  }
  function getUserBonusSnapshot(username) {
    const rate = getUserTransactionBonusRate(username);
    const closingPerMinute = getUserClosingBonusPerMinute(username);
    return {
      transactionBonusRate: rate,
      transactionBonusPercent: Number((rate * 100).toFixed(3)),
      closingBonusPerMinute: closingPerMinute
    };
  }
  function upsertCachedUserFromServer(username, data = {}) {
    const safeUsername = sanitizeUsername(data.username || username || '');
    if (!safeUsername) return null;
    const role = normalizeRole(data.role || 'staff');
    const record = {
      id: safeUsername,
      ...data,
      username: safeUsername,
      name: data.name || safeUsername,
      pin: String(data.pin ?? ''),
      role,
      transactionBonusRate: data.transactionBonusRate ?? (isDailyRole(role) ? data.dailyBonusRate : null),
      transactionBonusPercent: data.transactionBonusPercent ?? (isDailyRole(role) ? data.dailyBonusPercent : null),
      closingBonusPerMinute: isDailyRole(role) ? 0 : (data.closingBonusPerMinute ?? null),
      dailyBonusRate: Number(data.dailyBonusRate || 0),
      dailyBonusPercent: Number(data.dailyBonusPercent || 0),
      active: data.active !== false,
      deleted: data.deleted === true || data.deleted === 'true'
    };
    const idx = cachedUsers.findIndex(u => sanitizeUsername(u.username) === safeUsername);
    if (idx >= 0) cachedUsers[idx] = { ...cachedUsers[idx], ...record };
    else cachedUsers.push(record);
    return record;
  }

  async function fetchLatestBonusBeforeTransaction(username) {
    const safeUsername = sanitizeUsername(username || currentUser?.username || '');
    if (!safeUsername) throw new Error('User transaksi tidak valid');
    const userRef = doc(db, 'users', safeUsername);
    const bonusRef = doc(db, 'closings', '__bonus_settings');
    const [userSnap, bonusSnap] = await Promise.all([
      getDocFromServer(userRef),
      getDocFromServer(bonusRef).catch(() => null)
    ]);
    if (bonusSnap?.exists()) {
      const data = bonusSnap.data() || {};
      cachedBonusSettings = normalizeBonusSettings(data);
    }
    if (!userSnap.exists()) throw new Error('User tidak ditemukan saat cek bonus');
    const data = userSnap.data() || {};
    const freshUser = upsertCachedUserFromServer(userSnap.id, data);
    if (!freshUser || !isUserActive(freshUser)) throw new Error('User nonaktif saat cek bonus');
    if (sanitizeUsername(currentUser?.username) === safeUsername) {
      currentUser = {
        ...currentUser,
        username: freshUser.username,
        name: freshUser.name,
        role: freshUser.role || 'staff',
        transactionBonusRate: freshUser.transactionBonusRate,
        transactionBonusPercent: freshUser.transactionBonusPercent,
        closingBonusPerMinute: isDailyEmployee(freshUser) ? 0 : freshUser.closingBonusPerMinute,
        dailyBonusRate: Number(freshUser.dailyBonusRate || 0),
        dailyBonusPercent: Number(freshUser.dailyBonusPercent || 0),
        active: freshUser.active !== false
      };
      try { persistCurrentSession(); } catch (_) {}
    }
    return { user: freshUser, snapshot: getUserBonusSnapshot(freshUser) };
  }
  function getTodayTransactionsForUser(username, dateKey = toDateKey(nowDate())) {
    const target = sanitizeUsername(username || '');
    if (!target) return [];
    return getVisibleTransactions().filter(t => sanitizeUsername(t.user) === target && getTransactionDateKey(t) === dateKey);
  }
  function getDailyEmployeeTodaySalary(username, dateKey = toDateKey(nowDate())) {
    const items = getTodayTransactionsForUser(username, dateKey).filter(isDailyTransactionRecord);
    const income = items.reduce((sum, t) => sum + Number(t.amount || 0), 0);
    const rate = getUserTransactionBonusRate(username);
    const salary = calculateTransactionBonusForList(items);
    return { items, income, rate, percent: Number((rate * 100).toFixed(3)), salary };
  }
  function calculateTransactionBonusForList(list = []) {
    const total = (list || []).reduce((sum, t) => {
      const rate = getTransactionBonusRateForRecord(t);
      return sum + (Number(t.amount || 0) * rate);
    }, 0);
    return Math.round(total);
  }
  function calculateBonus(o) { return Math.round(Number(o || 0) * getTransactionBonusRate()); }

  async function saveBonusSettings() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const trxPercentRaw = String($('bonus-trx-percent')?.value || '').replace(',', '.').trim();
    const closingRaw = String($('bonus-closing-minute')?.value || '').replace(/\D/g, '').trim();
    const trxPercent = Number(trxPercentRaw);
    const closingPerMinute = Number(closingRaw);
    if (!Number.isFinite(trxPercent) || trxPercent < 0 || trxPercent > 100) return showToast('Persen bonus transaksi tidak valid', true);
    if (!Number.isFinite(closingPerMinute) || closingPerMinute < 0) return showToast('Bonus closing per menit tidak valid', true);
    const pin = await askPin('Simpan kontrol bonus?\nMasukkan PIN admin:');
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const payload = {
        transactionBonusRate: trxPercent / 100,
        transactionBonusPercent: trxPercent,
        closingBonusPerMinute: closingPerMinute,
        ...getClosingDeadlineSnapshot(),
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, 'closings', '__bonus_settings'), {
        ...payload,
        id: '__bonus_settings',
        dateKey: '__bonus_settings',
        closed: false,
        type: 'bonus_settings'
      }, { merge: true });
      cachedBonusSettings = { ...cachedBonusSettings, ...payload };
      await logAudit('bonus_settings_update', { transactionBonusPercent: trxPercent, closingBonusPerMinute: closingPerMinute });
      showToast('✓ Kontrol bonus disimpan');
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan kontrol bonus: ' + (e.code || e.message || 'cek Supabase'), true);
    }
    setLoading(false);
  }

  function resetBonusSettingsForm() {
    const trx = $('bonus-trx-percent');
    const closing = $('bonus-closing-minute');
    if (trx) trx.value = String(getTransactionBonusPercent());
    if (closing) closing.value = String(getClosingBonusPerMinute());
  }

  function renderBonusControlCard() {
    const trxPercent = getTransactionBonusPercent();
    const closingPerMinute = getClosingBonusPerMinute();
    const updatedLabel = cachedBonusSettings?.updatedAtMs ? new Date(Number(cachedBonusSettings.updatedAtMs)).toLocaleString('id-ID', { timeZone:'Asia/Jakarta' }) : 'Default sistem';
    return `
      <div class="card" style="padding:14px 16px;margin-top:12px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px">
          <div>
            <p class="label-xs" style="margin:0">Kontrol Bonus</p>
            <p style="font-size:11px;color:var(--text-soft);margin-top:4px">Default untuk user yang belum punya setting khusus. Kontrol utama tetap di form User per orang.</p>
          </div>
          <span class="status-pill status-ok">Admin</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px">
          <div>
            <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Bonus Transaksi (%)</label>
            <input id="bonus-trx-percent" type="text" inputmode="decimal" class="g-input" value="${escapeHtml(trxPercent)}" placeholder="Contoh 1.5" />
          </div>
          <div>
            <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Bonus Closing / Menit</label>
            <input id="bonus-closing-minute" type="text" inputmode="numeric" class="g-input" value="${escapeHtml(closingPerMinute)}" placeholder="Contoh 100" />
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
          <button onclick="saveBonusSettings()" class="btn btn-primary" style="padding:12px;font-size:12px"><i class="fas fa-floppy-disk"></i> Simpan Default</button>
          <button onclick="resetBonusSettingsForm()" class="btn btn-glass" style="padding:12px;font-size:12px"><i class="fas fa-rotate-left"></i> Reset Form</button>
        </div>
        <div style="margin-top:10px;padding:10px 11px;border:1px solid var(--border);border-radius:12px;background:var(--surface)">
          <div style="display:flex;justify-content:space-between;gap:10px;font-size:11px;color:var(--text-soft)"><span>Bonus transaksi aktif</span><strong style="color:var(--text)">${trxPercent}%</strong></div>
          <div style="display:flex;justify-content:space-between;gap:10px;font-size:11px;color:var(--text-soft);margin-top:5px"><span>Bonus closing aktif</span><strong style="color:var(--text)">Rp ${formatRupiah(closingPerMinute)} / menit</strong></div>
          <div style="font-size:10.5px;color:var(--text-ghost);margin-top:7px">Update: ${escapeHtml(updatedLabel)}${cachedBonusSettings?.updatedByName ? ` · ${escapeHtml(cachedBonusSettings.updatedByName)}` : ''}</div>
        </div>
      </div>`;
  }


  async function saveClosingDeadlineSettings() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const raw = String($('closing-deadline-time')?.value || '').trim();
    const parsed = parseClosingTimeInput(raw);
    if (!parsed) return showToast('Format jam closing tidak valid. Pakai HH:MM, contoh 19:00', true);
    const oldLabel = getClosingDeadlineTimeLabel();
    if (parsed.label === oldLabel) return showToast('Jam closing masih sama');
    const pin = await askPin(`Ubah jam closing default dari ${oldLabel} ke ${parsed.label} WIB?

Catatan: ini hanya berlaku untuk closing baru. Bonus closing lama tetap pakai snapshot deadline masing-masing.

Masukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const payload = {
        ...getClosingDeadlineSnapshot(parsed),
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, 'closings', '__bonus_settings'), {
        ...payload,
        id: '__bonus_settings',
        dateKey: '__bonus_settings',
        closed: false,
        type: 'bonus_settings'
      }, { merge: true });
      cachedBonusSettings = normalizeBonusSettings({ ...cachedBonusSettings, ...payload });
      await logAudit('closing_deadline_update', { oldDeadlineTime: oldLabel, closingDeadlineTime: parsed.label, closingDeadlineMinutes: (parsed.hour * 60) + parsed.minute });
      showToast(`✓ Jam closing default: ${parsed.label} WIB`);
      adminClosingPanelHash = '';
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan jam closing: ' + (e.code || e.message || 'cek Supabase'), true);
    }
    setLoading(false);
  }

  function resetClosingDeadlineForm() {
    const input = $('closing-deadline-time');
    if (input) input.value = getClosingDeadlineTimeLabel();
  }

  function renderClosingDeadlineSettingsCard() {
    const deadlineLabel = getClosingDeadlineTimeLabel();
    const updatedLabel = cachedBonusSettings?.updatedAtMs ? new Date(Number(cachedBonusSettings.updatedAtMs)).toLocaleString('id-ID', { timeZone:'Asia/Jakarta' }) : 'Default sistem';
    return `<div class="card" style="padding:14px 16px;margin-bottom:10px;border-color:rgba(211,107,53,.18)!important;background:linear-gradient(135deg,#fdf9f4 0%,#f7f2ea 100%)!important">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:10px">
        <div style="min-width:0;flex:1">
          <p class="label-xs" style="margin:0 0 6px;color:var(--accent)">Pengaturan Jam Closing</p>
          <div style="font-size:15px;font-weight:900;letter-spacing:-.02em;line-height:1.2">Deadline default ${escapeHtml(deadlineLabel)} WIB</div>
          <div style="font-size:10.8px;color:var(--text-soft);margin-top:5px;line-height:1.35">Perubahan jam ini hanya untuk closing baru. Closing lama tetap pakai snapshot deadline yang tersimpan.</div>
        </div>
        <span class="status-pill status-ok" style="font-size:10px;padding:6px 10px;white-space:nowrap"><i class="fas fa-clock"></i> Aktif</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr;gap:8px">
        <div>
          <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Jam Closing</label>
          <input id="closing-deadline-time" type="time" class="g-input" value="${escapeHtml(deadlineLabel)}" style="font-family:var(--num-font);font-weight:800" />
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button onclick="saveClosingDeadlineSettings()" class="btn btn-primary" style="padding:11px 12px;font-size:12px"><i class="fas fa-floppy-disk"></i> Simpan Jam</button>
          <button onclick="resetClosingDeadlineForm()" class="btn btn-glass" style="padding:11px 12px;font-size:12px"><i class="fas fa-rotate-left"></i> Reset</button>
        </div>
      </div>
      <div style="font-size:10px;color:var(--text-ghost);margin-top:8px;line-height:1.35">Update setting: ${escapeHtml(updatedLabel)}${cachedBonusSettings?.updatedByName ? ` · ${escapeHtml(cachedBonusSettings.updatedByName)}` : ''}</div>
    </div>`;
  }




  function getManualBonusDefaultUser() {
    const selected = selectedUserFilter !== 'all' ? sanitizeUsername(selectedUserFilter) : '';
    if (selected && isManualBonusUser(selected)) return selected;
    return getManualBonusUsers()[0]?.username || '';
  }

  function renderManualBonusCard() {
    const month = toMonthKey(nowDate());
    const defaultUser = getManualBonusDefaultUser();
    const manualBonusUsers = getManualBonusUsers();
    const options = manualBonusUsers.map(u => {
      const role = normalizeRole(u.role || 'staff');
      const label = role === 'harian' ? 'HARIAN' : 'STAFF';
      return `<option value="${escapeHtml(u.username)}" ${sanitizeUsername(u.username) === sanitizeUsername(defaultUser) ? 'selected' : ''}>${escapeHtml(u.name || u.username)} (@${escapeHtml(u.username)}) · ${label}</option>`;
    }).join('');
    const monthBonusRows = getMonthlyManualBonuses(null, month);
    const allRows = monthBonusRows.filter(b => !isTargetAutoBonusRow(b));
    const autoRows = monthBonusRows.filter(isTargetAutoBonusRow).slice(0, 30);
    const autoTotal = autoRows.reduce((sum, b) => sum + Number(b.amount || 0), 0);
    const rows = allRows.slice(0, 30);
    const totalManual = allRows.reduce((sum, b) => sum + Number(b.amount || 0), 0);
    const rowsInfo = allRows.length > rows.length ? `Tampil ${rows.length} terbaru dari ${allRows.length} data` : `${rows.length} data`;
    const totalColor = totalManual < 0 ? 'var(--red)' : 'var(--amber)';
    return `<div class="card" style="padding:14px 16px;background:var(--surface);border-color:rgba(255,196,107,.16)">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:12px">
        <div>
          <p class="label-xs" style="margin:0;color:var(--amber)">Bonus Manual</p>
          <p style="font-size:11px;color:var(--text-soft);margin-top:4px">Admin bisa tambah, kurangi, atau hapus catatan bonus manual untuk Staff dan Karyawan Harian. Nilainya ikut masuk perhitungan bulan berjalan.</p>
        </div>
        <span class="status-pill status-ok" style="color:${totalColor}">Rp ${formatRupiah(totalManual)}</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">
        <div>
          <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Pilih User</label>
          <select id="manual-bonus-user" class="g-input">${options || '<option value="">Belum ada staff/harian aktif</option>'}</select>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div>
            <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Aksi Bonus</label>
            <select id="manual-bonus-mode" class="g-input">
              <option value="add">Tambah Bonus (+)</option>
              <option value="subtract">Kurangi Bonus (-)</option>
            </select>
          </div>
          <div>
            <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Bulan Bonus</label>
            <input id="manual-bonus-month" type="month" class="g-input" value="${month}" />
          </div>
        </div>
        <div>
          <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Nominal</label>
          <input id="manual-bonus-amount" type="tel" inputmode="numeric" pattern="[0-9]*" class="g-input" placeholder="Contoh 50000" data-numeric="0" oninput="formatMoneyInputElement(this)" />
        </div>
        <div>
          <label style="font-size:10px;color:var(--text-ghost);font-weight:800;text-transform:uppercase;margin-bottom:6px;display:block">Keterangan</label>
          <input id="manual-bonus-note" type="text" class="g-input" placeholder="Contoh: bonus tambahan / koreksi bonus" />
        </div>
        <button onclick="saveManualBonus()" class="btn btn-primary" style="padding:12px;font-size:12px"><i class="fas fa-floppy-disk"></i> Simpan Bonus Manual</button>
      </div>
      <div style="margin-top:13px;border-top:1px solid var(--border);padding-top:11px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px">
          <p class="label-xs" style="margin:0">Riwayat Bonus Manual Bulan Ini</p>
          <span style="font-size:10.5px;color:var(--text-soft)">${rowsInfo}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px;max-height:220px;overflow-y:auto;overscroll-behavior:contain;padding-right:2px">
          ${rows.length ? rows.map(b => {
            const signedAmount = Number(b.amount || 0);
            const isMinus = signedAmount < 0;
            const absAmount = Math.abs(signedAmount);
            const actionLabel = isMinus ? 'Pengurang bonus' : 'Tambah bonus';
            const actionColor = isMinus ? 'var(--red)' : 'var(--amber)';
            const rowId = escapeHtml(b.id || '');
            const roleLabel = getRoleDisplayName(b.userRole || b.role || getReportUserRole(b.user, 'staff'));
            return `<div style="display:flex;justify-content:space-between;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:11px;background:var(--bg2);align-items:center">
              <div style="min-width:0;flex:1">
                <div style="font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(b.name || b.user || '-')}</div>
                <div style="font-size:10px;color:var(--text-soft);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(b.note || actionLabel)} · ${escapeHtml(b.monthKey || '-')} · ${escapeHtml(roleLabel)}</div>
                <div style="font-size:9.5px;color:${actionColor};font-weight:800;margin-top:4px">${actionLabel}</div>
              </div>
              <div style="display:flex;align-items:center;gap:7px;flex-shrink:0">
                <strong style="font-family:var(--num-font);font-size:13px;color:${actionColor}">${isMinus ? '-' : '+'} Rp ${formatRupiah(absAmount)}</strong>
                ${rowId ? `<button onclick="deleteManualBonus('${rowId}')" class="btn btn-danger" title="Hapus bonus manual" style="width:30px;height:30px;padding:0;border-radius:9px"><i class="fas fa-trash"></i></button>` : ''}
              </div>
            </div>`;
          }).join('') : `<div style="font-size:11px;color:var(--text-soft);padding:9px 10px;border:1px dashed var(--border);border-radius:11px">Belum ada bonus manual bulan ini.</div>`}
        </div>
      </div>
      <div style="margin-top:13px;border-top:1px solid var(--border);padding-top:11px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px">
          <div>
            <p class="label-xs" style="margin:0;color:var(--green)">Bonus Target Otomatis</p>
            <p style="font-size:10.5px;color:var(--text-soft);margin-top:3px">Dibuat otomatis saat target omzet tercapai. Hapus di sini untuk reset bonus target staff terkait.</p>
          </div>
          <span class="status-pill status-ok" style="color:var(--green)">Rp ${formatRupiah(autoTotal)}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px;max-height:220px;overflow-y:auto;overscroll-behavior:contain;padding-right:2px">
          ${autoRows.length ? autoRows.map(b => {
            const amount = Number(b.amount || 0);
            const rowId = escapeHtml(b.id || '');
            return `<div style="display:flex;justify-content:space-between;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:11px;background:var(--bg2);align-items:center">
              <div style="min-width:0;flex:1">
                <div style="font-size:12px;font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(b.name || b.user || '-')}</div>
                <div style="font-size:10px;color:var(--text-soft);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(b.note || 'Bonus target omzet harian tercapai')} Â· ${escapeHtml(b.dateKey || '-')}</div>
                <div style="font-size:9.5px;color:var(--green);font-weight:800;margin-top:4px">Bonus otomatis target</div>
              </div>
              <div style="display:flex;align-items:center;gap:7px;flex-shrink:0">
                <strong style="font-family:var(--num-font);font-size:13px;color:var(--green)">+ Rp ${formatRupiah(amount)}</strong>
                ${rowId ? `<button onclick="deleteManualBonus('${rowId}')" class="btn btn-danger" title="Reset bonus target otomatis" style="width:30px;height:30px;padding:0;border-radius:9px"><i class="fas fa-trash"></i></button>` : ''}
              </div>
            </div>`;
          }).join('') : `<div style="font-size:11px;color:var(--text-soft);padding:9px 10px;border:1px dashed var(--border);border-radius:11px">Belum ada bonus target otomatis bulan ini.</div>`}
        </div>
      </div>
    </div>`;
  }

  async function saveManualBonus() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy || manualBonusSaveInFlight) return showToast('Bonus manual sedang diproses...', true);
    manualBonusSaveInFlight = true;
    let loadingShown = false;
    try {
      const username = sanitizeUsername($('manual-bonus-user')?.value || '');
      const user = getUserByUsername(username);
      const mode = String($('manual-bonus-mode')?.value || 'add');
      const amountRaw = $('manual-bonus-amount')?.getAttribute('data-numeric') || String($('manual-bonus-amount')?.value || '').replace(/\D/g, '');
      const baseAmount = parseInt(amountRaw || '0', 10);
      const amount = mode === 'subtract' ? -baseAmount : baseAmount;
      const monthKey = String($('manual-bonus-month')?.value || toMonthKey(nowDate())).slice(0, 7);
      const defaultNote = mode === 'subtract' ? 'Pengurang bonus manual admin' : 'Bonus manual admin';
      const note = String($('manual-bonus-note')?.value || '').trim() || defaultNote;
      if (!username || !user) return showToast('Pilih user dulu!', true);
      if (!isManualBonusUser(user)) return showToast('Bonus manual hanya untuk Staff/Karyawan Harian aktif.', true);
      const role = normalizeRole(user.role || 'staff');
      const trialFlags = getTrialFlags(user);
      if (!baseAmount || baseAmount <= 0) return showToast('Nominal bonus tidak valid!', true);
      if (!/^\d{4}-\d{2}$/.test(monthKey)) return showToast('Bulan bonus tidak valid!', true);
      const actionText = mode === 'subtract' ? 'Kurangi' : 'Tambahkan';
      const pin = await askPin(`${actionText} bonus manual untuk ${user.name || username}?
Role: ${getRoleDisplayName(role)}
Nominal: ${mode === 'subtract' ? '-' : '+'} Rp ${formatRupiah(baseAmount)}
Bulan: ${monthKey}

Masukkan PIN admin:`);
      if (!pin) return;
      if (!(await requireCurrentAdminPin(pin))) return;

      const submitNow = Date.now();
      const submitSignature = [username, mode, amount, monthKey, note, currentUser.username].join('|');
      if (submitSignature === lastManualBonusSubmitSignature && submitNow - lastManualBonusSubmitAt < 5000) {
        return showToast('Bonus manual yang sama baru saja disimpan, dicegah supaya tidak dobel.', true);
      }
      lastManualBonusSubmitSignature = submitSignature;
      lastManualBonusSubmitAt = submitNow;

      setLoading(true);
      loadingShown = true;
      const now = nowDate();
      const clientRequestId = `mb_${sanitizeUsername(currentUser.username)}_${submitNow}_${Math.random().toString(36).slice(2, 8)}`;
      const payload = {
        user: username,
        name: user.name || username,
        userRole: role,
        role,
        bonusGroup: role,
        amount,
        note,
        monthKey,
        dateKey: toDateKey(now),
        time: dateToTimeInput(now),
        type: mode === 'subtract' ? 'manual_bonus_subtract' : 'manual_bonus_add',
        action: mode === 'subtract' ? 'subtract' : 'add',
        ...trialFlags,
        deleted: false,
        createdAt: serverTimestamp(),
        createdAtMs: submitNow,
        createdBy: currentUser.username,
        createdByName: currentUser.name,
        clientRequestId
      };
      const ref = await addDoc(collection(db, 'manualBonuses'), payload);
      const savedManualBonus = { id: ref.id, ...payload };
      upsertManualBonusRecord(savedManualBonus);
      await logAudit(mode === 'subtract' ? 'manual_bonus_subtract' : 'manual_bonus_add', { id: ref.id, user: username, name: user.name || username, role, amount, monthKey, note });
      await notifyStaffManualBonusFromServer(savedManualBonus, user);
      const amountInput = $('manual-bonus-amount');
      const noteInput = $('manual-bonus-note');
      if (amountInput) { amountInput.value = ''; amountInput.setAttribute('data-numeric', '0'); }
      if (noteInput) noteInput.value = '';
      showToast(`✓ ${actionText} bonus ${user.name || username}: ${mode === 'subtract' ? '-' : '+'} Rp ${formatRupiah(baseAmount)}`);
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan bonus manual: ' + (e.code || e.message || 'cek Supabase'), true);
    } finally {
      if (loadingShown) setLoading(false);
      manualBonusSaveInFlight = false;
    }
  }

  async function deleteManualBonus(id) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const bonusId = String(id || '').trim();
    if (!bonusId) return showToast('Data bonus tidak valid!', true);
    const item = (cachedManualBonuses || []).find(b => String(b.id) === bonusId);
    if (!item) return showToast('Data bonus tidak ditemukan!', true);
    const amount = Number(item.amount || 0);
    const autoTarget = isTargetAutoBonusRow(item);
    const pin = await askPin(`Hapus catatan ${autoTarget ? 'bonus target otomatis' : 'bonus manual'} ${item.name || item.user || ''}?\nNilai: ${amount < 0 ? '-' : '+'} Rp ${formatRupiah(Math.abs(amount))}\nBulan: ${item.monthKey || '-'}\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm('Catatan bonus ini akan dihapus dari perhitungan Bonus ++. Lanjutkan?')) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'manualBonuses', bonusId), {
        deleted: true,
        deletedAt: serverTimestamp(),
        deletedAtMs: Date.now(),
        deletedBy: currentUser.username,
        deletedByName: currentUser.name
      }, { merge: true });
      if (autoTarget) await resetServerTargetAutoBonusAfterDelete(item);
      cachedManualBonuses = dedupeManualBonusRecords(cachedManualBonuses.map(b => String(b.id) === bonusId ? { ...b, deleted: true, deletedAtMs: Date.now(), deletedBy: currentUser.username, deletedByName: currentUser.name } : b));
      await logAudit('manual_bonus_delete', { id: bonusId, user: item.user || '', name: item.name || '', amount, monthKey: item.monthKey || '', note: item.note || '' });
      showToast('✓ Bonus manual dihapus dari perhitungan');
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus bonus manual: ' + (e.code || e.message || 'cek Supabase'), true);
    }
    setLoading(false);
  }

  function getClosingCanceledUsersMap(closing) {
    const raw = closing?.canceledUsers || closing?.canceledByUser || {};
    if (Array.isArray(raw)) return raw.reduce((acc, u) => { const key = sanitizeUsername(u); if (key) acc[key] = true; return acc; }, {});
    return raw && typeof raw === 'object' ? raw : {};
  }
  function isClosingCanceledForUser(closing, username) {
    const u = sanitizeUsername(username || '');
    if (!closing || !u) return false;
    const canceled = getClosingCanceledUsersMap(closing);
    const value = canceled[u];
    return value === true || value === 'true' || !!(value && typeof value === 'object' && value.canceled !== false);
  }
  function getTodayClosing(username = null) {
    const today = toDateKey(nowDate());
    const userKey = username ? sanitizeUsername(username) : null;
    return cachedClosings.find(c => {
      if (!c || c.dateKey !== today || c.closed !== true) return false;
      if (c.type === 'bonus_settings' || c.id === '__bonus_settings' || c.dateKey === '__bonus_settings') return false;
      const scope = c.scope || (c.user ? 'user' : 'global');
      if (!userKey) return scope === 'global' || !c.user;
      return scope === 'user' && sanitizeUsername(c.user) === userKey;
    }) || null;
  }
  function getTodayGlobalClosing() {
    return getTodayClosing(null);
  }
  function getTodayGlobalClosingForUser(username = currentUser?.username) {
    const globalClosing = getTodayGlobalClosing();
    return globalClosing && !isClosingCanceledForUser(globalClosing, username) ? globalClosing : null;
  }
  function getTodayUserClosing(username = currentUser?.username) {
    return getTodayClosing(username);
  }
  function isTransactionsClosedToday(username = currentUser?.username) {
    if (isAdmin()) return false;
    return !!getTodayUserClosing(username) || !!getTodayGlobalClosingForUser(username);
  }
  function isUserClosedToday(username) {
    return !!getTodayUserClosing(username) || !!getTodayGlobalClosingForUser(username);
  }
  function getClosingDocId(dateKey, username = null) {
    const u = username ? sanitizeUsername(username) : '';
    return u ? `${dateKey}_${u}` : dateKey;
  }
  function getClosingDelayMinutes(date = new Date(), source = null) {
    const wib = getWIBDate(date);
    const currentMinutes = (wib.hour * 60) + wib.minute;
    return Math.max(0, currentMinutes - getClosingDeadlineMinutes(source));
  }
  function formatClosingDeadline(source = null) {
    return `${getClosingDeadlineTimeLabel(source)} WIB`;
  }
  function normalizeTimeLabel(value) {
    if (!value) return '';
    const raw = String(value).trim().replace('.', ':').replace(/\s*WIB$/i, '');
    const match = raw.match(/^(\d{1,2}):(\d{2})/);
    if (!match) return '';
    return `${String(Number(match[1])).padStart(2,'0')}:${match[2]}`;
  }
  function getDeadlineTimeLabel(source = null) {
    return getClosingDeadlineTimeLabel(source);
  }
  function getClosingTimeFromDelay(delayMinutes, source = null) {
    const delay = Number(delayMinutes || 0);
    if (!Number.isFinite(delay) || delay <= 0) return '';
    const total = getClosingDeadlineMinutes(source) + delay;
    const hour = Math.floor(total / 60) % 24;
    const minute = total % 60;
    return `${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}`;
  }
  function getCurrentWIBTimeLabel(date = new Date()) {
    const wib = getWIBDate(date);
    return `${String(wib.hour).padStart(2,'0')}:${String(wib.minute).padStart(2,'0')}`;
  }
  function getClosingDisplayTime(closing = getTodayClosing()) {
    if (!closing) return '';
    // Prioritas tile/menu Absen Hari Ini:
    // - Kalau admin EDIT jam setelah closing => pakai manualClosingTime.
    // - Kalau admin BATAL lalu CLOSING lagi => pakai jam closing terbaru / actualClosingTime,
    //   bukan manualClosingTime lama yang tersisa dari edit sebelumnya.
    const manualTime = normalizeTimeLabel(closing.manualClosingTime);
    const actualTime = normalizeTimeLabel(closing.actualClosingTime);
    const savedClosingTime = normalizeTimeLabel(closing.closingTime);
    const closedAtMs = Number(closing.closedAtMs || 0);
    const editedAtMs = Number(closing.editedAtMs || 0);
    if (manualTime && editedAtMs && (!closedAtMs || editedAtMs >= closedAtMs)) return manualTime;
    if (actualTime) return actualTime;
    const deadlineTime = getDeadlineTimeLabel(closing);
    if (savedClosingTime && savedClosingTime !== deadlineTime) return savedClosingTime;
    const delayTime = getClosingTimeFromDelay(closing.delayMinutes, closing);
    if (delayTime) return delayTime;
    if (closedAtMs) return new Date(closedAtMs).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', timeZone:'Asia/Jakarta' }).replace('.', ':');
    return manualTime || savedClosingTime || '';
  }
  function parseClosingTimeInput(value) {
    const raw = String(value || '').trim().replace('.', ':');
    const match = raw.match(/^(\d{1,2}):(\d{2})$/);
    if (!match) return null;
    const hour = Number(match[1]);
    const minute = Number(match[2]);
    if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return { hour, minute, label: `${String(hour).padStart(2,'0')}:${String(minute).padStart(2,'0')}` };
  }
  function getClosingDelayMinutesFromTime(hour, minute, source = null) {
    const currentMinutes = (Number(hour) * 60) + Number(minute);
    return Math.max(0, currentMinutes - getClosingDeadlineMinutes(source));
  }
  function getStaffClosingUsers(dateKey = toDateKey(nowDate())) {
    return realActiveUsers().filter(u => isClosingEligibleUser(u, dateKey));
  }
  function hasUserAttendanceOnDate(username, dateKey = toDateKey(nowDate())) {
    const target = sanitizeUsername(username || '');
    if (!target || !dateKey) return false;
    return getVisibleAttendance().some(a =>
      !isRecordDeleted(a) &&
      sanitizeUsername(a.user) === target &&
      extractDateKey(a) === dateKey
    );
  }
  function isRismaSpecialClosingUser(userOrUsername) {
    const username = typeof userOrUsername === 'object'
      ? sanitizeUsername(userOrUsername?.username || userOrUsername?.user || userOrUsername?.id || '')
      : sanitizeUsername(userOrUsername || '');
    return username === 'risma';
  }
  function hasRismaTransactionOnDate(dateKey = toDateKey(nowDate())) {
    const targetDate = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    return getVisibleTransactions().some(t =>
      !isRecordDeleted(t) &&
      String(t.dateKey || extractDateKey(t) || '').slice(0, 10) === targetDate &&
      sanitizeUsername(t.user || t.username || t.kasir || t.createdBy || '') === 'risma' &&
      Number(t.amount || 0) > 0
    );
  }
  function isClosingEligibleUser(userOrUsername, dateKey = toDateKey(nowDate())) {
    const user = typeof userOrUsername === 'object' ? userOrUsername : getUserByUsername(userOrUsername);
    if (!user) return false;
    const uname = sanitizeUsername(user.username);
    if (!uname || isDummyUser(user) || ADMIN_USERNAMES.includes(uname) || sanitizeUsername(user.role || 'staff') === 'admin') return false;
    // Aturan closing: karyawan harian boleh diclosing tanpa absen.
    // User khusus Risma dianggap hadir hanya kalau sudah ada transaksi Risma hari itu.
    // Staff biasa tetap wajib sudah absen di tanggal tersebut.
    if (isDailyEmployee(user)) return true;
    if (isRismaSpecialClosingUser(user)) return hasRismaTransactionOnDate(dateKey);
    return hasUserAttendanceOnDate(uname, dateKey);
  }
  function hasUserClosingOnDate(username, dateKey = toDateKey(nowDate())) {
    const target = sanitizeUsername(username || '');
    if (!target || !dateKey) return false;
    return (cachedClosings || []).some(c => {
      if (!c || c.closed !== true || c.dateKey !== dateKey) return false;
      if (c.canceled === true || c.canceled === 'true' || isRecordDeleted(c)) return false;
      if (c.type === 'bonus_settings' || c.id === '__bonus_settings' || c.dateKey === '__bonus_settings') return false;
      const scope = c.scope || (c.user ? 'user' : 'global');
      const user = sanitizeUsername(c.user || c.username || '');
      // Closing global mengunci semua user valid di tanggal tersebut.
      if (scope === 'global' || (!user && scope !== 'user')) return true;
      return scope === 'user' && user === target;
    });
  }
  function buildClosingBonusByUser(delayMinutes, targetUsername = null, dateKey = toDateKey(nowDate())) {
    const target = targetUsername ? sanitizeUsername(targetUsername) : null;
    const allStaffTargets = getStaffClosingUsers(dateKey);
    const targetUsers = target
      ? allStaffTargets.filter(u => sanitizeUsername(u.username) === target)
      : allStaffTargets;

    // FIX anti bonus dobel:
    // Saat closing GLOBAL, user yang sudah closing per-user di tanggal yang sama tetap ikut terkunci,
    // tetapi TIDAK dimasukkan lagi ke bonusByUser supaya bonus closing tidak masuk 2x.
    // Saat closing PER USER, pengecekan existing tetap dilakukan di handleClosingDay().
    const eligibleUsers = target
      ? targetUsers
      : targetUsers.filter(u => !hasUserClosingOnDate(u.username, dateKey));

    // Bonus closing tetap untuk staff biasa yang sudah absen hari ini.
    // User khusus Risma ikut bonus hanya kalau sudah ada transaksi Risma hari itu.
    // Nilainya sekarang per user dan disimpan sebagai snapshot saat closing dibuat.
    const delay = Number(delayMinutes || 0);
    const bonusUsers = eligibleUsers.filter(u => !isDailyEmployee(u) && (hasUserAttendanceOnDate(u.username, dateKey) || (isRismaSpecialClosingUser(u) && hasRismaTransactionOnDate(dateKey))));
    const bonusPerMinuteByUser = {};
    const bonusByUser = bonusUsers.reduce((acc, u) => {
      const uname = sanitizeUsername(u.username);
      const perMinute = getUserClosingBonusPerMinute(uname);
      bonusPerMinuteByUser[uname] = perMinute;
      acc[uname] = Math.round(Math.max(0, delay) * perMinute);
      return acc;
    }, {});
    const totalBonus = Object.values(bonusByUser).reduce((a,b)=>a+Number(b||0),0);
    const bonusValues = Object.values(bonusByUser).map(v => Number(v || 0));
    const bonusPerUser = bonusValues.length ? Math.max(...bonusValues) : 0;
    return { users: bonusUsers, targetUsers, eligibleUsers, bonusUsers, bonusByUser, bonusPerMinuteByUser, bonusPerUser, totalBonus };
  }

  function buildClosingBonusByUserForEdit(closing, delayMinutes, targetUsername = null, dateKey = toDateKey(nowDate())) {
    const delay = Math.max(0, Number(delayMinutes || 0));
    const storedBonusByUser = closing?.bonusByUser && typeof closing.bonusByUser === 'object' ? closing.bonusByUser : {};
    const storedPerMinuteByUser = closing?.bonusPerMinuteByUser && typeof closing.bonusPerMinuteByUser === 'object' ? closing.bonusPerMinuteByUser : {};
    const canceled = getClosingCanceledUsersMap(closing);
    const target = targetUsername ? sanitizeUsername(targetUsername) : null;
    let usernames = [];
    if (target) usernames = [target];
    else usernames = [...new Set([...Object.keys(storedBonusByUser), ...Object.keys(storedPerMinuteByUser)].map(sanitizeUsername).filter(Boolean))];
    if (!usernames.length && closing?.user) usernames = [sanitizeUsername(closing.user)].filter(Boolean);
    if (!usernames.length) {
      const legacyPerMinute = Number(closing?.bonusPerMinute);
      const perMinute = Number.isFinite(legacyPerMinute) && legacyPerMinute >= 0 ? legacyPerMinute : getClosingBonusPerMinute();
      const totalUsers = Math.max(0, Number(closing?.totalUsers || 0));
      if (totalUsers > 0) {
        const bonusPerUser = Math.round(delay * perMinute);
        const users = Array.from({ length: totalUsers }, (_, idx) => ({ username: `legacy_${idx + 1}`, name: 'Legacy Closing', role: 'staff' }));
        return { users, targetUsers: users, eligibleUsers: users, bonusUsers: users, bonusByUser: {}, bonusPerMinuteByUser: {}, bonusPerUser, totalBonus: bonusPerUser * totalUsers };
      }
      return buildClosingBonusByUser(delay, targetUsername, dateKey);
    }
    const bonusByUser = {};
    const bonusPerMinuteByUser = {};
    const users = [];
    usernames.forEach(uname => {
      if (!uname || canceled[uname]) return;
      const user = getUserByUsername(uname) || { username: uname, name: uname, role: 'staff' };
      if (isDailyEmployee(user)) return;
      const storedPerMinute = Number(storedPerMinuteByUser[uname]);
      const legacyPerMinute = Number(closing?.bonusPerMinute);
      const perMinute = Number.isFinite(storedPerMinute) && storedPerMinute >= 0
        ? storedPerMinute
        : (Number.isFinite(legacyPerMinute) && legacyPerMinute >= 0 ? legacyPerMinute : getUserClosingBonusPerMinute(uname));
      bonusPerMinuteByUser[uname] = perMinute;
      bonusByUser[uname] = Math.round(delay * perMinute);
      users.push(user);
    });
    const totalBonus = Object.values(bonusByUser).reduce((a,b)=>a+Number(b||0),0);
    const bonusValues = Object.values(bonusByUser).map(v => Number(v || 0));
    const bonusPerUser = bonusValues.length ? Math.max(...bonusValues) : 0;
    return { users, targetUsers: users, eligibleUsers: users, bonusUsers: users, bonusByUser, bonusPerMinuteByUser, bonusPerUser, totalBonus };
  }

  function isSpecialClosingDoc(c) {
    const id = String(c?.id || '');
    const dateKey = String(c?.dateKey || '');
    const type = String(c?.type || '');
    return id === '__bonus_settings' || id === RISMA_MANUAL_CLOSING_DOC_ID || id === RECEIPT_TEXT_DOC_ID || dateKey === '__bonus_settings' || dateKey === RISMA_MANUAL_CLOSING_DOC_ID || dateKey === RECEIPT_TEXT_DOC_ID || type === 'bonus_settings' || type === 'closing_manual_config' || type === 'receipt_text_settings';
  }
  function isClosingDataRecord(c) {
    return !!(c && !isSpecialClosingDoc(c) && (c.closed === true || c.canceled === true || c.scope || c.user || c.bonusByUser));
  }
  function getMonthlyClosingRecords(month = toMonthKey(nowDate())) {
    return cachedClosings.filter(c => isClosingDataRecord(c) && c.closed === true && String(c.monthKey || c.dateKey || '').startsWith(month));
  }
  function getClosingBonusPerUserDynamic(closing) {
    if (!closing || closing.closed !== true) return 0;
    const stored = Number(closing.bonusPerUser || 0);
    if (Number.isFinite(stored) && stored > 0) return stored;
    const byUser = closing.bonusByUser || {};
    const values = Object.values(byUser).map(v => Number(v || 0)).filter(v => Number.isFinite(v));
    if (values.length) return Math.max(...values);
    const delay = Number(closing.delayMinutes || 0);
    if (!Number.isFinite(delay) || delay <= 0) return 0;
    const storedPerMinute = Number(closing.bonusPerMinute || 0);
    const perMinute = Number.isFinite(storedPerMinute) && storedPerMinute >= 0 ? storedPerMinute : getClosingBonusPerMinute();
    return Math.round(delay * perMinute);
  }
  function getClosingTotalUsers(closing) {
    if (!closing) return 0;
    const stored = Number(closing.totalUsers || 0);
    if (Number.isFinite(stored) && stored > 0) return stored;
    const byUser = closing.bonusByUser || {};
    const countByUser = Object.keys(byUser).filter(k => sanitizeUsername(k) && sanitizeUsername(k) !== 'admin').length;
    if (countByUser > 0) return countByUser;
    return getStaffClosingUsers().length;
  }
  function getClosingBonusValue(closing, username = null) {
    if (!closing || closing.closed !== true) return 0;
    const byUser = closing.bonusByUser || {};
    const target = username && username !== 'all' ? sanitizeUsername(username) : null;
    if (target) {
      if (isClosingCanceledForUser(closing, target)) return 0;
      return Number(byUser[target] || 0);
    }
    if (Object.keys(byUser).length) return Object.keys(byUser).reduce((sum, key) => isClosingCanceledForUser(closing, key) ? sum : sum + Number(byUser[key] || 0), 0);
    return Number(closing.totalBonus || 0);
  }
  function getMonthlyClosingBonus(username = null, month = toMonthKey(nowDate())) {
    return getMonthlyClosingRecords(month).reduce((sum, closing) => sum + getClosingBonusValue(closing, username), 0);
  }
  function getMonthlyManualBonuses(username = null, month = toMonthKey(nowDate())) {
    const target = username && username !== 'all' ? sanitizeUsername(username) : null;
    return sortByCreatedDesc(dedupeManualBonusRecords(cachedManualBonuses || []).filter(b => {
      if (!b || b.deleted === true || b.deleted === 'true') return false;
      if (isTrialRecord(b)) return false;
      const amount = Number(b.amount || 0);
      if (!Number.isFinite(amount) || amount === 0) return false;
      const bMonth = String(b.monthKey || extractDateKey(b).slice(0, 7) || '');
      if (month && bMonth !== month) return false;
      if (target && sanitizeUsername(b.user) !== target) return false;
      return true;
    }));
  }

  function getMonthlyManualBonus(username = null, month = toMonthKey(nowDate())) {
    return getMonthlyManualBonuses(username, month).reduce((sum, b) => sum + Number(b.amount || 0), 0);
  }

  function normalizeBonusPeriod(period = toMonthKey(nowDate())) {
    if (period && typeof period === 'object') {
      const type = period.type || (period.dateKey ? 'daily' : (period.year ? 'yearly' : 'monthly'));
      return {
        type,
        dateKey: String(period.dateKey || '').slice(0, 10),
        monthKey: String(period.monthKey || period.month || toMonthKey(nowDate())).slice(0, 7),
        year: String(period.year || getBusinessYear(nowDate())).slice(0, 4)
      };
    }
    const raw = String(period || toMonthKey(nowDate()));
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return { type:'daily', dateKey: raw, monthKey: raw.slice(0, 7), year: raw.slice(0, 4) };
    if (/^\d{4}$/.test(raw)) return { type:'yearly', dateKey:'', monthKey:'', year: raw };
    return { type:'monthly', dateKey:'', monthKey: raw.slice(0, 7) || toMonthKey(nowDate()), year: raw.slice(0, 4) || getBusinessYear(nowDate()) };
  }
  function recordMatchesBonusPeriod(record, period = toMonthKey(nowDate())) {
    const p = normalizeBonusPeriod(period);
    const dateKey = String(record?.dateKey || extractDateKey(record) || '').slice(0, 10);
    const monthKey = String(record?.monthKey || (dateKey ? dateKey.slice(0, 7) : '') || '').slice(0, 7);
    if (p.type === 'daily') return dateKey === p.dateKey;
    if (p.type === 'yearly') return (monthKey || dateKey).startsWith(p.year);
    return monthKey === p.monthKey || (dateKey && dateKey.startsWith(p.monthKey));
  }
  function getPeriodClosingBonus(username = null, period = toMonthKey(nowDate())) {
    return (cachedClosings || [])
      .filter(c => isClosingDataRecord(c) && c.closed === true && recordMatchesBonusPeriod(c, period))
      .reduce((sum, closing) => sum + getClosingBonusValue(closing, username), 0);
  }
  function getPeriodManualBonuses(username = null, period = toMonthKey(nowDate())) {
    const target = username && username !== 'all' ? sanitizeUsername(username) : null;
    return sortByCreatedDesc(dedupeManualBonusRecords(cachedManualBonuses || []).filter(b => {
      if (!b || b.deleted === true || b.deleted === 'true') return false;
      if (isTrialRecord(b)) return false;
      const amount = Number(b.amount || 0);
      if (!Number.isFinite(amount) || amount === 0) return false;
      if (!recordMatchesBonusPeriod(b, period)) return false;
      if (target && sanitizeUsername(b.user) !== target) return false;
      return true;
    }));
  }
  function getPeriodManualBonus(username = null, period = toMonthKey(nowDate())) {
    return getPeriodManualBonuses(username, period).reduce((sum, b) => sum + Number(b.amount || 0), 0);
  }

  function getBonusBreakdown(transactions, username = null, period = toMonthKey(nowDate())) {
    const target = username && username !== 'all' ? sanitizeUsername(username) : null;
    const targetIsDaily = target ? isDailyEmployee(target) : false;
    const periodTransactions = (transactions || []).filter(t => recordMatchesBonusPeriod(t, period));
    const staffTransactions = periodTransactions.filter(t => !isDailyTransactionRecord(t));
    const dailyTransactions = periodTransactions.filter(isDailyTransactionRecord);
    const staffTransactionBonus = calculateTransactionBonusForList(staffTransactions);
    const dailySalary = calculateTransactionBonusForList(dailyTransactions);
    const trxBonus = targetIsDaily ? dailySalary : staffTransactionBonus;
    const closingBonus = targetIsDaily ? 0 : getPeriodClosingBonus(username, period);
    const manualBonus = getPeriodManualBonus(username, period);
    const totalBonus = targetIsDaily
      ? dailySalary + manualBonus
      : staffTransactionBonus + closingBonus + manualBonus + (target ? 0 : dailySalary);
    return { trxBonus, closingBonus, manualBonus, dailySalary, staffTransactionBonus, totalBonus };
  }

  function getMonthlyClosingCount(username = null, month = toMonthKey(nowDate())) {
    const target = username && username !== 'all' ? sanitizeUsername(username) : null;
    return getMonthlyClosingRecords(month).filter(closing => {
      if (target) return getClosingBonusValue(closing, target) > 0;
      return getClosingBonusValue(closing) > 0;
    }).length;
  }

  function isAtOrAfterClosingDeadline(date = new Date(), source = null) {
    const wib = getWIBDate(date);
    const currentMinutes = (wib.hour * 60) + wib.minute;
    return currentMinutes >= getClosingDeadlineMinutes(source);
  }

  function renderBonusBreakdownHtml(bonusBreakdown, username = null, month = toMonthKey(nowDate())) {
    return '';
  }

  function renderClosingStatusHtml(compact = false) {
    const closing = isAdmin() ? getTodayGlobalClosing() : (getTodayUserClosing(currentUser?.username) || getTodayGlobalClosingForUser(currentUser?.username));
    if (!closing) {
      const showEstimate = isAtOrAfterClosingDeadline(nowDate());
      const lateMinutes = getClosingDelayMinutes(nowDate());
      const estBonus = lateMinutes * getClosingBonusPerMinute();
      return `<div style="display:flex;flex-direction:column;gap:8px;padding:${compact?'10px 11px':'12px 13px'};border:1px solid ${showEstimate?'rgba(255,196,107,.24)':'var(--border)'};border-radius:13px;background:${showEstimate?'var(--amber-dim)':'var(--surface)'}">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div style="min-width:0">
            <div style="font-size:12px;font-weight:800;color:${showEstimate?'var(--amber)':'var(--green)'}"><i class="fas ${showEstimate?'fa-bell':'fa-lock-open'}"></i> ${showEstimate?'Estimasi bonus closing':'Transaksi masih terbuka'}</div>
            <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">${showEstimate ? `Mulai ${formatClosingDeadline()} · telat ${lateMinutes} menit` : 'Transaksi masih berjalan'}</div>
          </div>
          ${showEstimate ? `<div style="text-align:right;flex-shrink:0"><div style="font-family:var(--num-font);font-size:16px;font-weight:900;color:var(--amber);line-height:1">Rp ${formatRupiah(estBonus)}</div><div style="font-size:8.5px;color:var(--text-ghost);font-weight:800;margin-top:3px;text-transform:uppercase">/ user</div></div>` : ''}
        </div>
        ${showEstimate ? `<div style="font-size:10px;color:var(--text-soft);line-height:1.35;border-top:1px solid rgba(255,196,107,.16);padding-top:7px">Estimasi ini otomatis naik setiap menit setelah ${formatClosingDeadline()} sampai admin melakukan closing.</div>` : ''}
      </div>`;
    }
    return `<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:${compact?'10px 11px':'12px 13px'};border:1px solid rgba(255,196,107,.22);border-radius:13px;background:var(--amber-dim)">
      <div style="min-width:0">
        <div style="font-size:12px;font-weight:800;color:var(--amber)"><i class="fas fa-lock"></i> Transaksi sudah closing</div>
        <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">${formatDateLabel(closing.dateKey)} · bonus closing Rp ${formatRupiah(getClosingBonusValue(closing, currentUser?.username))}</div>
      </div>
    </div>`;
  }
  function getAdminClosingTargetUser() {
    const val = sanitizeUsername($('closing-target-user')?.value || '');
    if (!val || val === 'global') return null;
    return getUserByUsername(val) || null;
  }
  function getClosingTargetLabel(user = getAdminClosingTargetUser()) {
    return user ? `${user.name || user.username} (@${user.username})` : 'Semua User';
  }

  async function handleClosingDay() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const today = toDateKey(nowDate());
    const targetUser = getAdminClosingTargetUser();
    const targetUsername = targetUser ? sanitizeUsername(targetUser.username) : null;
    const existingUserClosing = targetUsername ? getTodayUserClosing(targetUsername) : null;
    const existingGlobalClosing = targetUsername ? getTodayGlobalClosingForUser(targetUsername) : getTodayGlobalClosing();
    const existing = targetUsername ? (existingUserClosing || existingGlobalClosing) : existingGlobalClosing;
    if (existing) return showToast(targetUsername ? (existingGlobalClosing && !existingUserClosing ? 'User ini sudah terkunci oleh closing global hari ini!' : 'User ini sudah closing hari ini!') : 'Global hari ini sudah closing!', true);
    const pin = await askPin(`Closing transaksi ${targetUsername ? 'untuk ' + getClosingTargetLabel(targetUser) : 'SEMUA USER'} tanggal ${today}?
${targetUsername ? 'Hanya user ini yang terkunci. User lain tetap bisa transaksi.' : 'Hanya user yang sudah absen, karyawan harian, atau Risma yang sudah transaksi hari ini yang masuk target closing.'}
Masukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    const currentClosingTime = getCurrentWIBTimeLabel(nowDate());
    const deadlineSnapshot = getClosingDeadlineSnapshot();
    const delayMinutes = getClosingDelayMinutes(nowDate(), deadlineSnapshot);
    const { users, targetUsers, bonusByUser, bonusPerMinuteByUser, bonusPerUser, totalBonus } = buildClosingBonusByUser(delayMinutes, targetUsername, today);
    if (targetUsername && !targetUsers.length) return showToast('User belum absen / bukan karyawan harian / Risma belum transaksi, jadi tidak perlu closing.', true);
    if (!targetUsername && !targetUsers.length) return showToast('Belum ada user yang sudah absen, karyawan harian, atau Risma yang sudah transaksi untuk closing.', true);
    if (!confirm(`Yakin closing ${targetUsername ? getClosingTargetLabel(targetUser) : 'SEMUA USER'} sekarang?
Deadline: ${deadlineSnapshot.deadline}
Lewat deadline: ${delayMinutes} menit
Bonus closing: per user sesuai setting masing-masing
Target closing valid: ${targetUsers.length} · layak bonus: ${users.length}
Total bonus closing: Rp ${formatRupiah(totalBonus)}
${users.length ? '' : 'Catatan: staff belum absen tidak ikut diclosing; karyawan harian tetap bisa diclosing tanpa bonus; Risma ikut hanya kalau sudah transaksi hari ini.'}`)) return;
    setLoading(true);
    try {
      const docId = getClosingDocId(today, targetUsername);
      await setDoc(doc(db, 'closings', docId), {
        id: docId,
        closed: true,
        scope: targetUsername ? 'user' : 'global',
        user: targetUsername || null,
        name: targetUser?.name || null,
        dateKey: today,
        monthKey: toMonthKey(nowDate()),
        closedAt: serverTimestamp(),
        closedAtMs: Date.now(),
        closedBy: currentUser.username,
        closedByName: currentUser.name,
        actualClosingTime: currentClosingTime,
        closingTime: currentClosingTime,
        manualClosingTime: currentClosingTime,
        canceled: false,
        canceledAtMs: null,
        editedAtMs: null,
        ...deadlineSnapshot,
        delayMinutes,
        bonusPerMinute: getClosingBonusPerMinute(),
        bonusPerMinuteByUser,
        bonusPerUser,
        bonusByUser,
        bonusLogicVersion: 3,
        totalUsers: users.length,
        totalBonus
      }, { merge: true });
      cachedClosings = [{
        id: docId,
        closed: true,
        scope: targetUsername ? 'user' : 'global',
        user: targetUsername || null,
        name: targetUser?.name || null,
        dateKey: today,
        monthKey: toMonthKey(nowDate()),
        closedAtMs: Date.now(),
        closedBy: currentUser.username,
        closedByName: currentUser.name,
        actualClosingTime: currentClosingTime,
        closingTime: currentClosingTime,
        manualClosingTime: currentClosingTime,
        canceled: false,
        editedAtMs: null,
        ...deadlineSnapshot,
        delayMinutes,
        bonusPerMinute: getClosingBonusPerMinute(),
        bonusPerMinuteByUser,
        bonusPerUser,
        bonusByUser,
        bonusLogicVersion: 3,
        totalUsers: users.length,
        totalBonus
      }, ...cachedClosings.filter(c => c.id !== docId)];
      await logAudit('closing_day', { dateKey: today, scope: targetUsername ? 'user' : 'global', user: targetUsername || null, closingTime: currentClosingTime, deadlineTime: deadlineSnapshot.deadlineTime, delayMinutes, bonusPerUser, totalUsers: users.length, totalBonus });
      showToast(delayMinutes ? `✓ Closing ${targetUsername ? targetUser.name : 'global'} · total bonus Rp ${formatRupiah(totalBonus)}` : `✓ Closing ${targetUsername ? targetUser.name : 'global'} berhasil`);
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal closing transaksi', true);
    }
    setLoading(false);
  }


  async function handleEditClosingTime() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const targetUser = getAdminClosingTargetUser();
    const targetUsername = targetUser ? sanitizeUsername(targetUser.username) : null;
    const closing = targetUsername ? getTodayUserClosing(targetUsername) : getTodayGlobalClosing();
    if (!closing) return showToast(targetUsername ? 'User ini belum closing hari ini.' : 'Closing global hari ini belum ada.', true);
    const currentLabel = closing.manualClosingTime || closing.closingTime || new Date(closing.closedAtMs || Date.now()).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', timeZone:'Asia/Jakarta' });
    const input = prompt(`Edit jam closing tanggal ${closing.dateKey || toDateKey(nowDate())}\nFormat HH:MM WIB. Contoh 18:10`, currentLabel);
    if (!input) return;
    const parsed = parseClosingTimeInput(input);
    if (!parsed) return showToast('Format jam tidak valid. Pakai HH:MM, contoh 18:10', true);
    const pin = await askPin('Masukkan PIN admin untuk simpan edit jam closing:');
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    const delayMinutes = getClosingDelayMinutesFromTime(parsed.hour, parsed.minute, closing);
    const { users, bonusByUser, bonusPerMinuteByUser, bonusPerUser, totalBonus } = buildClosingBonusByUserForEdit(closing, delayMinutes, targetUsername, closing.dateKey || toDateKey(nowDate()));
    if (!confirm(`Simpan jam closing ${parsed.label} WIB?\nDeadline snapshot data ini: ${formatClosingDeadline(closing)}\nLewat deadline: ${delayMinutes} menit\nBonus closing: pakai snapshot bonus user yang tersimpan di closing ini\nTotal user: ${users.length}\nTotal bonus closing: Rp ${formatRupiah(totalBonus)}`)) return;
    setLoading(true);
    try {
      const dateKey = closing.dateKey || toDateKey(nowDate());
      const docId = closing.id || getClosingDocId(dateKey, targetUsername);
      await setDoc(doc(db, 'closings', docId), {
        manualClosingTime: parsed.label,
        closingTime: parsed.label,
        delayMinutes,
        bonusPerMinute: Number.isFinite(Number(closing.bonusPerMinute)) ? Number(closing.bonusPerMinute) : getClosingBonusPerMinute(),
        bonusPerMinuteByUser,
        bonusPerUser,
        bonusByUser,
        bonusLogicVersion: 3,
        totalUsers: users.length,
        totalBonus,
        editedAt: serverTimestamp(),
        editedAtMs: Date.now(),
        editedBy: currentUser.username,
        editedByName: currentUser.name
      }, { merge: true });
      await logAudit('closing_time_edit', { dateKey, closingTime: parsed.label, delayMinutes, bonusPerUser, totalUsers: users.length, totalBonus });
      cachedClosings = cachedClosings.map(c => c.id === docId ? {
        ...c,
        manualClosingTime: parsed.label,
        closingTime: parsed.label,
        delayMinutes,
        bonusPerMinute: Number.isFinite(Number(c.bonusPerMinute)) ? Number(c.bonusPerMinute) : getClosingBonusPerMinute(),
        bonusPerMinuteByUser,
        bonusPerUser,
        bonusByUser,
        bonusLogicVersion: 3,
        totalUsers: users.length,
        totalBonus,
        editedAtMs: Date.now(),
        editedBy: currentUser.username,
        editedByName: currentUser.name
      } : c);
      showToast('✓ Jam closing diperbarui');
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal edit jam closing', true);
    }
    setLoading(false);
  }

  async function handleCancelClosingToday() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const targetUser = getAdminClosingTargetUser();
    const targetUsername = targetUser ? sanitizeUsername(targetUser.username) : null;
    const userClosing = targetUsername ? getTodayUserClosing(targetUsername) : null;
    const globalClosing = getTodayGlobalClosing();
    const lockedByGlobal = !!(targetUsername && !userClosing && globalClosing && !isClosingCanceledForUser(globalClosing, targetUsername));
    const closing = targetUsername ? (userClosing || (lockedByGlobal ? globalClosing : null)) : globalClosing;
    if (!closing) return showToast(targetUsername ? 'User ini belum closing hari ini.' : 'Belum ada closing global hari ini.', true);
    const dateKey = closing.dateKey || toDateKey(nowDate());
    const docId = closing.id || getClosingDocId(dateKey, targetUsername);
    const pin = await askPin(`Batal closing ${targetUsername ? 'untuk ' + getClosingTargetLabel(targetUser) : 'GLOBAL'} tanggal ${dateKey}?
${lockedByGlobal ? 'User ini akan dibuka dari closing global. User lain tetap terkunci.' : (targetUsername ? 'User ini akan dibuka lagi. User lain tidak berubah.' : 'Transaksi staff akan dibuka kembali.')}
Masukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm(`Yakin batal closing ${targetUsername ? getClosingTargetLabel(targetUser) : 'GLOBAL'}?
${lockedByGlobal ? 'Hanya user ini yang dibuka dari closing global. Bonus closing user ini tidak dihitung.' : 'Bonus closing target ini tidak akan dihitung.'}`)) return;
    setLoading(true);
    try {
      if (lockedByGlobal) {
        const bonusByUser = { ...(closing.bonusByUser || {}) };
        const bonusPerMinuteByUser = { ...(closing.bonusPerMinuteByUser || {}) };
        delete bonusByUser[targetUsername];
        delete bonusPerMinuteByUser[targetUsername];
        const canceledUsers = { ...getClosingCanceledUsersMap(closing) };
        canceledUsers[targetUsername] = {
          canceled: true,
          canceledAtMs: Date.now(),
          canceledBy: currentUser.username,
          canceledByName: currentUser.name,
          name: targetUser?.name || targetUsername
        };
        const totalBonus = Object.values(bonusByUser).reduce((sum, val) => sum + Number(val || 0), 0);
        const totalUsers = Object.keys(bonusByUser).length;
        await setDoc(doc(db, 'closings', docId), {
          canceledUsers,
          bonusByUser,
          bonusPerMinuteByUser,
          totalBonus,
          totalUsers,
          editedAt: serverTimestamp(),
          editedAtMs: Date.now(),
          editedBy: currentUser.username,
          editedByName: currentUser.name,
          cancelNote: `User ${targetUsername} dibuka dari closing global oleh admin`
        }, { merge: true });
        await logAudit('closing_cancel_user_from_global', { dateKey, scope: 'global', user: targetUsername, name: targetUser?.name || targetUsername });
        cachedClosings = cachedClosings.map(c => c.id === docId ? {
          ...c,
          canceledUsers,
          bonusByUser,
          bonusPerMinuteByUser,
          totalBonus,
          totalUsers,
          editedAtMs: Date.now(),
          editedBy: currentUser.username,
          editedByName: currentUser.name,
          cancelNote: `User ${targetUsername} dibuka dari closing global oleh admin`
        } : c);
        showToast(`✓ Closing ${targetUser?.name || targetUsername} dibatalkan dari global`);
      } else {
        await setDoc(doc(db, 'closings', docId), {
          closed: false,
          canceled: true,
          canceledAt: serverTimestamp(),
          canceledAtMs: Date.now(),
          canceledBy: currentUser.username,
          canceledByName: currentUser.name,
          cancelNote: 'Closing dibatalkan admin',
          totalBonus: 0,
          bonusPerUser: 0,
          bonusByUser: {}
        }, { merge: true });
        await logAudit('closing_cancel', { dateKey, scope: targetUsername ? 'user' : 'global', user: targetUsername || null });
        cachedClosings = cachedClosings.map(c => (c.id === docId || (c.dateKey === dateKey && (targetUsername ? sanitizeUsername(c.user) === targetUsername : (c.scope === 'global' || !c.user)))) ? { ...c, id: docId, closed:false, canceled:true, canceledAtMs:Date.now(), canceledBy:currentUser.username, canceledByName:currentUser.name, totalBonus:0, bonusPerUser:0, bonusByUser:{} } : c);
        showToast(targetUsername ? `✓ Closing ${targetUser?.name || targetUsername} dibatalkan` : '✓ Closing global dibatalkan, transaksi dibuka lagi');
      }
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal batal closing', true);
    }
    setLoading(false);
  }


  function getMonthlyAttendancePerformance(username) {
    const month = toMonthKey(nowDate());
    const me = sanitizeUsername(username || '');
    const monthlyAtt = getVisibleAttendance().filter(a =>
      String(extractDateKey(a) || '').startsWith(month) &&
      sanitizeUsername(a.user) === me
    );
    if (!monthlyAtt.length) return null;
    // Hitung rata-rata jam absen (dalam menit dari tengah malam WIB)
    let totalMinutes = 0;
    let validCount = 0;
    for (const rec of monthlyAtt) {
      const ms = getRecordTimeMs(rec);
      if (!ms) continue;
      const wib = getWIBDate(new Date(ms));
      totalMinutes += wib.hour * 60 + wib.minute;
      validCount++;
    }
    if (!validCount) return null;
    const avgMinutes = totalMinutes / validCount;
    const avgHour = Math.floor(avgMinutes / 60);
    const avgMin = Math.floor(avgMinutes % 60);
    const avgLabel = `${String(avgHour).padStart(2,'0')}:${String(avgMin).padStart(2,'0')}`;
    // Batas: 07:20 = 420 menit. Lewat 07:20 (> 420) = perlu ditingkatkan
    const isGood = avgMinutes <= 420;
    return { avgLabel, isGood, count: validCount };
  }


  async function login() {
    const username = sanitizeUsername($('login-user')?.value);
    const pin = String($('login-pin')?.value || '').trim();
    if (!username || !pin) return showToast('Lengkapi username dan PIN!', true);
    setLoading(true);
    try {
      const ref = doc(db, 'users', username);
      const snap = await getDocFreshSafe('login user', ref);
      if (!snap || !snap.exists()) throw new Error('User tidak ditemukan');
      const user = snap.data();
      if (!isUserActive(user)) throw new Error('User nonaktif. Hubungi admin.');
      if (String(user.pin || '') !== pin) throw new Error('PIN salah');
      if (!isAdminAccount(user, username)) throw new Error('Akses ditolak. Aplikasi ini khusus admin.');
      currentUser = { username: sanitizeUsername(user.username || username), name: user.name || username, role: 'admin', transactionBonusRate: user.transactionBonusRate ?? null, transactionBonusPercent: user.transactionBonusPercent ?? null, closingBonusPerMinute: user.closingBonusPerMinute ?? null, dailyBonusRate: Number(user.dailyBonusRate || 0), dailyBonusPercent: Number(user.dailyBonusPercent || 0), active: isUserActive(user), deleted: false };
      cachedTransactions = [];
      cachedAttendance = [];
      cachedAuditLogs = [];
      cachedClosings = [];
      cachedManualBonuses = [];
      cachedUnlockRequests = [];
      cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
      cachedHeaderGuideNote = { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedReceiptTextSettings = { id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
      persistCurrentSession();
      try { localStorage.setItem(PAGE_KEY, 'home'); } catch (_) {}
      bindRealtimeData();
      adminNotifBootstrapped = false;
      initAdminWebPush();
      requestNativeAdminFcmToken();
      router.navigate('home');
      showToast(`✓ Login ${currentUser.name}`);
    } catch (e) {
      if (e.message === 'PIN salah' && navigator.vibrate) navigator.vibrate(200);
      showToast(e.message || 'Login gagal', true);
    }
    setLoading(false);
  }

  function logout() {
    if (!confirm('Keluar dari aplikasi?')) return;
    const logoutUsername = currentUser?.username || null;
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(PAGE_KEY);
    currentUser = null;
    currentPos = null;
    appPageHistoryStack = [];
    appBackNavigating = false;
    adminProCurrentPageKey = '';
    adminNotifBootstrapped = false;
    adminNotifSeenIds = new Set();
    cachedTransactions = [];
    cachedAttendance = [];
    cachedUsers = [];
    cachedAuditLogs = [];
    cachedClosings = [];
    cachedManualBonuses = [];
    cachedUnlockRequests = [];
    cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
    cachedHeaderGuideNote = { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedReceiptTextSettings = { id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedBonusSettings = getDefaultBonusSettings();
    attendanceReady = false;
    closeTransactionModal();
    stopRealtimeData();
    router.navigate('login');
    showToast('✓ Logout berhasil');
  }

  async function restoreSession() {
    try {
      const raw = localStorage.getItem(SESSION_KEY);
      if (!raw) return false;
      const savedUser = toSessionUser(JSON.parse(raw));
      const username = sanitizeUsername(savedUser.username || '');
      if (!username || !isAdminAccount(savedUser, username)) {
        localStorage.removeItem(SESSION_KEY);
        localStorage.removeItem(PAGE_KEY);
        currentUser = null;
        return false;
      }
      const snap = await getDocFromServer(doc(db, 'users', username));
      if (!snap.exists()) throw new Error('Session user tidak ditemukan');
      const user = snap.data() || {};
      if (!isUserActive(user) || !isAdminAccount(user, username)) throw new Error('Session tidak valid');
      currentUser = toSessionUser({
        username: sanitizeUsername(user.username || username),
        name: user.name || savedUser.name || username,
        role: 'admin',
        transactionBonusRate: user.transactionBonusRate ?? savedUser.transactionBonusRate ?? null,
        transactionBonusPercent: user.transactionBonusPercent ?? savedUser.transactionBonusPercent ?? null,
        closingBonusPerMinute: user.closingBonusPerMinute ?? savedUser.closingBonusPerMinute ?? null,
        dailyBonusRate: Number(user.dailyBonusRate || savedUser.dailyBonusRate || 0),
        dailyBonusPercent: Number(user.dailyBonusPercent || savedUser.dailyBonusPercent || 0),
        active: isUserActive(user),
        deleted: false
      });
      persistCurrentSession();
      cachedTransactions = [];
      cachedAttendance = [];
      cachedAuditLogs = [];
      cachedClosings = [];
      cachedManualBonuses = [];
      cachedUnlockRequests = [];
      cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
      cachedHeaderGuideNote = { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedReceiptTextSettings = { id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
      bindRealtimeData();
      adminNotifBootstrapped = false;
      initAdminWebPush();
      requestNativeAdminFcmToken();
      return true;
    } catch (e) {
      localStorage.removeItem(SESSION_KEY);
      localStorage.removeItem(PAGE_KEY);
      return false;
    }
  }


  function bindRealtimeData() {
    if (!currentUser) return;
    attendanceReady = false;
    stopRealtimeData();

    const tq = query(collection(db, 'transactions'), limit(TX_SYNC_LIMIT_ADMIN));
    unsubTransactions = onSnapshot(tq, (snap) => {
      cachedTransactions = sortByCreatedDesc(
        snap.docs.map(d => ({ id: d.id, ...d.data() }))
      );
      handleAdminTransactionSnapshotNotifications(snap);
      serverScheduleDailyTargetCheck();
      refreshCurrentPage();
    }, async (err) => {
      console.error(err);
      try {
        const fallbackQ = query(collection(db, 'transactions'), limit(TX_SYNC_LIMIT_ADMIN));
        const fallbackSnap = await getDocs(fallbackQ);
        cachedTransactions = sortByCreatedDesc(
          fallbackSnap.docs.map(d => ({ id: d.id, ...d.data() }))
        );
        refreshCurrentPage();
      } catch (e) {
        console.error('Fallback transaksi gagal:', e);
      }
    });

    const aq = query(collection(db, 'attendance'), limit(ATT_SYNC_LIMIT_ADMIN));
    unsubAttendance = onSnapshot(aq, (snap) => {
      stripCachedAttendance();
      cachedAttendance = dedupeAttendanceRecords(
        snap.docs.map(d => ({ id: d.id, ...d.data() }))
      );
      attendanceReady = true;
      serverScheduleDailyTargetCheck();
      refreshCurrentPage();
    }, (err) => { attendanceReady = true; console.error(err); refreshCurrentPage(); });

    const cq = query(collection(db, 'closings'), limit(CLOSING_SYNC_LIMIT));
    unsubClosings = onSnapshot(cq, (snap) => {
      cachedClosings = sortByCreatedDesc(snap.docs.map(d => ({ id: d.id, ...d.data() })).filter(c => c.id !== HEADER_GUIDE_NOTE_DOC_ID && c.id !== STAFF_DAILY_NOTE_DOC_ID && c.id !== RECEIPT_TEXT_DOC_ID && c.type !== 'header_guide_note' && c.type !== 'staff_daily_home_note' && c.type !== 'receipt_text_settings'));
      refreshCurrentPage();
    }, (err) => console.error('Closing listener gagal:', err));

    unsubBonusSettings = onSnapshot(doc(db, 'closings', '__bonus_settings'), (snap) => {
      if (snap.exists()) {
        const data = snap.data() || {};
        cachedBonusSettings = normalizeBonusSettings(data);
      } else {
        cachedBonusSettings = getDefaultBonusSettings();
      }
      refreshCurrentPage();
    }, (err) => console.error('Bonus settings listener gagal:', err));




    unsubHeaderGuideNote = onSnapshot(doc(db, 'closings', HEADER_GUIDE_NOTE_DOC_ID), (snap) => {
      cachedHeaderGuideNote = snap.exists()
        ? { id: snap.id, note: DEFAULT_HEADER_GUIDE_NOTE, ...(snap.data() || {}) }
        : { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
      refreshCurrentPage();
    }, (err) => console.error('Catatan Panduan Icon Header listener gagal:', err));

    unsubReceiptTextSettings = onSnapshot(doc(db, 'closings', RECEIPT_TEXT_DOC_ID), (snap) => {
      cachedReceiptTextSettings = snap.exists()
        ? normalizeReceiptTextSettings({ id: snap.id, ...(snap.data() || {}) })
        : normalizeReceiptTextSettings({ id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' });
      refreshCurrentPage();
    }, (err) => console.error('Setting tulisan struk listener gagal:', err));

    const mbq = query(collection(db, 'manualBonuses'), limit(MANUAL_BONUS_SYNC_LIMIT));
    unsubManualBonuses = onSnapshot(mbq, (snap) => {
      cachedManualBonuses = dedupeManualBonusRecords(
        snap.docs.map(d => ({ id: d.id, ...d.data() }))
      );
      serverScheduleDailyTargetCheck();
      refreshCurrentPage();
    }, (err) => console.error('Manual bonus listener gagal:', err));

    const unlockQ = query(collection(db, STAFF_UNLOCK_TABLE), limit(160));
    unsubUnlockRequests = onSnapshot(unlockQ, (snap) => {
      cachedUnlockRequests = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      refreshCurrentPage();
    }, (err) => console.error('Buka fitur listener gagal:', err));

    const uq = query(collection(db, 'users'), orderBy('name'));
    unsubUsers = onSnapshot(uq, (snap) => {
      cachedUsers = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      cachedUserSelectHtml = ''; // Reset cache saat data user berubah
      serverScheduleDailyTargetCheck();
      refreshCurrentPage();
    }, (err) => console.error(err));

    unsubRismaManualClosing = onSnapshot(doc(db, RISMA_MANUAL_CLOSING_COLLECTION, RISMA_MANUAL_CLOSING_DOC_ID), (snap) => {
      cachedRismaManualClosingConfig = snap.exists()
        ? { id: snap.id, enabled: true, allowedUsers: [], allowedNames: {}, ...(snap.data() || {}) }
        : { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
      refreshCurrentPage();
    }, (err) => console.error('Closing manual Risma listener gagal:', err));

    const lq = query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc'), limit(AUDIT_SYNC_LIMIT));
    unsubAuditLogs = onSnapshot(lq, (snap) => {
      cachedAuditLogs = sortByCreatedDesc(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      refreshCurrentPage();
    }, (err) => console.error(err));

    applyNavRoleLabels();
  }

  function isSettingsFormBeingEdited() {
    if (currentPage !== 'settings') return false;
    const active = document.activeElement;
    if (!active) return false;
    const tag = String(active.tagName || '').toLowerCase();
    if (!['input','textarea','select'].includes(tag)) return false;
    const summary = $('settings-summary');
    return !!summary && summary.contains(active);
  }

  function isAdminProFormBeingEdited() {
    if (!String(currentPage || '').startsWith('adminPro:')) return false;
    const active = document.activeElement;
    if (!active) return false;
    const tag = String(active.tagName || '').toLowerCase();
    if (!['input','textarea','select'].includes(tag)) return false;
    const content = $('page-content');
    return !!content && content.contains(active);
  }

  function renderCurrentAdminProPage() {
    const key = String(adminProCurrentPageKey || String(currentPage || '').split(':')[1] || '').trim();
    if (!key) return;
    openAdminProPage(key);
  }

  async function refreshCurrentPage() {
    if (!currentUser) return;
    if (currentPage === 'home') { await updateHomeStatus(); await updateHomeStats(); }
    else if (currentPage === 'history') await renderHistory();
    else if (currentPage === 'attendance') renderAttendanceAdminPage();
    else if (currentPage === 'report') await renderReport();
    else if (currentPage === 'closing') renderAdminClosingPanelMaybe();
    else if (currentPage === 'settings') {
      // Supabase compat layer melakukan polling realtime. Saat admin sedang mengetik form,
      // polling dapat memanggil renderSettingsSummary() dan menimpa innerHTML, sehingga kolom
      // yang sedang diisi terlihat hilang/kosong. Jangan refresh panel settings selama ada input aktif.
      if (isBusy || !isSettingsFormBeingEdited()) await renderSettingsSummary();
    }
    else if (String(currentPage || '').startsWith('adminPro:')) {
      if (isBusy || !isAdminProFormBeingEdited()) renderCurrentAdminProPage();
    }
    else if (currentPage === 'adminLogs') renderAdminLogsPage();
  }

  function canTransactNow() {
    return isAdmin();
  }

  function getHeaderGuideNoteText() {
    const note = String(cachedHeaderGuideNote?.note || '').trim();
    return note || DEFAULT_HEADER_GUIDE_NOTE;
  }
  function getStaffDailyHomeNoteText() {
    const note = String(cachedStaffDailyHomeNote?.note || '').trim();
    return note || DEFAULT_STAFF_DAILY_NOTE;
  }
  function headerGuideStorageKey() {
    return `${HEADER_GUIDE_HIDDEN}_${sanitizeUsername(currentUser?.username || 'guest')}`;
  }
  function isHeaderGuideHidden() {
    try { return localStorage.getItem(headerGuideStorageKey()) === '1'; } catch (e) { return false; }
  }
  function toggleHeaderGuide() {
    try { localStorage.setItem(headerGuideStorageKey(), isHeaderGuideHidden() ? '0' : '1'); } catch (e) {}
    refreshCurrentPage();
  }
  function headerGuideEyeIcon(hidden = false) {
    return hidden
      ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="3"/></svg>'
      : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.9 10.9 0 0 1 12 5c6.5 0 10 7 10 7a18.3 18.3 0 0 1-2.5 3.4"/><path d="M6.1 6.8C3.5 8.6 2 12 2 12s3.5 7 10 7a10.9 10.9 0 0 0 4.1-.8"/></svg>';
  }
  function renderHeaderIconGuide() {
    if (!currentUser || isAdmin()) return '';
    const hidden = isHeaderGuideHidden();
    if (hidden) {
      return `<div class="card header-guide-card is-hidden page-in s4"><div class="header-guide-between"><div style="min-width:0"><div class="label-xs">Catatan Bonus</div><div class="header-guide-bonus-quote">“${escapeHtml(getHeaderGuideNoteText())}”</div><div style="font-size:10px;line-height:1.35;color:var(--text-soft);margin-top:5px">Tap ikon mata untuk tampilkan Panduan Icon Header lagi.</div></div><button class="header-guide-eye" onclick="toggleHeaderGuide()" aria-label="Tampilkan Panduan Icon Header" title="Tampilkan">${headerGuideEyeIcon(true)}</button></div></div>`;
    }
    const themeIcon = '<i class="fas fa-sun"></i>';
    const locked = !canTransactNow();
    const lockIcon = locked ? '🔒' : '🔓';
    const lockText = locked ? (isTransactionsClosedToday() ? 'Transaksi terkunci karena sudah closing.' : 'Transaksi terkunci karena belum absen.') : 'Transaksi terbuka dan siap digunakan.';
    return `<div class="card header-guide-card page-in s4" style="padding:11px 12px"><div class="header-guide-between"><div><div class="label-xs" style="margin-bottom:3px;color:var(--accent)">Panduan Icon Header</div><div style="font-size:10.5px;color:var(--text-soft);line-height:1.35">Keterangan tombol paling atas di aplikasi.</div></div><button class="header-guide-eye" onclick="toggleHeaderGuide()" aria-label="Sembunyikan Panduan Icon Header" title="Sembunyikan">${headerGuideEyeIcon(false)}</button></div><div class="header-guide-grid"><div class="header-guide-item"><span class="header-guide-ico">M</span><div><div class="header-guide-title">Member</div><div class="header-guide-desc">Membuka halaman kode khusus member.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${lockIcon}</span><div><div class="header-guide-title">Status Transaksi</div><div class="header-guide-desc">${lockText}</div></div></div><div class="header-guide-item"><span class="header-guide-ico">↻</span><div><div class="header-guide-title">Refresh</div><div class="header-guide-desc">Muat ulang data dan update bonus terbaru.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${themeIcon}</span><div><div class="header-guide-title">Tema</div><div class="header-guide-desc">Ganti tampilan gelap atau terang.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">⏻</span><div><div class="header-guide-title">Keluar</div><div class="header-guide-desc">Logout dari akun staff di perangkat ini.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">!</span><div><div class="header-guide-title">Catatan Refresh</div><div class="header-guide-desc">Pakai refresh saat data belum masuk, bonus belum berubah, atau transaksi gagal.</div></div></div></div></div>`;
  }

  function renderHeaderGuideNoteControlBody() {
    const note = getHeaderGuideNoteText();
    const updatedBy = cachedHeaderGuideNote?.updatedByName || cachedHeaderGuideNote?.updatedBy || '-';
    const updatedAtMs = Number(cachedHeaderGuideNote?.updatedAtMs || 0);
    const updatedText = updatedAtMs ? new Date(updatedAtMs).toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' }) : 'Default aplikasi';
    return `
      <div style="display:flex;flex-direction:column;gap:9px">
        <div>
          <p class="label-xs" style="margin-bottom:6px">Catatan Saat Panduan Disembunyikan</p>
          <textarea id="header-guide-note-input" class="g-input" rows="5" maxlength="280" style="resize:vertical;min-height:104px;line-height:1.45">${escapeHtml(note)}</textarea>
          <p style="font-size:10.5px;color:var(--text-soft);margin-top:6px;line-height:1.35">Teks ini tampil di card <b>Catatan Bonus</b> ketika Panduan Icon Header disembunyikan staff/harian.</p>
        </div>
        <div>
          <p class="label-xs" style="margin-bottom:6px">Preview</p>
          <div class="header-guide-note-preview">“${escapeHtml(note)}”</div>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <span style="font-size:10.5px;color:var(--text-soft)">Update: ${escapeHtml(updatedText)} · ${escapeHtml(updatedBy)}</span>
          <div style="display:flex;gap:7px">
            <button onclick="resetHeaderGuideNoteInput()" class="btn btn-glass" style="padding:9px 10px;font-size:11.5px">Default</button>
            <button onclick="saveHeaderGuideNote()" class="btn btn-primary" style="padding:9px 12px;font-size:11.5px"><i class="fas fa-save"></i> Simpan</button>
          </div>
        </div>
      </div>`;
  }

  async function saveHeaderGuideNote() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const note = String($('header-guide-note-input')?.value || '').trim();
    if (!note) return showToast('Catatan tidak boleh kosong', true);
    if (note.length > 280) return showToast('Catatan maksimal 280 karakter', true);
    const pin = await askPin('Simpan catatan Panduan Icon Header?\nMasukkan PIN admin:');
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin, 'PIN admin salah!'))) return;
    setLoading(true);
    try {
      const payload = {
        id: HEADER_GUIDE_NOTE_DOC_ID,
        type: 'header_guide_note',
        note,
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, 'closings', HEADER_GUIDE_NOTE_DOC_ID), payload, { merge: true });
      cachedHeaderGuideNote = { ...cachedHeaderGuideNote, ...payload };
      await logAudit('header_guide_note_update', { note });
      showToast('✓ Catatan panduan disimpan');
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan catatan panduan', true);
    }
    setLoading(false);
  }

  function resetHeaderGuideNoteInput() {
    const input = $('header-guide-note-input');
    if (input) input.value = DEFAULT_HEADER_GUIDE_NOTE;
  }


  function receiptCleanLine(value, fallback = '', max = 42) {
    const s = String(value ?? '').replace(/[\x00-\x1F\x7F]/g, ' ').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim();
    const out = s || fallback;
    return String(out || '').slice(0, max);
  }

  function receiptCleanMultiline(value, fallback = '', maxLines = 4, maxEach = 42) {
    const lines = String(value ?? '').split(/\r?\n/).map(v => receiptCleanLine(v, '', maxEach)).filter(Boolean).slice(0, maxLines);
    return lines.length ? lines.join('\n') : fallback;
  }

  function normalizeReceiptTextSettings(raw = {}) {
    const merged = { ...DEFAULT_RECEIPT_TEXT_SETTINGS, ...(raw || {}) };
    const feed = Math.round(Number(merged.bottomFeedLines ?? DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines));
    const bottomFeedLines = Math.max(0, Math.min(20, Number.isFinite(feed) ? feed : DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines));
    return {
      id: RECEIPT_TEXT_DOC_ID,
      storeName: receiptCleanLine(merged.storeName, DEFAULT_RECEIPT_TEXT_SETTINGS.storeName),
      storeSubtext: receiptCleanMultiline(merged.storeSubtext, '', 4),
      dailyTitle: receiptCleanLine(merged.dailyTitle, DEFAULT_RECEIPT_TEXT_SETTINGS.dailyTitle),
      dateLabel: receiptCleanLine(merged.dateLabel, DEFAULT_RECEIPT_TEXT_SETTINGS.dateLabel, 12),
      cashierLabel: receiptCleanLine(merged.cashierLabel, DEFAULT_RECEIPT_TEXT_SETTINGS.cashierLabel, 12),
      productLabel: receiptCleanLine(merged.productLabel, DEFAULT_RECEIPT_TEXT_SETTINGS.productLabel, 12),
      totalLabel: receiptCleanLine(merged.totalLabel, DEFAULT_RECEIPT_TEXT_SETTINGS.totalLabel, 12),
      countLabel: receiptCleanLine(merged.countLabel, DEFAULT_RECEIPT_TEXT_SETTINGS.countLabel, 12),
      footerText: receiptCleanMultiline(merged.footerText, DEFAULT_RECEIPT_TEXT_SETTINGS.footerText, 3),
      bottomFeedLines,
      updatedAtMs: Number(merged.updatedAtMs || 0),
      updatedBy: merged.updatedBy || '',
      updatedByName: merged.updatedByName || ''
    };
  }

  function getReceiptTextSettings() {
    return normalizeReceiptTextSettings(cachedReceiptTextSettings || DEFAULT_RECEIPT_TEXT_SETTINGS);
  }

  // Alias aman untuk fitur backup/restore.
  // Versi sebelumnya memanggil getReceiptTextSettingsSafe(), tapi fungsi itu belum ada
  // sehingga Backup JSON dan Excel gagal sebelum file sempat diunduh.
  function getReceiptTextSettingsSafe() {
    try {
      return getReceiptTextSettings();
    } catch (e) {
      console.warn('Fallback setting struk untuk backup:', e);
      return normalizeReceiptTextSettings(DEFAULT_RECEIPT_TEXT_SETTINGS);
    }
  }

  function receiptSettingInputValue(id) {
    return String(document.getElementById(id)?.value || '');
  }

  function collectReceiptTextSettingsFromForm() {
    return normalizeReceiptTextSettings({
      storeName: receiptSettingInputValue('receipt-store-name'),
      storeSubtext: receiptSettingInputValue('receipt-store-subtext'),
      dailyTitle: receiptSettingInputValue('receipt-daily-title'),
      dateLabel: receiptSettingInputValue('receipt-date-label'),
      cashierLabel: receiptSettingInputValue('receipt-cashier-label'),
      productLabel: receiptSettingInputValue('receipt-product-label'),
      totalLabel: receiptSettingInputValue('receipt-total-label'),
      countLabel: receiptSettingInputValue('receipt-count-label'),
      footerText: receiptSettingInputValue('receipt-footer-text'),
      bottomFeedLines: receiptSettingInputValue('receipt-bottom-feed-lines')
    });
  }

  function receiptPreviewLabel(label, width = 8) {
    const s = receiptCleanLine(label, '-', 12);
    return `${s.length < width ? s.padEnd(width, ' ') : s} :`;
  }
  function receiptPreviewSummaryLabel(label) {
    return receiptPreviewLabel(label, 11);
  }

  function buildReceiptSettingsPreview(settings = getReceiptTextSettings()) {
    const s = normalizeReceiptTextSettings(settings);
    const width = 32;
    const separator = receiptLine(width);
    const header = [s.storeName, ...String(s.storeSubtext || '').split(/\n/).filter(Boolean)].join('\n');
    const footer = String(s.footerText || DEFAULT_RECEIPT_TEXT_SETTINGS.footerText).split(/\n/).filter(Boolean).join('\n');
    return `${header}\n${separator}\n${receiptPreviewLabel(s.dateLabel)} 03/05/2026 21:30\n${receiptPreviewLabel(s.cashierLabel)} Rocky\n${s.productLabel}:\n> Hijab Paris\n${separator}\n> Pasmina\n${separator}\n> Brego\n${separator}\n\n${receiptPreviewSummaryLabel('Total Bayar')} Rp 125.000\n${receiptPreviewSummaryLabel('Bayar')} QRIS / Transfer\n${separator}\n${footer}\n${'\n'.repeat(s.bottomFeedLines)}`;
  }

  function renderReceiptTextSettingsBody() {
    const s = getReceiptTextSettings();
    const updatedAtMs = Number(s.updatedAtMs || 0);
    const updatedBy = s.updatedByName || s.updatedBy || '-';
    return `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px">
        <div style="font-size:11px;color:var(--text-soft);line-height:1.4">Setting ini hanya muncul di admin dan dipakai untuk format struk transaksi.</div>
        <span class="status-pill status-ok" style="white-space:nowrap"><i class="fas fa-receipt"></i> Admin</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div><p class="label-xs">Nama Toko/Header</p><input id="receipt-store-name" class="g-input" maxlength="42" value="${escapeHtml(s.storeName)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Judul Struk Harian</p><input id="receipt-daily-title" class="g-input" maxlength="42" value="${escapeHtml(s.dailyTitle)}" oninput="updateReceiptSettingsPreview()"></div>
        </div>
        <div><p class="label-xs">Teks Kecil di Bawah Header</p><textarea id="receipt-store-subtext" class="g-input" rows="3" maxlength="180" style="min-height:74px;resize:vertical" placeholder="Opsional" oninput="updateReceiptSettingsPreview()">${escapeHtml(s.storeSubtext)}</textarea></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <div><p class="label-xs">Label Tanggal</p><input id="receipt-date-label" class="g-input" maxlength="12" value="${escapeHtml(s.dateLabel)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Label Kasir</p><input id="receipt-cashier-label" class="g-input" maxlength="12" value="${escapeHtml(s.cashierLabel)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Label Produk</p><input id="receipt-product-label" class="g-input" maxlength="12" value="${escapeHtml(s.productLabel)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Label Total</p><input id="receipt-total-label" class="g-input" maxlength="12" value="${escapeHtml(s.totalLabel)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Label Jumlah</p><input id="receipt-count-label" class="g-input" maxlength="12" value="${escapeHtml(s.countLabel)}" oninput="updateReceiptSettingsPreview()"></div>
          <div><p class="label-xs">Jarak Bawah Sobek</p><input id="receipt-bottom-feed-lines" type="number" inputmode="numeric" min="0" max="20" class="g-input" value="${Number(s.bottomFeedLines || 6)}" oninput="updateReceiptSettingsPreview()"></div>
        </div>
        <div><p class="label-xs">Footer / Penutup Struk</p><textarea id="receipt-footer-text" class="g-input" rows="3" maxlength="120" style="min-height:74px;resize:vertical" oninput="updateReceiptSettingsPreview()">${escapeHtml(s.footerText)}</textarea></div>
        <div style="border:1px dashed var(--border);border-radius:14px;background:var(--surface);padding:10px 11px">
          <p class="label-xs" style="margin-bottom:6px">Preview Struk</p>
          <pre id="receipt-settings-preview" style="font-family:'Courier New',monospace;font-size:11px;line-height:1.35;white-space:pre-wrap;color:var(--text);max-height:230px;overflow:auto">${escapeHtml(buildReceiptSettingsPreview(s))}</pre>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button onclick="resetReceiptTextSettingsForm()" class="btn btn-glass" style="padding:11px;font-size:12px"><i class="fas fa-rotate-left"></i> Default</button>
          <button onclick="saveReceiptTextSettings()" class="btn btn-primary" style="padding:11px;font-size:12px"><i class="fas fa-save"></i> Simpan Setting Struk</button>
        </div>
        <p style="font-size:10.5px;color:var(--text-soft);line-height:1.35">Terakhir update: ${updatedAtMs ? new Date(updatedAtMs).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-'} · ${escapeHtml(updatedBy)}</p>
      </div>`;
  }

  function updateReceiptSettingsPreview() {
    const el = document.getElementById('receipt-settings-preview');
    if (!el) return;
    el.textContent = buildReceiptSettingsPreview(collectReceiptTextSettingsFromForm());
  }

  function resetReceiptTextSettingsForm() {
    const s = normalizeReceiptTextSettings(DEFAULT_RECEIPT_TEXT_SETTINGS);
    const set = (id, value) => { const el = document.getElementById(id); if (el) el.value = value; };
    set('receipt-store-name', s.storeName);
    set('receipt-store-subtext', s.storeSubtext);
    set('receipt-daily-title', s.dailyTitle);
    set('receipt-date-label', s.dateLabel);
    set('receipt-cashier-label', s.cashierLabel);
    set('receipt-product-label', s.productLabel);
    set('receipt-total-label', s.totalLabel);
    set('receipt-count-label', s.countLabel);
    set('receipt-footer-text', s.footerText);
    set('receipt-bottom-feed-lines', s.bottomFeedLines);
    updateReceiptSettingsPreview();
  }

  async function saveReceiptTextSettings() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const next = collectReceiptTextSettingsFromForm();
    const pin = await askPin('Simpan setting tulisan struk?\nMasukkan PIN admin:');
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const payload = {
        ...next,
        id: RECEIPT_TEXT_DOC_ID,
        dateKey: RECEIPT_TEXT_DOC_ID,
        closed: false,
        type: 'receipt_text_settings',
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, 'closings', RECEIPT_TEXT_DOC_ID), payload, { merge: true });
      cachedReceiptTextSettings = normalizeReceiptTextSettings(payload);
      await logAudit('receipt_text_settings_update', { storeName: next.storeName, footerText: next.footerText, bottomFeedLines: next.bottomFeedLines });
      showToast('✓ Setting tulisan struk disimpan');
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan setting struk: ' + (e.code || e.message || 'cek Supabase'), true);
    }
    setLoading(false);
  }

  function updateLocation() {
    const info = $('loc-info'); if (!info) return;
    info.innerHTML = `<span class="loc-chip loc-loading"><i class="fas fa-circle-notch fa-spin" style="font-size:10px"></i> Mencari GPS...</span>`;
    if (!navigator.geolocation) {
      info.innerHTML = `<span class="loc-chip loc-out"><i class="fas fa-xmark"></i> GPS tidak didukung</span>`; return;
    }
    navigator.geolocation.getCurrentPosition(pos => {
      currentPos = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      const dist = calculateDistance(currentPos.lat, currentPos.lng, OFFICE_LOC.lat, OFFICE_LOC.lng);
      info.innerHTML = dist <= RADIUS_LIMIT
        ? `<span class="loc-chip loc-in"><i class="fas fa-circle" style="font-size:6px"></i> Dalam Radius · ${Math.round(dist)}m</span>`
        : `<span class="loc-chip loc-out"><i class="fas fa-xmark"></i> Diluar Radius · ${Math.round(dist)}m</span>`;
      updateHomeStatus();
    }, () => {
      info.innerHTML = `<span class="loc-chip loc-out"><i class="fas fa-triangle-exclamation"></i> Gagal ambil lokasi</span>`;
    }, { enableHighAccuracy:true, timeout:10000, maximumAge:30000 });
  }

  function formatMoneyInputElement(el) {
    if (!el) return;
    const numeric = (el.value || '').replace(/\D/g, '');
    const value = parseInt(numeric || '0', 10);
    el.setAttribute('data-numeric', String(value));
    el.value = numeric ? formatRupiah(value) : '';
  }

  function bindTransactionAmountFormatter(inputId) {
    const input = $(inputId);
    if (!input || input.dataset.bound === 'true') return;
    input.dataset.bound = 'true';
    input.addEventListener('input', function () {
      const numeric = (this.value || '').replace(/\D/g, '');
      const value = parseInt(numeric || '0', 10);
      this.setAttribute('data-numeric', String(value));
      this.value = numeric ? formatRupiah(value) : '';
    });
  }

  let modalTransactionItems = [];
  function normalizeTransactionProductName(value) {
    return String(value || '').replace(/\s+/g, ' ').trim().toUpperCase();
  }
  function forceUppercaseInputValue(el) {
    if (!el) return;
    const oldValue = String(el.value || '');
    const nextValue = oldValue.toUpperCase();
    if (oldValue === nextValue) return;
    const start = el.selectionStart, end = el.selectionEnd;
    el.value = nextValue;
    try {
      if (typeof start === 'number' && typeof end === 'number') el.setSelectionRange(start, end);
    } catch (_) {}
  }
  function transactionProductItemsFromText(text, fallback = 'Transaksi') {
    const rows = String(text || '').split(/\r?\n/).map(normalizeTransactionProductName).filter(Boolean);
    return rows.length ? rows : [fallback];
  }
  function transactionProductTextFromItems(items, fallback = 'Transaksi') {
    const rows = (Array.isArray(items) ? items : []).map(normalizeTransactionProductName).filter(Boolean);
    return rows.length ? rows.join('\n') : fallback;
  }

  // Cache untuk getModalTransactionProductText
  let _lastModalTransactionProductTextCache = '';
  let _lastModalTransactionItemsCache = ''; // JSON.stringify dari modalTransactionItems
  let _lastModalPosItemValueCache = '';

  function getModalTransactionProductText(forceRecalculate = false) {
    const currentModalPosItemValue = normalizeTransactionProductName($('modal-pos-item')?.value || '');
    const currentModalTransactionItemsString = JSON.stringify(modalTransactionItems); // Gunakan stringify sebagai hash konten array

    if (!forceRecalculate &&
        currentModalTransactionItemsString === _lastModalTransactionItemsCache &&
        currentModalPosItemValue === _lastModalPosItemValueCache) {
      return _lastModalTransactionProductTextCache; // Kembalikan nilai cache jika tidak ada perubahan
    }

    const rows = [...modalTransactionItems];
    if (currentModalPosItemValue) rows.push(currentModalPosItemValue);
    const newText = transactionProductTextFromItems(rows, 'Transaksi');

    _lastModalTransactionItemsCache = currentModalTransactionItemsString;
    _lastModalPosItemValueCache = currentModalPosItemValue;
    _lastModalTransactionProductTextCache = newText;

    return newText;
  }
  function renderModalTransactionItems() {
    const input = $('modal-pos-item');
    const add = $('modal-pos-item-add');
    const list = $('modal-pos-item-list');
    const hidden = $('modal-pos-note');
    forceUppercaseInputValue(input);
    if (add) add.disabled = !String(input?.value || '').trim();
    // Hanya update hidden.value jika nilainya benar-benar berubah
    const currentProductText = getModalTransactionProductText();
    if (hidden && hidden.value !== currentProductText) {
      hidden.value = currentProductText;
    }
    if (!list) return;
    if (!modalTransactionItems.length) {
      list.innerHTML = '<div class="modal-product-empty">Ketik 1 barang boleh langsung Simpan/Cetak. Tombol tambah hanya untuk barang berikutnya.</div>';
      return;
    }
    list.innerHTML = modalTransactionItems.map((item, index) => `
      <div class="modal-product-row">
        <span class="modal-product-name">${escapeHtml(item)}</span>
        <button type="button" class="modal-product-remove" onclick="removeModalTransactionItem(${index})">Hapus</button>
      </div>`).join('');
  }
  function resetModalTransactionItems(note = '') {
    const text = String(note || '').trim();
    modalTransactionItems = text && text !== 'Transaksi' ? transactionProductItemsFromText(text, 'Transaksi') : [];
    renderModalTransactionItems();
  }
  function updateModalTransactionItemButton() { renderModalTransactionItems(); }
  function addModalTransactionItem() {
    const input = $('modal-pos-item');
    const value = normalizeTransactionProductName(input?.value || '');
    if (!value) { renderModalTransactionItems(); input?.focus?.(); return; }
    modalTransactionItems.push(value);
    if (input) input.value = '';
    renderModalTransactionItems();
    setTimeout(() => input?.focus?.(), 0);
  }
  function removeModalTransactionItem(index) {
    const i = Number(index);
    if (Number.isInteger(i) && i >= 0 && i < modalTransactionItems.length) modalTransactionItems.splice(i, 1);
    renderModalTransactionItems();
    setTimeout(() => $('modal-pos-item')?.focus?.(), 0);
  }
  function handleModalTransactionItemKey(e) {
    if (e?.key === 'Enter') {
      e.preventDefault();
      addModalTransactionItem();
    }
  }
  function transactionProductListHtml(note) {
    return transactionProductReceiptHtml(note);
  }
  function transactionProductDetailHtml(note) {
    return transactionProductReceiptHtml(note);
  }
  function transactionProductReceiptHtml(note) {
    const items = transactionProductItemsFromText(note, 'Transaksi');
    return `<div class="trx-product-receipt-list">${items.map(item => `<div class="trx-product-receipt-row">${escapeHtml('> ' + item)}</div>`).join('')}</div>`;
  }
  function transactionHistoryTimeLabel(t) {
    const txMs = getRecordTimeMs(t);
    return txMs ? dateToTimeInput(new Date(txMs)) : formatDateLabel(getTransactionDateKey(t));
  }
  function closeTransactionDetail() {
    const old = $('transaction-detail-modal');
    if (old) old.remove();
  }
  function openTransactionDetail(id) {
    const t = (cachedTransactions || []).find(x => String(x.id) === String(id));
    if (!t) return showToast('Transaksi tidak ditemukan', true);
    const txName = t.name || t.user || '-';
    const payLabel = getTransactionPaymentLabel(t);
    const itemCount = transactionProductItemsFromText(t.note || 'Transaksi', 'Transaksi').length;
    closeTransactionDetail();
    const wrap = document.createElement('div');
    wrap.id = 'transaction-detail-modal';
    wrap.className = 'modal-wrap show';
    wrap.style.zIndex = '430';
    wrap.style.alignItems = 'center';
    wrap.style.justifyContent = 'center';
    wrap.innerHTML = `
      <div class="modal-sheet modal-sheet-wide" style="max-width:480px;border-radius:22px;padding:18px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:15px">
          <div style="min-width:0">
            <h3 style="font-size:16px;font-weight:900;letter-spacing:-.02em">Detail Transaksi</h3>
            <p style="font-size:11px;color:var(--text-soft);margin-top:3px;font-weight:600">${escapeHtml(txName)} · ${itemCount} Item</p>
          </div>
          <button onclick="closeTransactionDetail()" class="btn btn-glass" style="width:36px;height:36px;padding:0;border-radius:12px"><i class="fas fa-xmark"></i></button>
        </div>
        
        <div class="card" style="background:var(--accent-dim)!important;border-color:var(--accent-glow)!important;padding:15px!important;margin-bottom:12px;box-shadow:none">
          <p class="label-xs" style="color:var(--accent);margin-bottom:6px">Total Pembayaran</p>
          <p class="trx-amount" style="font-size:24px;color:var(--text);margin:0">Rp ${formatRupiah(t.amount)}</p>
          <div style="display:flex;align-items:center;gap:6px;margin-top:8px">
            <span style="font-size:11px;color:var(--text-soft);font-weight:700">${transactionHistoryTimeLabel(t)}</span>
            <span style="width:3px;height:3px;border-radius:50%;background:var(--text-ghost)"></span>
            ${getTransactionPaymentBadge(t)}
          </div>
        </div>

        <div class="card" style="padding:15px!important;box-shadow:none">
          <p class="label-xs" style="margin-bottom:12px">Rincian Produk</p>
          ${transactionProductDetailHtml(t.note || 'Transaksi')}
        </div>
      </div>`;
    document.body.appendChild(wrap);
    wrap.addEventListener('click', e => { if (e.target === wrap) closeTransactionDetail(); });
  }


  let receiptPreviewText = '';
  let receiptPreviewTitle = 'Struk Transaksi';

  function receiptPadLine(left, right, width = 40) {
    left = String(left || '').slice(0, width);
    right = String(right || '').slice(0, width);
    const space = Math.max(1, width - left.length - right.length);
    return left + ' '.repeat(space) + right;
  }
  function receiptLine(width = 40) { return '-'.repeat(width); }
  function receiptDateTime(ms) {
    const d = ms ? new Date(ms) : nowDate();
    try {
      return new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Jakarta',
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }).format(d).replace(',', '');
    } catch (_) {
      const pad = (n) => String(n).padStart(2, '0');
      return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }
  }
  function receiptValueLine(label = '', value = '') {
    const cleanLabel = receiptCleanLine(label || '-', '-', 10).slice(0, 7).padEnd(7, ' ');
    return `${cleanLabel} : ${String(value ?? '').trim()}`;
  }
  function receiptSummaryValueLine(label = '', value = '') {
    const cleanLabel = receiptCleanLine(label || '-', '-', 12).padEnd(11, ' ');
    return `${cleanLabel} : ${String(value ?? '').trim()}`;
  }
  function receiptProductItems(note) {
    return transactionProductItemsFromText(note, 'Transaksi').map(x => receiptCleanLine(x, '', 28)).filter(Boolean);
  }
  function receiptProductMarkedLines(note, indent = '') {
    const items = receiptProductItems(note);
    return items.flatMap(item => [`${indent}> ${item}`, `${indent}${receiptLine(32)}`]);
  }
  function buildTransactionReceiptText(tx = {}) {
    const s = getReceiptTextSettingsSafe();
    const width = 32;
    const lines = [];
    const storeName = receiptCleanLine(s.storeName, 'ROCKY HIJAB', width);
    if (storeName) lines.push(storeName);
    String(s.storeSubtext || '').split(/\r?\n/).map(x => receiptCleanLine(x, '', width)).filter(Boolean).forEach(x => lines.push(x));
    lines.push(receiptLine(width));
    lines.push(receiptValueLine(s.dateLabel || 'Tanggal', receiptDateTime(getRecordTimeMs(tx))));
    lines.push(receiptValueLine(s.cashierLabel || 'Kasir', receiptCleanLine(tx.name || tx.user || currentUser?.name || '-', '-', 22)));
    lines.push(`${receiptCleanLine(s.productLabel || 'Produk', 'Produk', 12)}:`);
    lines.push(...receiptProductMarkedLines(tx.note));
    lines.push('');
    lines.push(receiptSummaryValueLine('Total Bayar', 'Rp ' + formatRupiah(tx.amount || 0)));
    lines.push(receiptSummaryValueLine('Bayar', getTransactionPaymentLabel(tx)));
    lines.push(receiptLine(width));
    String(s.footerText || 'Terima kasih').split(/\r?\n/).map(x => receiptCleanLine(x, '', width)).filter(Boolean).forEach(x => lines.push(x));
    lines.push('');
    return lines.join('\n') + '\n'.repeat(Math.max(1, Math.min(20, Number(s.bottomFeedLines || 4))));
  }
  function openReceiptPreview(text, title = 'Struk Transaksi') {
    receiptPreviewText = String(text || '');
    receiptPreviewTitle = String(title || 'Struk Transaksi');
    const titleEl = $('receipt-preview-title');
    const textEl = $('receipt-preview-text');
    const modal = $('receipt-preview-modal');
    if (titleEl) titleEl.textContent = receiptPreviewTitle;
    if (textEl) textEl.textContent = receiptPreviewText;
    if (modal) { modal.classList.add('show'); modal.style.display = 'flex'; }
  }
  function closeReceiptPreview() {
    const modal = $('receipt-preview-modal');
    if (modal) { modal.classList.remove('show'); modal.style.display = 'none'; }
  }
  function nativePrintReceiptText() {
    const text = receiptPreviewText || '';
    if (!text) return showToast('Struk kosong', true);
    const bridges = [window.Android, window.AndroidPrinter, window.AndroidPrinterBridge].filter(Boolean);
    for (const bridge of bridges) {
      if (typeof bridge.printReceipt === 'function') {
        const ok = bridge.printReceipt(text);
        if (ok === false) showToast('Izinkan Nearby devices/Bluetooth, lalu struk akan dicetak otomatis.', false);
        return;
      }
    }
    showToast('Cetak aktif saat dibuka dari APK Android Studio', true);
  }
  function directPrintReceiptText(text, title = 'Struk Transaksi') {
    receiptPreviewText = String(text || '');
    receiptPreviewTitle = String(title || 'Struk Transaksi');
    nativePrintReceiptText();
  }
  function printTransactionReceipt(id) {
    const tx = cachedTransactions.find(t => String(t.id) === String(id));
    if (!tx) return showToast('Transaksi tidak ditemukan!', true);
    openReceiptPreview(buildTransactionReceiptText(tx), `Struk · ${formatDateLabel(getTransactionDateKey(tx))}`);
  }

  async function openTransactionModal() {
    if (!currentUser) return showToast('Silakan login dulu!', true);
    transactionEditTargetId = null;
    const modal = $('transaction-modal');
    if (modal) {
      const sheet = modal.querySelector('.modal-sheet');
      if (sheet) sheet.classList.add('modal-sheet-wide');
    }
    bindTransactionAmountFormatter('modal-pos-amount');
    setTransactionUserSelect(currentUser?.username || '');
    modal.classList.add('show');
    modal.style.display = 'flex';
    if ($('transaction-modal-title')) $('transaction-modal-title').innerText = 'Transaksi';
    if ($('transaction-modal-save-btn')) $('transaction-modal-save-btn').innerText = 'Simpan';
    if ($('transaction-modal-print-btn')) $('transaction-modal-print-btn').style.display = 'inline-flex';
    if ($('transaction-modal-actions')) $('transaction-modal-actions').style.gridTemplateColumns = '1fr 1fr 1fr';
    resetModalTransactionItems('');
    $('modal-pos-amount').value = '';
    $('modal-pos-amount').setAttribute('data-numeric', '0');
    const statusBox = $('modal-pos-status');
    if (isAdmin()) {
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--accent-dim);border:1px solid rgba(91,143,255,0.18);border-radius:11px"><i class="fas fa-bolt" style="color:var(--accent);font-size:13px"></i><span style="font-size:12.5px;color:var(--accent);font-weight:600">Admin bisa transaksi langsung tanpa absen</span></div>`;
    } else if (isTransactionsClosedToday()) {
      const closing = getTodayClosing();
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--amber-dim);border:1px solid rgba(255,196,107,0.2);border-radius:11px"><i class="fas fa-lock" style="color:var(--amber);font-size:13px"></i><span style="font-size:12.5px;color:var(--amber);font-weight:600">Transaksi sudah closing hari ini. Terbuka otomatis besok.</span></div>`;
    } else if (isDailyEmployee(currentUser)) {
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--accent-dim);border:1px solid rgba(91,143,255,0.18);border-radius:11px"><i class="fas fa-user-check" style="color:var(--accent);font-size:13px"></i><span style="font-size:12.5px;color:var(--accent);font-weight:600">Karyawan Harian</span></div>`;
    } else if (!attendanceReady) {
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--surface);border:1px solid var(--border);border-radius:11px"><i class="fas fa-circle-notch fa-spin" style="color:var(--text-soft);font-size:13px"></i><span style="font-size:12.5px;color:var(--text-soft);font-weight:600">Memeriksa absensi hari ini...</span></div>`;
    } else if (canTransactNow()) {
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--green-dim);border:1px solid rgba(82,216,158,0.18);border-radius:11px"><i class="fas fa-circle-check" style="color:var(--green);font-size:13px"></i><span style="font-size:12.5px;color:var(--green);font-weight:600">Siap melakukan transaksi</span></div>`;
    } else {
      statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--red-dim);border:1px solid rgba(255,107,107,0.2);border-radius:11px"><i class="fas fa-circle-xmark" style="color:var(--red);font-size:13px"></i><span style="font-size:12.5px;color:var(--red);font-weight:600">Absen dulu sebelum transaksi!</span></div>`;
    }
    setTimeout(() => $('modal-pos-item')?.focus?.(), 100);
  }
  function closeTransactionModal() {
    closeTransactionPaymentModal(true);
    transactionEditTargetId = null;
    const modal = $('transaction-modal'); if (!modal) return;
    modal.classList.remove('show'); modal.style.display = 'none';
  }
  function openTransactionPaymentModal(draft) {
    pendingTransactionPaymentDraft = { ...(draft || {}) };
    transactionPaymentSubmitting = false;
    const modal = $('transaction-payment-modal');
    const box = $('transaction-payment-summary');
    if (box) {
      const isEditPayment = !!pendingTransactionPaymentDraft.isEdit;
      const txUsername = sanitizeUsername(pendingTransactionPaymentDraft.username || currentUser?.username || '');
      const txUserLabel = txUsername ? `${pendingTransactionPaymentDraft.name || txUsername} (@${txUsername})` : '';
      box.innerHTML = `<p class="label-xs" style="margin-bottom:6px">${isEditPayment ? 'Konfirmasi edit transaksi' : 'Konfirmasi transaksi'}</p>${txUserLabel ? `<p style="font-size:12px;color:var(--text-soft);font-weight:800;margin-bottom:7px"><i class="fas fa-user"></i> ${escapeHtml(txUserLabel)}</p>` : ''}<p style="font-family:var(--num-font);font-size:24px;font-weight:800;color:var(--accent);line-height:1">Rp ${formatRupiah(pendingTransactionPaymentDraft.amount || 0)}</p><p style="font-size:12px;color:var(--text);font-weight:700;margin-top:8px;white-space:pre-wrap;word-break:break-word">${escapeHtml(pendingTransactionPaymentDraft.note || 'Transaksi')}</p><p style="font-size:11px;color:var(--text-soft);margin-top:8px">${isEditPayment ? 'Pilih metode pembayaran baru. Edit akan disimpan dengan field Cash atau QRIS / Transfer agar selaras dengan aplikasi lain.' : 'Transaksi belum dikirim ke Supabase. Pilih salah satu metode untuk menyimpan sebagai sukses.'}</p>`;
    }
    if (modal) { modal.classList.add('show'); modal.style.display = 'flex'; }
  }
  function closeTransactionPaymentModal(clearDraft = false) {
    const modal = $('transaction-payment-modal');
    if (modal) { modal.classList.remove('show'); modal.style.display = 'none'; }
    transactionPaymentSubmitting = false;
    document.querySelectorAll('[data-transaction-payment-choice]').forEach(b => {
      b.disabled = false;
      b.style.opacity = '';
      if (b.dataset.originalHtml) b.innerHTML = b.dataset.originalHtml;
      b.removeAttribute('aria-busy');
    });
    if (clearDraft) pendingTransactionPaymentDraft = null;
  }
  function handleTransactionModalSave() {
    if (transactionEditTargetId) return saveEditedTransaction();
    return prepareTransactionPaymentFromModal(false);
  }
  function handleTransactionModalPrint() {
    if (transactionEditTargetId) return saveEditedTransaction();
    return prepareTransactionPaymentFromModal(true);
  }

  function openEditTransactionModal(id) {
    if (!currentUser) return showToast('Silakan login dulu!', true);
    const trx = cachedTransactions.find(t => t.id === id);
    if (!trx) return showToast('Transaksi tidak ditemukan!', true);
    if (trx.user !== currentUser.username && !isAdmin()) return showToast('Tidak bisa edit transaksi orang lain!', true);
    if (isRecordDeleted(trx)) return showToast('Transaksi terhapus tidak bisa diedit.', true);
    transactionEditTargetId = id;
    bindTransactionAmountFormatter('modal-pos-amount');
    setTransactionUserSelect(trx.user || currentUser?.username || '');
    const modal = $('transaction-modal');
    if (modal) {
      const sheet = modal.querySelector('.modal-sheet');
      if (sheet) sheet.classList.add('modal-sheet-wide');
    }
    if ($('transaction-modal-title')) $('transaction-modal-title').innerText = 'Edit Transaksi';
    if ($('transaction-modal-save-btn')) $('transaction-modal-save-btn').innerText = 'Simpan Edit';
    if ($('transaction-modal-print-btn')) $('transaction-modal-print-btn').style.display = 'none';
    if ($('transaction-modal-actions')) $('transaction-modal-actions').style.gridTemplateColumns = '1fr 1fr';
    const amountInput = $('modal-pos-amount');
    resetModalTransactionItems(String(trx.note || 'Transaksi'));
    if (amountInput) {
      const amount = Number(trx.amount || 0);
      amountInput.setAttribute('data-numeric', String(amount));
      amountInput.value = amount ? formatRupiah(amount) : '';
    }
    const statusBox = $('modal-pos-status');
    if (statusBox) statusBox.innerHTML = `<div style="display:flex;align-items:center;gap:9px;padding:11px 13px;background:var(--amber-dim);border:1px solid rgba(255,196,107,0.2);border-radius:11px"><i class="fas fa-pen-to-square" style="color:var(--amber);font-size:13px"></i><span style="font-size:12.5px;color:var(--amber);font-weight:600">Mode edit: ubah user, catatan, nominal, lalu pilih Cash atau QRIS / Transfer.</span></div>`;
    if (modal) { modal.classList.add('show'); modal.style.display = 'flex'; }
    setTimeout(() => $('modal-pos-item')?.focus?.(), 100);
  }

  async function saveEditedTransaction() {
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const id = transactionEditTargetId;
    const trx = cachedTransactions.find(t => String(t.id) === String(id));
    if (!trx) return showToast('Transaksi tidak ditemukan!', true);
    if (trx.user !== currentUser.username && !isAdmin()) return showToast('Tidak bisa edit transaksi orang lain!', true);
    const amount = parseInt($('modal-pos-amount')?.getAttribute('data-numeric') || '0', 10);
    const note = getModalTransactionProductText();
    const selectedUser = getSelectedTransactionUser(trx.user || currentUser?.username || '');
    if (!selectedUser) return showToast('Pilih user transaksi!', true);
    if (!isAdmin() && sanitizeUsername(selectedUser.username) !== sanitizeUsername(currentUser?.username || '')) return showToast('Tidak bisa pilih user lain!', true);
    if (!amount || amount <= 0) return showToast('Nominal tidak valid!', true);
    openTransactionPaymentModal({
      id,
      isEdit: true,
      username: sanitizeUsername(selectedUser.username),
      name: selectedUser.name || selectedUser.username,
      amount,
      note,
      oldAmount: Number(trx.amount || 0),
      oldNote: trx.note || 'Transaksi',
      printAfterSave: false
    });
  }

  function prepareTransactionPaymentFromModal(printAfterSave = false) {
    if (isBusy) return;
    const amount = parseInt($('modal-pos-amount')?.getAttribute('data-numeric') || '0', 10);
    const note = getModalTransactionProductText();
    const selectedUser = getSelectedTransactionUser(currentUser?.username || '');
    if (!selectedUser) return showToast('Pilih user transaksi!', true);
    if (!isAdmin() && sanitizeUsername(selectedUser.username) !== sanitizeUsername(currentUser?.username || '')) return showToast('Tidak bisa pilih user lain!', true);
    if (!amount || amount <= 0) return showToast('Nominal tidak valid!', true);
    openTransactionPaymentModal({ username: sanitizeUsername(selectedUser.username), name: selectedUser.name || selectedUser.username, amount, note, printAfterSave: Boolean(printAfterSave) });
  }
  async function confirmTransactionPayment(paymentMethod, btn, event) {
    try { event?.preventDefault?.(); event?.stopPropagation?.(); } catch (_) {}
    if (transactionPaymentSubmitting || isBusy) return;
    transactionPaymentSubmitting = true;
    const buttons = [...document.querySelectorAll('[data-transaction-payment-choice]')];
    buttons.forEach(b => { b.disabled = true; b.style.opacity = '.72'; b.setAttribute('aria-busy','true'); });
    if (btn) {
      btn.dataset.originalHtml = btn.dataset.originalHtml || btn.innerHTML;
      btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Menyimpan...';
    }
    try {
      await handleTransactionFromModal(paymentMethod);
    } finally {
      if (!isBusy) transactionPaymentSubmitting = false;
    }
  }

  async function handleTransactionFromModal(paymentMethod = '') {
    if (isBusy) return;
    const draft = pendingTransactionPaymentDraft || {};
    const amount = Number(draft.amount || parseInt($('modal-pos-amount')?.getAttribute('data-numeric') || '0', 10));
    const note = transactionProductTextFromItems(transactionProductItemsFromText(draft.note || getModalTransactionProductText(), 'Transaksi'), 'Transaksi');
    const targetUser = getSelectedTransactionUser(draft.username || currentUser?.username || '');
    const targetUsername = sanitizeUsername(draft.username || targetUser?.username || currentUser?.username || '');
    if (!targetUser || !targetUsername) return showToast('Pilih user transaksi!', true);
    if (!isAdmin() && targetUsername !== sanitizeUsername(currentUser?.username || '')) return showToast('Tidak bisa pilih user lain!', true);
    if (!amount || amount <= 0) return showToast('Nominal tidak valid!', true);
    const payment = normalizeTransactionPaymentMethod(paymentMethod);
    if (!payment) {
      openTransactionPaymentModal({ username: targetUsername, name: targetUser.name || targetUsername, amount, note, printAfterSave: Boolean(draft.printAfterSave) });
      return;
    }
    const paymentInfo = getTransactionPaymentInfo(payment);
    setLoading(true);
    try {
      if (draft.isEdit && draft.id) {
        const id = String(draft.id);
        const trx = cachedTransactions.find(t => String(t.id) === id);
        if (!trx) throw new Error('Transaksi tidak ditemukan');
        const editUserRole = normalizeRole(targetUser.role || trx.userRole || trx.role || 'staff');
        const editBonusGroup = editUserRole === 'harian' ? 'harian' : 'staff';
        const editBonus = getUserBonusSnapshot(targetUser);
        const editTrialFlags = getTrialFlags(targetUser);
        const patch = {
          user: targetUsername,
          name: targetUser.name || targetUsername,
          amount,
          note,
          userRole: editUserRole,
          role: editUserRole,
          bonusGroup: editBonusGroup,
          bonusRate: editBonus.transactionBonusRate,
          transactionBonusRate: editBonus.transactionBonusRate,
          bonusPercent: editBonus.transactionBonusPercent,
          transactionBonusPercent: editBonus.transactionBonusPercent,
          closingBonusPerMinuteSnapshot: editBonus.closingBonusPerMinute,
          ...editTrialFlags,
          paymentMethod: paymentInfo.method,
          paymentLabel: paymentInfo.label,
          paymentStatus: 'success',
          paymentCashOutType: paymentInfo.method === 'qris_transfer' ? 'qris' : '',
          isNonCashPayment: paymentInfo.method === 'qris_transfer',
          paymentConfirmed: true,
          paymentConfirmedAtMs: Date.now(),
          edited: true,
          editedAt: serverTimestamp(),
          editedAtMs: Date.now(),
          editedBy: currentUser.username,
          editedByName: currentUser.name
        };
        await setDoc(doc(db, 'transactions', id), patch, { merge: true });
        await logAudit('transaction_edit', {
          id,
          user: targetUsername,
          beforeUser: trx.user,
          afterUser: targetUsername,
          beforeAmount: Number(trx.amount || draft.oldAmount || 0),
          afterAmount: amount,
          beforeNote: trx.note || draft.oldNote || 'Transaksi',
          afterNote: note,
          paymentMethod: paymentInfo.method,
          paymentLabel: paymentInfo.label
        });
        showToast(`✓ Edit transaksi disimpan · ${paymentInfo.label}`);
        pendingTransactionPaymentDraft = null;
        closeTransactionPaymentModal(true);
        closeTransactionModal();
        await refreshCurrentPage();
        setLoading(false);
        return;
      }
      const latest = await fetchLatestBonusBeforeTransaction(targetUsername);
      const freshUser = latest.user || targetUser || currentUser;
      const userBonus = latest.snapshot || getUserBonusSnapshot(freshUser);
      const trialFlags = getTrialFlags(freshUser);
      if (!canTransactNow()) {
        showToast(isTransactionsClosedToday() ? 'Transaksi sudah closing. Terbuka otomatis besok.' : 'Absen dulu sebelum transaksi!', true);
        closeTransactionPaymentModal(true);
        closeTransactionModal();
        setTimeout(() => router.navigate('home'), 500);
        setLoading(false);
        return;
      }
      const userRole = normalizeRole(freshUser.role || targetUser.role || currentUser.role || 'staff');
      const bonusGroup = userRole === 'harian' ? 'harian' : 'staff';
      const bonusRate = userBonus.transactionBonusRate;
      const savedRef = await addDoc(collection(db, 'transactions'), {
        user: sanitizeUsername(freshUser.username || targetUsername),
        name: freshUser.name || targetUser.name || targetUsername,
        amount,
        note,
        paymentMethod: paymentInfo.method,
        paymentLabel: paymentInfo.label,
        paymentStatus: 'success',
        paymentCashOutType: paymentInfo.method === 'qris_transfer' ? 'qris' : '',
        isNonCashPayment: paymentInfo.method === 'qris_transfer',
        paymentConfirmed: true,
        paymentConfirmedAtMs: Date.now(),
        dateKey: toDateKey(nowDate()),
        monthKey: toMonthKey(nowDate()),
        userRole,
        bonusGroup,
        bonusRate,
        transactionBonusRate: bonusRate,
        bonusPercent: userBonus.transactionBonusPercent,
        transactionBonusPercent: userBonus.transactionBonusPercent,
        closingBonusPerMinuteSnapshot: userBonus.closingBonusPerMinute,
        bonusLogicVersion: 3,
        ...trialFlags,
        notifyAdmin: false,
        notificationType: 'admin_manual_transaction',
        notificationStatus: 'skip',
        source: 'admin_manual',
        createdBy: sanitizeUsername(currentUser.username),
        createdByName: currentUser.name || currentUser.username,
        createdAt: serverTimestamp(),
        createdAtMs: Date.now()
      });
      const savedTx = {
        id: savedRef?.id || '',
        user: sanitizeUsername(freshUser.username || targetUsername),
        name: freshUser.name || targetUser.name || targetUsername,
        amount,
        note,
        paymentMethod: paymentInfo.method,
        paymentLabel: paymentInfo.label,
        dateKey: toDateKey(nowDate()),
        monthKey: toMonthKey(nowDate()),
        userRole,
        role: userRole,
        bonusGroup,
        bonusRate,
        transactionBonusRate: bonusRate,
        bonusPercent: userBonus.transactionBonusPercent,
        transactionBonusPercent: userBonus.transactionBonusPercent,
        closingBonusPerMinuteSnapshot: userBonus.closingBonusPerMinute,
        ...trialFlags,
        paymentStatus: 'success',
        paymentCashOutType: paymentInfo.method === 'qris_transfer' ? 'qris' : '',
        isNonCashPayment: paymentInfo.method === 'qris_transfer',
        paymentConfirmed: true,
        paymentConfirmedAtMs: Date.now(),
        source: 'admin_manual',
        createdBy: sanitizeUsername(currentUser.username),
        createdByName: currentUser.name || currentUser.username,
        createdAtMs: Date.now()
      };
      const shouldPrint = Boolean(pendingTransactionPaymentDraft?.printAfterSave);
      pendingTransactionPaymentDraft = null;
      playTransactionSuccessSound();
      showToast(`✓ Transaksi disimpan · ${paymentInfo.label}${shouldPrint ? ' · cetak struk' : ''}`);
      closeTransactionPaymentModal(true);
      closeTransactionModal();
      await refreshCurrentPage();
      if (shouldPrint) setTimeout(() => directPrintReceiptText(buildTransactionReceiptText(savedTx), 'Struk Transaksi Baru'), 180);
    } catch (e) {
      console.error(e);
      showToast(e.message || 'Gagal cek bonus terbaru. Transaksi belum disimpan.', true);
    }
    setLoading(false);
  }

  async function deleteTransaction(id) {
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const trx = cachedTransactions.find(t => t.id === id);
    if (!trx) return showToast('Transaksi tidak ditemukan!', true);
    if (trx.user !== currentUser.username && !isAdmin()) return showToast('Tidak bisa hapus transaksi orang lain!', true);
    const pin = await askPin(`Hapus transaksi Rp ${formatRupiah(trx.amount)}?\nMasukkan PIN:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'transactions', id), {
        deleted: true,
        deletedAt: serverTimestamp(),
        deletedAtMs: Date.now(),
        deletedBy: currentUser.username,
        deletedByName: currentUser.name
      }, { merge: true });
      await logAudit('transaction_soft_delete', { id, user: trx.user, amount: Number(trx.amount || 0), note: trx.note || 'Transaksi' });
      cachedTransactions = cachedTransactions.map(t => String(t.id) === String(id) ? {
        ...t,
        deleted: true,
        deletedAtMs: Date.now(),
        deletedBy: currentUser.username,
        deletedByName: currentUser.name
      } : t);
      await serverApplyDailyTarget();
      showToast(`✓ Transaksi dihapus aman`);
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus', true);
    }
    setLoading(false);
  }


  async function restoreDeletedTransaction(id) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const trx = cachedTransactions.find(t => t.id === id);
    if (!trx) return showToast('Transaksi tidak ditemukan!', true);
    if (!isRecordDeleted(trx)) return showToast('Transaksi ini belum dihapus.', true);
    const pin = await askPin(`Pulihkan transaksi Rp ${formatRupiah(trx.amount)}?\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'transactions', id), {
        deleted: false,
        deletedAt: null,
        deletedAtMs: null,
        deletedBy: null,
        deletedByName: null
      }, { merge: true });
      await logAudit('transaction_restore', { id, user: trx.user, amount: Number(trx.amount || 0) });
      showToast('✓ Transaksi dipulihkan');
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal memulihkan transaksi', true);
    }
    setLoading(false);
  }

  async function hardDeleteTransaction(id) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const trx = cachedTransactions.find(t => t.id === id);
    if (!trx) return showToast('Transaksi tidak ditemukan!', true);
    if (!isRecordDeleted(trx)) return showToast('Hapus permanen hanya dari data terhapus.', true);
    const pin = await askPin(`HAPUS PERMANEN transaksi Rp ${formatRupiah(trx.amount)}?\nKetik PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm('Data akan hilang permanen dan tidak bisa dikembalikan. Lanjutkan?')) return;
    setLoading(true);
    try {
      await deleteDoc(doc(db, 'transactions', id));
      await logAudit('transaction_hard_delete', { id, user: trx.user, amount: Number(trx.amount || 0), note: trx.note || 'Transaksi' });
      showToast('✓ Transaksi dihapus permanen');
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus permanen', true);
    }
    setLoading(false);
  }

  async function bulkRestoreDeletedTransactions() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const items = getFilteredDeletedTransactions();
    if (!items.length) return showToast('Tidak ada data terhapus sesuai filter', true);
    const pin = await askPin(`Pulihkan ${items.length} transaksi terhapus sesuai filter?\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm(`Pulihkan ${items.length} transaksi?`)) return;
    setLoading(true);
    try {
      for (const trx of items) {
        await setDoc(doc(db, 'transactions', trx.id), {
          deleted: false,
          deletedAt: null,
          deletedAtMs: null,
          deletedBy: null,
          deletedByName: null
        }, { merge: true });
      }
      await logAudit('transaction_restore_bulk', { count: items.length, filterUser: recycleUserFilter, q: recycleSearch || '' });
      showToast(`✓ ${items.length} transaksi dipulihkan`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal pulihkan banyak data', true);
    }
    setLoading(false);
  }

  async function bulkHardDeleteDeletedTransactions() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const items = getFilteredDeletedTransactions();
    if (!items.length) return showToast('Tidak ada data terhapus sesuai filter', true);
    const pin = await askPin(`HAPUS PERMANEN ${items.length} transaksi sesuai filter?\nKetik PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm(`Data sebanyak ${items.length} transaksi akan hilang permanen. Lanjutkan?`)) return;
    setLoading(true);
    try {
      for (const trx of items) {
        await deleteDoc(doc(db, 'transactions', trx.id));
      }
      await logAudit('transaction_hard_delete_bulk', { count: items.length, filterUser: recycleUserFilter, q: recycleSearch || '' });
      showToast(`✓ ${items.length} transaksi dihapus permanen`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus permanen banyak data', true);
    }
    setLoading(false);
  }

  async function updateHomeStatus() {
    const el = $('home-status');
    if (!el) return;
    el.innerHTML = '';
  }


  function getClosingHistoryRows(limitRows = 14) {
    return [...(cachedClosings || [])]
      .filter(isClosingDataRecord)
      .sort((a, b) => String(b.dateKey || b.id || '').localeCompare(String(a.dateKey || a.id || '')))
      .slice(0, limitRows);
  }
  function formatClosingHistoryTime(closing) {
    const jam = getClosingDisplayTime(closing);
    if (jam) return jam;
    const ms = Number(closing?.closedAtMs || closing?.editedAtMs || 0);
    if (ms) return new Date(ms).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', timeZone:'Asia/Jakarta' }).replace('.', ':');
    return '--:--';
  }
  function formatClosingCancelTime(closing) {
    const ms = Number(closing?.canceledAtMs || 0);
    if (!ms) return '';
    return new Date(ms).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit', timeZone:'Asia/Jakarta' }).replace('.', ':');
  }
  function renderClosingHistoryCard() {
    // Riwayat closing sengaja tidak ditampilkan agar halaman tetap ringan.
    // Data closing tetap tersimpan di Supabase untuk laporan, bonus, anti double closing, dan audit.
    return '';
  }

  function getRismaManualClosingAllowedUsers() {
    const arr = Array.isArray(cachedRismaManualClosingConfig?.allowedUsers) ? cachedRismaManualClosingConfig.allowedUsers : [];
    return [...new Set(arr.map(u => sanitizeUsername(u)).filter(Boolean))];
  }
  function getRismaManualClosingAllowedNames() {
    const raw = cachedRismaManualClosingConfig?.allowedNames || {};
    return raw && typeof raw === 'object' ? raw : {};
  }
  function renderRismaManualClosingPanel() {
    const users = getStaffClosingUsers();
    const eligibleSet = new Set(users.map(u => sanitizeUsername(u.username)));
    const allowed = new Set(getRismaManualClosingAllowedUsers().filter(u => eligibleSet.has(sanitizeUsername(u))));
    const names = getRismaManualClosingAllowedNames();
    const selectedCount = allowed.size;
    const closedCount = [...allowed].filter(u => hasUserClosingOnDate(u, toDateKey(nowDate()))).length;
    const rows = users.length ? users.map(u => {
      const uname = sanitizeUsername(u.username);
      const checked = allowed.has(uname) ? 'checked' : '';
      const closed = hasUserClosingOnDate(uname, toDateKey(nowDate()));
      const label = escapeHtml(u.name || names[uname] || uname);
      return `<label style="display:flex;align-items:center;justify-content:space-between;gap:9px;padding:9px 10px;border:1px solid var(--border);border-radius:12px;background:var(--surface);cursor:pointer">
        <span style="min-width:0;display:flex;flex-direction:column;gap:2px">
          <b style="font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${label}</b>
          <small style="font-size:9.5px;color:var(--text-soft)">@${escapeHtml(uname)}${closed ? ' · sudah closing hari ini' : ''}</small>
        </span>
        <input class="risma-manual-target" type="checkbox" value="${escapeHtml(uname)}" ${checked} style="width:18px;height:18px;accent-color:var(--accent);flex-shrink:0">
      </label>`;
    }).join('') : `<div style="font-size:12px;color:var(--text-soft);padding:12px;border:1px dashed var(--border);border-radius:12px;text-align:center">Belum ada user yang sudah absen, karyawan harian aktif, atau transaksi Risma hari ini.</div>`;
    return `<div style="margin-top:10px;background:linear-gradient(145deg,var(--bg3),var(--bg2));border:1px solid rgba(190,24,93,.22);border-radius:18px;padding:14px;box-shadow:0 10px 28px rgba(0,0,0,.12);position:relative;overflow:hidden">
      <div style="position:absolute;top:-44px;right:-50px;width:132px;height:132px;background:radial-gradient(circle,rgba(190,24,93,.16) 0%,transparent 70%);pointer-events:none"></div>
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px;position:relative;z-index:1;margin-bottom:10px">
        <div style="min-width:0;flex:1">
          <p class="label-xs" style="margin:0 0 6px">Closing Manual</p>
          <div style="font-size:16px;font-weight:900;letter-spacing:-.02em;line-height:1.2">Arahan Closing untuk Risma</div>
          <div style="font-size:11px;color:var(--text-soft);margin-top:5px;line-height:1.35">Admin pilih user yang boleh diclosing oleh Risma. Yang muncul hanya staff yang sudah absen hari ini, karyawan harian, dan Risma kalau sudah transaksi.</div>
        </div>
        <span class="status-pill status-ok" style="font-size:10px;padding:6px 10px;white-space:nowrap"><i class="fas fa-user-check"></i> ${selectedCount} target</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;position:relative;z-index:1;margin-bottom:10px">
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:9px 10px"><div style="font-size:9px;color:var(--text-ghost);font-weight:900;text-transform:uppercase;margin-bottom:3px">Dipilih Admin</div><b style="font-family:var(--num-font);font-size:17px;color:var(--accent)">${selectedCount} user</b></div>
        <div style="background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:9px 10px"><div style="font-size:9px;color:var(--text-ghost);font-weight:900;text-transform:uppercase;margin-bottom:3px">Sudah Closing</div><b style="font-family:var(--num-font);font-size:17px;color:${closedCount?'var(--green)':'var(--text-soft)'}">${closedCount} user</b></div>
      </div>
      <div style="display:grid;grid-template-columns:1fr;gap:7px;max-height:220px;overflow:auto;position:relative;z-index:1;margin-bottom:10px">${rows}</div>
      <button onclick="saveRismaManualClosingConfig()" class="btn btn-primary" style="width:100%;min-height:42px;padding:11px 12px;font-size:13px;border-radius:14px;font-weight:900;position:relative;z-index:1"><i class="fas fa-paper-plane"></i> Simpan Arahan ke Risma</button>
      <div style="font-size:10px;color:var(--text-soft);line-height:1.35;margin-top:8px;position:relative;z-index:1">Catatan: ini tidak langsung closing. Staff yang tidak absen tidak masuk target; Risma ikut hanya kalau sudah ada transaksi hari ini.</div>
    </div>`;
  }
  async function saveRismaManualClosingConfig() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const selected = [...document.querySelectorAll('.risma-manual-target:checked')]
      .map(el => sanitizeUsername(el.value))
      .filter(Boolean);
    const allowedUsers = [...new Set(selected)];
    const allowedNames = {};
    allowedUsers.forEach(u => {
      const found = getUserByUsername(u);
      allowedNames[u] = found?.name || found?.username || u;
    });
    setLoading(true);
    try {
      await setDoc(doc(db, RISMA_MANUAL_CLOSING_COLLECTION, RISMA_MANUAL_CLOSING_DOC_ID), {
        id: RISMA_MANUAL_CLOSING_DOC_ID,
        enabled: true,
        allowedUsers,
        allowedNames,
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name,
        source: 'admin_index',
        type: 'closing_manual_config',
        dateKey: '__risma_manual_closing',
        title: 'Closing Manual Risma'
      }, { merge: true });
      cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers, allowedNames, updatedAtMs: Date.now(), updatedBy: currentUser.username, updatedByName: currentUser.name };
      await logAudit('closing_manual_config', { targetApp: 'risma', allowedUsers, count: allowedUsers.length });
      showToast(allowedUsers.length ? `✓ Arahan closing Risma: ${allowedUsers.length} user` : '✓ Arahan closing Risma dikosongkan');
      renderAdminClosingPanelMaybe(true);
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan Closing Manual', true);
    }
    setLoading(false);
  }

  function renderAdminClosingPanel() {
    if (!isAdmin()) return;
    const box = $('admin-closing-panel');
    if (!box) return;
    const targetUser = getAdminClosingTargetUser();
    const targetUsername = targetUser ? sanitizeUsername(targetUser.username) : null;
    const rawGlobalClosing = getTodayGlobalClosing();
    const globalClosing = targetUsername ? getTodayGlobalClosingForUser(targetUsername) : rawGlobalClosing;
    const userClosing = targetUsername ? getTodayUserClosing(targetUsername) : null;
    const closing = targetUsername ? (userClosing || globalClosing) : rawGlobalClosing;
    const lockedByGlobal = !!(targetUsername && !userClosing && globalClosing);
    const activeDeadlineSnapshot = getClosingDeadlineSnapshot();
    const lateMinutes = getClosingDelayMinutes(nowDate(), activeDeadlineSnapshot);
    const preview = buildClosingBonusByUser(lateMinutes, targetUsername, toDateKey(nowDate()));
    const displayDelay = closing ? (closing.delayMinutes || 0) : lateMinutes;
    const displayBonus = closing ? (targetUsername ? getClosingBonusValue(closing, targetUsername) : getClosingBonusValue(closing)) : (targetUsername ? (preview.bonusByUser[targetUsername] || 0) : preview.totalBonus);
    const bonusBoxLabel = targetUsername ? 'Bonus User' : 'Total Bonus';
    const closingJam = closing ? getClosingDisplayTime(closing) : '';
    const statusText = closing ? 'Sudah Closing' : 'Masih Terbuka';
    const mainTitle = closing ? `Closing ${closingJam || '--:--'} WIB` : `Belum Closing ${targetUsername ? targetUser.name : 'Global'}`;
    const mainDesc = closing
      ? (lockedByGlobal ? 'User ini sudah terkunci oleh closing global hari ini.' : (targetUsername ? 'User ini terkunci transaksi. User lain tetap bisa jalan.' : 'Semua staff terkunci transaksi sampai ganti tanggal.'))
      : `Pilih user yang sudah absen hari ini, karyawan harian, atau Risma yang sudah transaksi. Yang tidak hadir tidak perlu diclosing.`;
    box.innerHTML = `
      ${renderClosingDeadlineSettingsCard()}
      <div style="background:linear-gradient(145deg,var(--bg3),var(--bg2));border:1px solid ${closing?'rgba(255,196,107,.24)':'rgba(91,143,255,.18)'};border-radius:18px;padding:14px;box-shadow:0 10px 28px rgba(0,0,0,.14);position:relative;overflow:hidden">
        <div style="position:absolute;top:-44px;right:-50px;width:132px;height:132px;background:radial-gradient(circle,${closing?'rgba(255,196,107,.16)':'rgba(91,143,255,.16)'} 0%,transparent 70%);pointer-events:none"></div>

        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;position:relative;z-index:1;margin-bottom:12px">
          <div style="min-width:0;flex:1">
            <p class="label-xs" style="margin:0 0 6px">Closing Per User</p>
            <div style="font-size:16px;font-weight:900;letter-spacing:-.02em;line-height:1.2">${mainTitle}</div>
            <div style="font-size:11px;color:var(--text-soft);margin-top:5px;line-height:1.35">${mainDesc}</div>
          </div>
          <span class="status-pill ${closing?'status-warn':'status-ok'}" style="font-size:10px;padding:6px 10px;white-space:nowrap">
            <i class="fas ${closing?'fa-lock':'fa-lock-open'}"></i> ${statusText}
          </span>
        </div>

        <select id="closing-target-user" class="g-input" onchange="renderAdminClosingPanelMaybe(true)" style="margin-bottom:10px;position:relative;z-index:1">
          <option value="global">Semua / Global</option>
          ${getStaffClosingUsers().map(u => `<option value="${escapeHtml(u.username)}" ${targetUsername === sanitizeUsername(u.username) ? 'selected' : ''}>${escapeHtml(u.name || u.username)} (@${escapeHtml(u.username)}) · ${isDailyEmployee(u) ? 'HARIAN' : 'SUDAH ABSEN'} ${isUserClosedToday(u.username) ? '· SUDAH CLOSING' : ''}</option>`).join('')}
        </select>
        <div style="font-size:10.5px;color:var(--text-soft);line-height:1.35;margin:-3px 0 10px;position:relative;z-index:1">${closing ? `Deadline snapshot data ini: ${formatClosingDeadline(closing)}` : `Deadline closing baru: ${activeDeadlineSnapshot.deadline}`}</div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;position:relative;z-index:1;margin-bottom:11px">
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:10px 11px">
            <div style="font-size:9px;color:var(--text-ghost);font-weight:900;text-transform:uppercase;margin-bottom:4px">Telat</div>
            <div style="font-family:var(--num-font);font-size:18px;font-weight:900;color:${displayDelay?'var(--amber)':'var(--green)'}">${displayDelay} menit</div>
          </div>
          <div style="background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:10px 11px">
            <div style="font-size:9px;color:var(--text-ghost);font-weight:900;text-transform:uppercase;margin-bottom:4px">${bonusBoxLabel}</div>
            <div style="font-family:var(--num-font);font-size:18px;font-weight:900;color:var(--accent)">Rp ${formatRupiah(displayBonus)}</div>
          </div>
        </div>

        <div style="display:flex;flex-direction:column;gap:8px;position:relative;z-index:1">
          <button onclick="handleClosingDay()" ${closing?'disabled':''} class="btn ${closing?'btn-glass':'btn-primary'}" style="width:100%;min-height:44px;padding:11px 12px;font-size:13px;border-radius:14px;font-weight:900">
            <i class="fas fa-lock"></i> ${closing?'Sudah Diclosing':'Closing Target Ini'}
          </button>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <button onclick="handleEditClosingTime()" ${closing && !lockedByGlobal?'':'disabled'} class="btn btn-glass" style="min-height:40px;padding:10px 8px;font-size:12px;border-radius:13px;justify-content:center;white-space:nowrap">
              <i class="fas fa-pen-to-square"></i> Edit Jam
            </button>
            <button onclick="handleCancelClosingToday()" ${closing?'':'disabled'} class="btn btn-danger closing-cancel-btn" style="min-height:40px;padding:10px 8px;font-size:12px;border-radius:13px;justify-content:center;white-space:nowrap">
              <i class="fas fa-unlock"></i> ${lockedByGlobal?'Buka User':'Batal Closing'}
            </button>
          </div>
        </div>
      </div>${renderRismaManualClosingPanel()}`;
  }



  // === CASH FISIK HARI INI (HOME ADMIN) ===
  // Disamakan dengan card Cash Fisik di catatan.html:
  // Cash Fisik = Omset Supabase/Kasir hari ini - Operasional Toko - QRIS - Tabungan.
  // Manual income di Supabase tidak ikut cash fisik.
  function normalizeFinanceAmount(value) {
    const n = Number(value || 0);
    return Number.isFinite(n) ? Math.abs(n) : 0;
  }
  function financeRoundRp(value) {
    const n = Number(value || 0);
    return Number.isFinite(n) ? Math.round(n) : 0;
  }
  function isFinanceCashDrawerAdjustmentTx(rec = {}) {
    const desc = String(rec && rec.description || '');
    const category = String(rec && rec.category_name || '').toLowerCase();
    return desc.startsWith(CASH_DRAWER_ADJ_PREFIX)
      || category === CASH_DRAWER_MINUS_CATEGORY_NAME.toLowerCase()
      || category === CASH_DRAWER_PLUS_CATEGORY_NAME.toLowerCase();
  }
  function isFinanceOpsExpense(rec = {}) {
    return rec && !isFinanceCashDrawerAdjustmentTx(rec) && String(rec.type || '').toLowerCase() === 'expense' && String(rec.description || '').startsWith(OPS_PREFIX);
  }
  function isFinanceCashOut(rec = {}) {
    return rec && !isFinanceCashDrawerAdjustmentTx(rec) && String(rec.type || '').toLowerCase() === 'expense' && String(rec.description || '').startsWith(CASHOUT_PREFIX);
  }
  function getFinanceCashOutType(rec = {}) {
    const m = String(rec.description || '').match(/^?\[CASHOUT:(\w+)\]/i) || String(rec.description || '').match(/^\[CASHOUT:(\w+)\]/i);
    return m ? String(m[1] || '').toLowerCase() : 'lainnya';
  }
  function normalizeFinanceCashDrawerAudit(rec = {}) {
    const diff = financeRoundRp(rec.differenceAmount ?? rec.difference_amount ?? 0);
    const rawStatus = String(rec.status || (diff < 0 ? 'minus' : diff > 0 ? 'lebih' : 'pas')).toLowerCase();
    const status = ['minus', 'pas', 'lebih'].includes(rawStatus) ? rawStatus : (diff < 0 ? 'minus' : diff > 0 ? 'lebih' : 'pas');
    const date = String(rec.dateKey || rec.date_key || rec.date || toDateKey(nowDate())).slice(0, 10);
    return {
      id: Number(rec.id || 0),
      owner_id: rec.owner_id || CASH_FISIK_OWNER_ID,
      dateKey: date,
      baseAmount: financeRoundRp(rec.baseAmount ?? rec.base_amount ?? 0),
      expectedAmount: financeRoundRp(rec.expectedAmount ?? rec.expected_amount ?? 0),
      actualAmount: financeRoundRp(rec.actualAmount ?? rec.actual_amount ?? 0),
      differenceAmount: diff,
      previousAdjustmentAmount: financeRoundRp(rec.previousAdjustmentAmount ?? rec.previous_adjustment_amount ?? 0),
      adjustmentAmount: financeRoundRp(rec.adjustmentAmount ?? rec.adjustment_amount ?? 0),
      status,
      createdAt: rec.createdAt || rec.created_at || '',
      updatedAt: rec.updatedAt || rec.updated_at || ''
    };
  }
  function financeCashDrawerAdjustmentTxAuditId(rec = {}) {
    const m = String(rec && rec.description || '').match(/^\[SELISIH_LACI:([^\]]+)\]/);
    return m ? String(m[1] || '') : '';
  }
  async function fetchFinanceCashRows(dateKey = toDateKey(nowDate()), force = false) {
    const now = Date.now();
    if (!force && cachedFinanceCashDateKey === dateKey && (now - cachedFinanceCashFetchedAt) < 15000) {
      return cachedFinanceCashRows;
    }
    try {
      const { data, error } = await cashFisikSupabase
        .from('transactions')
        .select('id,date,description,amount,type,category_id,category_name')
        .eq('owner_id', CASH_FISIK_OWNER_ID)
        .eq('date', dateKey)
        .order('id', { ascending: false });
      if (error) throw error;
      cachedFinanceCashRows = (data || []).map(r => ({
        id: Number(r.id || 0),
        date: r.date,
        description: String(r.description || ''),
        amount: Number(r.amount || 0),
        type: String(r.type || ''),
        category_id: r.category_id || '',
        category_name: String(r.category_name || '')
      }));
      cachedFinanceCashDateKey = dateKey;
      cachedFinanceCashFetchedAt = now;
      return cachedFinanceCashRows;
    } catch (e) {
      console.warn('Cash Fisik Supabase gagal:', e?.message || e);
      if (cachedFinanceCashDateKey === dateKey) return cachedFinanceCashRows;
      return [];
    }
  }
  async function fetchFinanceCashAuditRows(dateKey = toDateKey(nowDate()), force = false) {
    const now = Date.now();
    if (!force && cachedFinanceCashAuditDateKey === dateKey && (now - cachedFinanceCashAuditFetchedAt) < 15000) {
      return cachedFinanceCashAuditRows;
    }
    try {
      const { data, error } = await cashFisikSupabase
        .from(CASH_DRAWER_TABLE)
        .select('*')
        .eq('owner_id', CASH_FISIK_OWNER_ID)
        .eq('date_key', dateKey)
        .order('created_at', { ascending: false })
        .limit(20);
      if (error) throw error;
      cachedFinanceCashAuditRows = (data || []).map(normalizeFinanceCashDrawerAudit);
      cachedFinanceCashAuditDateKey = dateKey;
      cachedFinanceCashAuditFetchedAt = now;
      return cachedFinanceCashAuditRows;
    } catch (e) {
      console.warn('Audit Laci Cash Supabase gagal:', e?.message || e);
      if (cachedFinanceCashAuditDateKey === dateKey) return cachedFinanceCashAuditRows;
      return [];
    }
  }
  function latestFinanceCashDrawerAudit(auditRows = [], dateKey = toDateKey(nowDate())) {
    const d = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    return (auditRows || [])
      .filter(r => String(r.dateKey || '').slice(0, 10) === d)
      .sort((a, b) => (Date.parse(b.createdAt || '') || Number(b.id || 0)) - (Date.parse(a.createdAt || '') || Number(a.id || 0)))[0] || null;
  }
  function financeCashDrawerAdjustmentForDate(financeRows = [], auditRows = [], dateKey = toDateKey(nowDate())) {
    const d = String(dateKey || toDateKey(nowDate())).slice(0, 10);
    const latest = latestFinanceCashDrawerAudit(auditRows, d);
    let adjustmentRows = (financeRows || []).filter(r => String(r.date || '').slice(0, 10) === d && isFinanceCashDrawerAdjustmentTx(r));
    if (latest) {
      const byAudit = adjustmentRows.filter(r => String(financeCashDrawerAdjustmentTxAuditId(r)) === String(latest.id));
      if (byAudit.length) adjustmentRows = byAudit;
      else if (!adjustmentRows.length && latest.status !== 'pas' && financeRoundRp(latest.adjustmentAmount) !== 0) {
        return financeRoundRp(latest.adjustmentAmount);
      }
    }
    return financeRoundRp(adjustmentRows.reduce((sum, row) => {
      const type = String(row.type || '').toLowerCase();
      const amount = normalizeFinanceAmount(row.amount);
      return sum + (type === 'income' ? amount : -amount);
    }, 0));
  }

  function getSupabaseOmzetForCashFisik(dateKey = toDateKey(nowDate())) {
    return getVisibleTransactions()
      .filter(t => !isRecordDeleted(t) && extractDateKey(t) === dateKey)
      .reduce((sum, t) => sum + Number(t.amount || t.nominal || t.total || 0), 0);
  }
  async function getHomeCashFisikBreakdown(dateKey = toDateKey(nowDate()), force = false) {
    const financeRows = await fetchFinanceCashRows(dateKey, force);
    const auditRows = await fetchFinanceCashAuditRows(dateKey, force);
    const fbTotal = getSupabaseOmzetForCashFisik(dateKey);
    const opsTotal = financeRows.filter(isFinanceOpsExpense).reduce((s, t) => s + normalizeFinanceAmount(t.amount), 0);
    const cashOutRows = financeRows.filter(isFinanceCashOut);
    const qris = cashOutRows.filter(t => getFinanceCashOutType(t) === 'qris').reduce((s, t) => s + normalizeFinanceAmount(t.amount), 0);
    const tabungan = cashOutRows.filter(t => getFinanceCashOutType(t) === 'tabungan').reduce((s, t) => s + normalizeFinanceAmount(t.amount), 0);
    const lainnya = cashOutRows.filter(t => !['qris','tabungan'].includes(getFinanceCashOutType(t))).reduce((s, t) => s + normalizeFinanceAmount(t.amount), 0);
    const laci = financeCashDrawerAdjustmentForDate(financeRows, auditRows, dateKey);
    const manualIncome = financeRows
      .filter(t => !isFinanceCashDrawerAdjustmentTx(t) && String(t.type || '').toLowerCase() === 'income' && !String(t.description || '').startsWith('[FIREBASE:'))
      .reduce((s, t) => s + normalizeFinanceAmount(t.amount), 0);
    const deduction = financeRoundRp(opsTotal + qris + tabungan + lainnya - laci);
    const cashFisik = Math.max(0, financeRoundRp(fbTotal - deduction));
    return { rows: financeRows, audits: auditRows, omzet: fbTotal, ops: opsTotal, qris, tabungan, lainnya, laci, manualIncome, deduction, cashFisik };
  }
  async function updateHomeCashFisikCard(dateKey = toDateKey(nowDate()), force = false) {
    const data = await getHomeCashFisikBreakdown(dateKey, force);
    const totalEl = $('home-cash-fisik-total');
    const infoEl = $('home-cash-fisik-info');
    const card = $('home-cash-fisik-card');
    const safeCash = Math.max(0, Number(data.cashFisik || 0));
    if (totalEl) {
      totalEl.innerText = `Rp ${formatRupiah(safeCash)}`;
      totalEl.style.color = data.cashFisik < 0 ? 'var(--red)' : '#2563eb';
    }
    if (card) {
      card.style.background = data.cashFisik < 0 ? 'var(--red-dim)' : '#eff6ff';
      card.style.borderColor = data.cashFisik < 0 ? 'rgba(255,107,107,.22)' : '#bfdbfe';
    }
    if (infoEl) {
      // Tampilan home dibuat nominal-only sesuai request.
      // Breakdown Supabase/Ops/QRIS/Tabungan tetap dihitung di belakang, tapi tidak ditampilkan.
      infoEl.innerText = '';
      infoEl.style.display = 'none';
    }
    return data;
  }

  async function updateHomeStats() {
    const today = toDateKey(nowDate());
    const month = toMonthKey(nowDate());
    const sourceTransactions = getVisibleTransactions();
    const pendapatanHariIni = sourceTransactions.filter(t => extractDateKey(t) === today).reduce((a,b)=>a+Number(b.amount||0),0);
    const omzetBulanan = sourceTransactions.filter(t => t.monthKey === month).reduce((a,b)=>a+Number(b.amount||0),0);
    const bonusBreakdown = getBonusBreakdown(sourceTransactions, null, month);
    const todayBonusBreakdown = getBonusBreakdown(sourceTransactions, null, { type: 'daily', dateKey: today });
    if ($('today-income')) $('today-income').innerText = `Rp ${formatRupiah(pendapatanHariIni)}`;
    if ($('home-cash-fisik-total')) {
      const shouldForceCash = forceCashFisikNextRender;
      forceCashFisikNextRender = false;
      await updateHomeCashFisikCard(today, shouldForceCash);
    }
    if ($('total-bonus')) $('total-bonus').innerText = `Rp ${formatRupiah(bonusBreakdown.totalBonus)}`;
    if ($('bonus-text')) {
      $('bonus-text').style.display = '';
      $('bonus-text').innerText = 'Bonus ini sudah termasuk total bonus keseluruhan';
    }
    if ($('month-omzet')) $('month-omzet').innerText = `Rp ${formatRupiah(omzetBulanan)}`;
    if ($('today-bonus-total')) $('today-bonus-total').innerText = `Rp ${formatRupiah(todayBonusBreakdown.totalBonus)}`;
    if ($('today-bonus-omzet')) $('today-bonus-omzet').innerText = `Rp ${formatRupiah(pendapatanHariIni)}`;
    if ($('today-bonus-text')) {
      const staffToday = Number(todayBonusBreakdown.staffTransactionBonus || todayBonusBreakdown.trxBonus || 0) + Number(todayBonusBreakdown.closingBonus || 0);
      const harianToday = Number(todayBonusBreakdown.dailySalary || 0);
      const manualToday = Number(todayBonusBreakdown.manualBonus || 0);
      $('today-bonus-text').innerText = `Staff Rp ${formatRupiah(staffToday)} - Harian Rp ${formatRupiah(harianToday)}${manualToday ? ' - Manual Rp ' + formatRupiah(manualToday) : ''}`;
    }
    if ($('scope-chip')) $('scope-chip').textContent = 'Semua User';
    renderAdminDashboardPanels();
  }

  function getFilteredTransactions() {
    const visible = getVisibleTransactions();
    const source = isAdmin() && selectedUserFilter !== 'all' ? visible.filter(t => t.user === selectedUserFilter) : visible;
    const today = toDateKey(nowDate());
    const month = toMonthKey(nowDate());
    const year = getBusinessYear(nowDate());
    if (historyFilter === 'daily') return source.filter(t => getTransactionDateKey(t) === today);
    if (historyFilter === 'monthly') return source.filter(t => getTransactionMonthKey(t) === month);
    if (historyFilter === 'yearly') return source.filter(t => String(getTransactionDateKey(t) || '').startsWith(year));
    if (historyFilter === 'range' && rangeStartDate && rangeEndDate) return source.filter(t => { const dateKey = getTransactionDateKey(t); return dateKey >= rangeStartDate && dateKey <= rangeEndDate; });
    return source;
  }


  function rockyReceiptLine(char = '-', count = 32) { return String(char || '-').repeat(count); }
  function rockyReceiptCenter(text = '', width = 32) {
    const s = String(text || '').trim();
    if (s.length >= width) return s;
    const left = Math.floor((width - s.length) / 2);
    return ' '.repeat(left) + s;
  }
  function rockyReceiptPair(label = '', value = '', width = 32) {
    const l = String(label || '').trim();
    const r = String(value || '').trim();
    const space = Math.max(1, width - l.length - r.length);
    return l + ' '.repeat(space) + r;
  }
  function buildRockyReceiptText(t = {}) {
    return buildTransactionReceiptText(t);
  }


  async function renderHistory() {
    const list = $('history-list'); if (!list) return;
    const filtered = sortByCreatedDesc(getFilteredTransactions());
    const total = filtered.reduce((a,b)=>a+Number(b.amount||0),0);
    const visibleItems = filtered.slice(0, historyDisplayLimit);
    const hasMore = filtered.length > visibleItems.length;
    const filterBox = isAdmin() ? `
      <div style="margin-bottom:10px" class="page-in s1">
        <select id="admin-history-user" class="g-input" onchange="setSelectedUserFilter(this.value)">${getUserOptionsHtml(true)}</select>
      </div>` : '';
    list.innerHTML = `
      <div class="stat-hero page-in" style="margin-bottom:12px">
        <p class="stat-label">${isAdmin() ? 'Total Transaksi Global' : 'Total Transaksi'}</p>
        <p class="stat-value">Rp ${formatRupiah(total)}</p>
        <p class="stat-sub">Menampilkan ${visibleItems.length} dari ${filtered.length} transaksi · ${isAdmin() ? getSelectedUserLabel() : 'akun saya'}</p>
      </div>
      ${filterBox}
      <div style="display:flex;gap:7px;margin-bottom:10px" class="page-in s1">
        <button onclick="openTransactionModal()" class="btn btn-primary" style="width:100%;padding:11px 12px;font-size:12.5px"><i class="fas fa-plus"></i> Tambah Transaksi</button>
      </div>
      <div style="display:flex;gap:7px;margin-bottom:9px" class="page-in s1">
        <input type="date" id="history-range-start" class="g-input" style="flex:1;font-size:11px;padding:9px 11px;color-scheme:${getTheme()}">
        <span style="font-size:11px;color:var(--text-ghost);align-self:center;flex-shrink:0">–</span>
        <input type="date" id="history-range-end" class="g-input" style="flex:1;font-size:11px;padding:9px 11px;color-scheme:${getTheme()}">
      </div>
      <div style="display:flex;gap:7px;margin-bottom:12px" class="page-in s2">
        <button onclick="filterHistoryByDateRange()" class="btn btn-primary" style="flex:1;padding:9px;font-size:12px">Cari</button>
        <button onclick="resetHistoryFilter()" class="btn btn-glass" style="flex:1;padding:9px;font-size:12px">Reset</button>
      </div>
      <div class="tab-group page-in s2" style="margin-bottom:14px">
        <button onclick="setHistoryFilter('daily')" class="tab-btn ${historyFilter==='daily'?'active':''}">Hari Ini</button>
        <button onclick="setHistoryFilter('monthly')" class="tab-btn ${historyFilter==='monthly'?'active':''}">Bulan Ini</button>
        <button onclick="setHistoryFilter('yearly')" class="tab-btn ${historyFilter==='yearly'?'active':''}">Tahun Ini</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:7px" class="page-in s3">
        ${visibleItems.map(t => {
          const txId = escapeHtml(t.id);
          const txName = escapeHtml(t.name || t.user || '-');
          const txTime = transactionHistoryTimeLabel(t);
          const itemCount = transactionProductItemsFromText(t.note || 'Transaksi', 'Transaksi').length;
          const payLabel = getTransactionPaymentLabel(t);
          const payMethod = normalizeTransactionPaymentMethod(t.paymentMethod || t.payment_method || t.paymentLabel || t.payment_label || t.paymentType || t.payment_type || t.metodePembayaran || t.metode_pembayaran) || 'cash';
          const trxCardClass = payMethod === 'qris_transfer' ? ' trx-card-qris' : ' trx-card-cash';
          return `
          <div class="trx-card${trxCardClass}">
            <div class="trx-icon" style="font-family:var(--num-font);font-weight:900;color:#000 !important;background:#ffd600 !important;box-shadow:0 1.5px 4px rgba(184, 146, 0, 0.3) !important">${itemCount}</div>
            <div style="flex:1;min-width:0">
              <div style="display:flex;align-items:center;gap:7px;margin-bottom:2px;flex-wrap:wrap">
                <span class="trx-amount">Rp ${formatRupiah(t.amount)}</span>
              </div>
              <div style="display:flex;align-items:center;gap:7px;margin-top:3px;flex-wrap:wrap">
                <p class="trx-time" style="margin:0">${txTime}</p>
                ${getTransactionPaymentBadge(t)}
                ${isAdmin() ? `<span class="user-chip" style="font-size:9px;padding:2px 7px;gap:4px;line-height:1;margin:0"><i class="fas fa-user" style="font-size:9px"></i>${escapeHtml(t.name || t.user)}</span>` : ''}
              </div>
            </div>
            <div class="trx-actions-inline" style="flex-shrink:0">
              <button onclick="openTransactionDetail('${txId}')" class="btn btn-glass icon-action-btn" title="Detail"><i class="fas fa-list"></i></button>
              <button onclick="printTransactionReceipt('${txId}')" class="btn btn-success icon-action-btn" title="Cetak"><i class="fas fa-print"></i></button>
              <button onclick="openEditTransactionModal('${txId}')" class="btn btn-glass icon-action-btn icon-edit-btn" title="Edit"><i class="fas fa-pen"></i></button>
              <button onclick="deleteTransaction('${txId}')" class="btn btn-danger icon-action-btn icon-trash-btn" title="Hapus"><i class="fas fa-trash-can"></i></button>
            </div>
          </div>
        `}).join('') || `<div style="text-align:center;padding:56px 0;color:var(--text-ghost)"><i class="fas fa-inbox" style="font-size:30px;margin-bottom:10px;display:block;opacity:0.5"></i><p style="font-size:12.5px">Tidak ada transaksi</p></div>`}
      </div>
      ${hasMore ? `<button onclick="increaseHistoryDisplayLimit()" class="btn btn-glass page-in s4" style="width:100%;margin-top:12px;padding:11px 12px;font-size:12px">Muat ${Math.min(HISTORY_PAGE_STEP, filtered.length - visibleItems.length)} transaksi lagi</button>` : ''}
    `;
    if ($('history-range-start')) $('history-range-start').value = rangeStartDate || '';
    if ($('history-range-end')) $('history-range-end').value = rangeEndDate || '';
    if ($('admin-history-user')) $('admin-history-user').value = selectedUserFilter;
  }


  function getReportMonthKey() {
    const raw = String(reportMonthKey || '').slice(0, 7);
    return /^\d{4}-\d{2}$/.test(raw) ? raw : toMonthKey(nowDate());
  }

  function getMonthMeta(monthKey = getReportMonthKey()) {
    const match = String(monthKey || '').match(/^(\d{4})-(\d{2})$/);
    const fallback = toMonthKey(nowDate());
    const [year, month] = match ? [Number(match[1]), Number(match[2])] : fallback.split('-').map(Number);
    const key = `${year}-${String(month).padStart(2, '0')}`;
    const days = new Date(year, month, 0).getDate();
    const start = `${key}-01`;
    const end = `${key}-${String(days).padStart(2, '0')}`;
    const label = new Date(year, month - 1, 1).toLocaleDateString('id-ID', { month: 'long', year: 'numeric' });
    return { key, year, month, days, start, end, label };
  }

  function getMonthDayKeys(monthKey = getReportMonthKey()) {
    const meta = getMonthMeta(monthKey);
    return Array.from({ length: meta.days }, (_, idx) => `${meta.key}-${String(idx + 1).padStart(2, '0')}`);
  }

  function getMonthlyReportTargetUser() {
    if (isAdmin() && selectedUserFilter !== 'all') return sanitizeUsername(selectedUserFilter);
    if (!isAdmin() && currentUser?.username) return sanitizeUsername(currentUser.username);
    return null;
  }

  function getReportUserName(username, fallback = '') {
    const found = getUserByUsername(username);
    return found?.name || fallback || username || '-';
  }

  function getReportUserRole(username, fallbackRole = 'staff') {
    const found = getUserByUsername(username);
    return normalizeRole(found?.role || fallbackRole || 'staff');
  }

  function buildMonthlyReportData(monthKey = getReportMonthKey()) {
    const meta = getMonthMeta(monthKey);
    const targetUser = getMonthlyReportTargetUser();
    const visibleTransactions = getVisibleTransactions();
    const visibleAttendance = getVisibleAttendance();
    const sourceTransactions = targetUser ? visibleTransactions.filter(t => sanitizeUsername(t.user) === targetUser) : visibleTransactions;
    const sourceAttendance = targetUser ? visibleAttendance.filter(a => sanitizeUsername(a.user) === targetUser) : visibleAttendance;
    const transactions = sourceTransactions.filter(t => getTransactionMonthKey(t) === meta.key || String(getTransactionDateKey(t) || '').startsWith(meta.key));
    const attendance = sourceAttendance.filter(a => String(extractDateKey(a) || '').startsWith(meta.key));
    const closings = getMonthlyClosingRecords(meta.key).filter(c => !targetUser || getClosingBonusValue(c, targetUser) > 0 || sanitizeUsername(c.user) === targetUser);
    const manualBonuses = getMonthlyManualBonuses(targetUser, meta.key);
    const dayKeys = getMonthDayKeys(meta.key);

    const userMap = new Map();
    const ensureUser = (username, name = '', role = 'staff') => {
      const key = sanitizeUsername(username || '');
      if (!key || key === 'admin') return null;
      if (targetUser && key !== targetUser) return null;
      if (!userMap.has(key)) {
        const found = getUserByUsername(key);
        userMap.set(key, {
          user: key,
          name: found?.name || name || key,
          role: normalizeRole(found?.role || role || 'staff'),
          omzet: 0,
          transaksi: 0,
          hariTransaksiSet: new Set(),
          hadirSet: new Set(),
          trxBonus: 0,
          closingBonus: 0,
          manualBonus: 0,
          dailySalary: 0,
          totalBonus: 0,
          avgTransaction: 0
        });
      }
      return userMap.get(key);
    };

    if (isAdmin()) {
      realActiveUsers().forEach(u => {
        if (!ADMIN_USERNAMES.includes(sanitizeUsername(u.username))) ensureUser(u.username, u.name, u.role || 'staff');
      });
    } else if (currentUser?.username) {
      ensureUser(currentUser.username, currentUser.name, currentUser.role || 'staff');
    }

    transactions.forEach(t => {
      const row = ensureUser(t.user, t.name, t.userRole || t.role || 'staff');
      if (!row) return;
      const amount = Number(t.amount || 0);
      const dateKey = getTransactionDateKey(t);
      row.omzet += amount;
      row.transaksi += 1;
      if (dateKey) row.hariTransaksiSet.add(dateKey);
    });

    attendance.forEach(a => {
      const row = ensureUser(a.user, a.name, 'staff');
      const dateKey = extractDateKey(a);
      if (row && dateKey) row.hadirSet.add(dateKey);
    });

    manualBonuses.forEach(b => ensureUser(b.user, b.name, b.userRole || b.role || 'staff'));
    closings.forEach(c => {
      const byUser = c.bonusByUser || {};
      Object.keys(byUser).forEach(u => ensureUser(u, getReportUserName(u), 'staff'));
      if (c.user) ensureUser(c.user, c.name, 'staff');
    });

    const userRows = Array.from(userMap.values()).map(row => {
      const userTransactions = transactions.filter(t => sanitizeUsername(t.user) === row.user);
      const staffTransactions = userTransactions.filter(t => !isDailyTransactionRecord(t));
      const dailyTransactions = userTransactions.filter(isDailyTransactionRecord);
      const role = getReportUserRole(row.user, row.role);
      row.role = role;
      row.trxBonus = isDailyRole(role) ? 0 : calculateTransactionBonusForList(staffTransactions);
      row.dailySalary = isDailyRole(role) ? calculateTransactionBonusForList(dailyTransactions.length ? dailyTransactions : userTransactions) : 0;
      row.closingBonus = isDailyRole(role) ? 0 : getMonthlyClosingBonus(row.user, meta.key);
      row.manualBonus = getMonthlyManualBonus(row.user, meta.key);
      row.totalBonus = row.trxBonus + row.closingBonus + row.manualBonus + row.dailySalary;
      row.hariTransaksi = row.hariTransaksiSet.size;
      row.hadir = row.hadirSet.size;
      row.avgTransaction = row.transaksi ? Math.round(row.omzet / row.transaksi) : 0;
      return row;
    }).filter(row => row.omzet || row.transaksi || row.hadir || row.totalBonus || (!targetUser && isAdmin()))
      .sort((a, b) => (b.omzet - a.omzet) || (b.totalBonus - a.totalBonus) || String(a.name).localeCompare(String(b.name)));

    const dailyRows = dayKeys.map(dateKey => {
      const tx = transactions.filter(t => getTransactionDateKey(t) === dateKey);
      const att = attendance.filter(a => extractDateKey(a) === dateKey);
      const close = closings.filter(c => c.dateKey === dateKey);
      const omzet = tx.reduce((sum, t) => sum + Number(t.amount || 0), 0);
      const trxCount = tx.length;
      const users = new Set(tx.map(t => sanitizeUsername(t.user)).filter(Boolean));
      const hadirUsers = new Set(att.map(a => sanitizeUsername(a.user)).filter(Boolean));
      const closingBonus = close.reduce((sum, c) => sum + getClosingBonusValue(c, targetUser), 0);
      return { dateKey, omzet, trxCount, userCount: users.size, hadirCount: hadirUsers.size, closingCount: close.length, closingBonus };
    });

    const omzet = transactions.reduce((sum, t) => sum + Number(t.amount || 0), 0);
    const trxCount = transactions.length;
    const activeUserCount = new Set(transactions.map(t => sanitizeUsername(t.user)).filter(Boolean)).size;
    const uniqueAttendance = new Set(attendance.map(a => `${sanitizeUsername(a.user)}-${extractDateKey(a)}`).filter(Boolean)).size;
    const daysWithSales = dailyRows.filter(d => d.trxCount > 0).length;
    const bestDay = dailyRows.reduce((best, row) => row.omzet > (best?.omzet || 0) ? row : best, null);
    const topTransaction = sortByCreatedDesc([...transactions]).sort((a, b) => Number(b.amount || 0) - Number(a.amount || 0))[0] || null;
    const staffTrxBonus = userRows.reduce((sum, u) => sum + Number(u.trxBonus || 0), 0);
    const dailySalary = userRows.reduce((sum, u) => sum + Number(u.dailySalary || 0), 0);
    const closingBonus = userRows.reduce((sum, u) => sum + Number(u.closingBonus || 0), 0);
    const manualBonus = userRows.reduce((sum, u) => sum + Number(u.manualBonus || 0), 0);
    const staffManualBonus = userRows.filter(u => !isDailyRole(u.role)).reduce((sum, u) => sum + Number(u.manualBonus || 0), 0);
    const dailyManualBonus = userRows.filter(u => isDailyRole(u.role)).reduce((sum, u) => sum + Number(u.manualBonus || 0), 0);
    const staffTotalBonus = staffTrxBonus + closingBonus + staffManualBonus;
    const dailyTotalSalary = dailySalary + dailyManualBonus;
    const totalBonus = staffTotalBonus + dailyTotalSalary;

    return {
      meta,
      targetUser,
      transactions,
      attendance,
      closings,
      manualBonuses,
      userRows,
      dailyRows,
      totals: {
        omzet,
        trxCount,
        activeUserCount,
        uniqueAttendance,
        daysWithSales,
        avgPerTransaction: trxCount ? Math.round(omzet / trxCount) : 0,
        avgPerSalesDay: daysWithSales ? Math.round(omzet / daysWithSales) : 0,
        staffTrxBonus,
        dailySalary,
        closingBonus,
        manualBonus,
        staffManualBonus,
        dailyManualBonus,
        staffTotalBonus,
        dailyTotalSalary,
        totalBonus,
        closingCount: closings.length,
        bestDay,
        topTransaction
      }
    };
  }

  function renderMonthlyStatCard(label, value, sub = '', color = 'var(--text)') {
    return `<div class="stat-mini" style="text-align:left">
      <p class="stat-mini-lbl">${label}</p>
      <p class="stat-mini-num" style="font-size:18px;color:${color};word-break:break-word">${value}</p>
      ${sub ? `<p style="font-size:9.5px;color:var(--text-ghost);margin-top:3px">${sub}</p>` : ''}
    </div>`;
  }


  function renderMonthlyAverageTransactionCard(avgAmount, trxCount = 0) {
    return `<div class="stat-mini" style="text-align:left;display:flex;flex-direction:column;justify-content:space-between;min-height:92px">
      <div>
        <p class="stat-mini-lbl" style="line-height:1.25;margin-bottom:5px">Rata-rata</p>
        <p style="font-size:9px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:var(--text-ghost);margin-bottom:5px">per transaksi</p>
      </div>
      <div>
        <p class="stat-mini-num" style="font-size:20px;line-height:1.08;color:var(--text);word-break:normal;white-space:nowrap">Rp ${formatRupiah(avgAmount)}</p>
        <p style="font-size:9.5px;color:var(--text-ghost);margin-top:5px">${Number(trxCount || 0)} transaksi dihitung</p>
      </div>
    </div>`;
  }

  function renderMonthlyBonusSalarySplitCard(totals) {
    const staffTotal = Number(totals.staffTotalBonus ?? (Number(totals.staffTrxBonus || 0) + Number(totals.closingBonus || 0) + Number(totals.manualBonus || 0)));
    const dailyTotal = Number(totals.dailyTotalSalary ?? totals.dailySalary ?? 0);
    const total = staffTotal + dailyTotal;
    return `<div class="stat-mini" style="text-align:left">
      <p class="stat-mini-lbl">Total Bonus + Gaji</p>
      <div style="display:flex;flex-direction:column;gap:5px;margin-top:3px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;border:1px solid rgba(91,143,255,.18);border-radius:9px;background:var(--accent-dim);padding:6px 7px">
          <span style="font-size:9.5px;font-weight:800;color:var(--accent)">Staff</span>
          <strong style="font-family:var(--num-font);font-size:12px;color:var(--accent);white-space:nowrap">Rp ${formatRupiah(staffTotal)}</strong>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;border:1px solid rgba(82,216,158,.18);border-radius:9px;background:var(--green-dim);padding:6px 7px">
          <span style="font-size:9.5px;font-weight:800;color:var(--green)">Harian</span>
          <strong style="font-family:var(--num-font);font-size:12px;color:var(--green);white-space:nowrap">Rp ${formatRupiah(dailyTotal)}</strong>
        </div>
      </div>
      <p style="font-size:9.5px;color:var(--text-ghost);margin-top:5px">Total Rp ${formatRupiah(total)}</p>
    </div>`;
  }

  function renderMonthlyReport() {
    const data = buildMonthlyReportData(getReportMonthKey());
    const { meta, totals, userRows, dailyRows, transactions, closings, manualBonuses } = data;
    const targetLabel = isAdmin() ? getSelectedUserLabel() : (currentUser?.name || 'Data Saya');
    const topTx = totals.topTransaction;
    const bestDay = totals.bestDay;
    const topUser = userRows.find(u => u.omzet > 0);
    const warning = transactions.length >= 9900 ? `<div class="card page-in s1" style="padding:11px 12px;border-color:rgba(255,196,107,.24);background:var(--amber-dim);color:var(--amber);font-size:11px;line-height:1.35"><i class="fas fa-triangle-exclamation"></i> Data bulan ini mendekati batas sinkron 10.000 baris. Kalau transaksi lebih banyak, pakai backup Excel untuk arsip lengkap.</div>` : '';

    return `
      ${isAdmin() ? `<div style="margin-bottom:10px" class="page-in s1"><select id="admin-report-user" class="g-input" onchange="setSelectedUserFilter(this.value)">${getUserOptionsHtml(true)}</select></div>` : ''}
      <div class="card page-in s1" style="padding:12px 13px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px">
          <div style="min-width:0">
            <p class="label-xs" style="margin:0;color:var(--accent)">Periode Laporan Bulanan</p>
            <p style="font-size:11px;color:var(--text-soft);margin-top:3px">${escapeHtml(targetLabel)} · ${meta.start} s/d ${meta.end}</p>
          </div>
          <span class="status-pill status-ok" style="white-space:nowrap"><i class="fas fa-calendar-days"></i> ${escapeHtml(meta.label)}</span>
        </div>
        <input type="month" id="report-month-picker" class="g-input" value="${meta.key}" onchange="setReportMonth(this.value)" style="color-scheme:${getTheme()};margin-bottom:9px">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px">
          <button onclick="syncMonthlyReportData()" class="btn btn-glass" style="padding:10px 8px;font-size:11px"><i class="fas fa-rotate"></i> Sinkron Bulan</button>
          <button onclick="exportMonthlyReportCsv()" class="btn btn-primary" style="padding:10px 8px;font-size:11px"><i class="fas fa-file-csv"></i> Export CSV</button>
        </div>
        <p style="font-size:10px;color:var(--text-ghost);line-height:1.35;margin-top:7px"><i class="fas fa-circle-info"></i> CSV berisi ringkasan totalan + rekap per user; detail riwayat closing tidak ditampilkan agar ringan.</p>
      </div>
      ${warning}
      <div class="stat-hero page-in">
        <p class="stat-label">Total Omzet Bulanan · ${escapeHtml(meta.label)}</p>
        <p class="stat-value">Rp ${formatRupiah(totals.omzet)}</p>
        <p class="stat-sub">${totals.trxCount} transaksi · ${totals.daysWithSales} hari jualan · rata-rata Rp ${formatRupiah(totals.avgPerSalesDay)}/hari jualan</p>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px" class="page-in s1">
        ${renderMonthlyStatCard('User Aktif', totals.activeUserCount, 'user transaksi', 'var(--green)')}
        ${renderMonthlyStatCard('Absensi', totals.uniqueAttendance, 'user-hari hadir', 'var(--accent)')}
        ${renderMonthlyAverageTransactionCard(totals.avgPerTransaction, totals.trxCount)}
        ${renderMonthlyBonusSalarySplitCard(totals)}
      </div>
      <div class="card page-in s2" style="padding:13px 14px;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px">
          <p class="label-xs" style="margin:0">Breakdown Bonus Bulanan</p>
          <span class="user-chip">${escapeHtml(meta.key)}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px;font-size:12px">
          ${[
            ['Bonus Transaksi Staff', totals.staffTrxBonus, 'fa-percent'],
            ['Gaji / Bonus Harian', totals.dailySalary, 'fa-user-clock'],
            ['Bonus Closing', totals.closingBonus, 'fa-lock'],
            ['Bonus Manual', totals.manualBonus, 'fa-pen-to-square']
          ].map(([label, value, icon]) => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 10px;border:1px solid var(--border);border-radius:11px;background:var(--surface)"><span style="color:#171717;font-weight:700"><i class="fas ${icon}" style="color:#171717;width:16px"></i> ${label}</span><strong style="font-family:var(--num-font);color:#171717">Rp ${formatRupiah(value)}</strong></div>`).join('')}
          <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px;border:1px solid rgba(255,196,107,.22);border-radius:12px;background:var(--amber-dim)"><span style="font-weight:800;color:#171717">Total dibayarkan</span><strong style="font-family:var(--num-font);font-size:15px;color:#171717">Rp ${formatRupiah(totals.totalBonus)}</strong></div>
        </div>
      </div>
      <div class="card page-in s2" style="padding:13px 14px;margin-top:10px">
        <p class="label-xs">Highlight Bulan Ini</p>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:7px">
          ${renderMonthlyStatCard('Top User', topUser ? escapeHtml(topUser.name) : '-', topUser ? `Rp ${formatRupiah(topUser.omzet)}` : 'belum ada', 'var(--green)')}
          ${renderMonthlyStatCard('Hari Terbaik', bestDay && bestDay.omzet ? formatDateLabel(bestDay.dateKey) : '-', bestDay && bestDay.omzet ? `Rp ${formatRupiah(bestDay.omzet)}` : 'belum ada', 'var(--accent)')}
          ${renderMonthlyStatCard('Transaksi Tertinggi', topTx ? `Rp ${formatRupiah(topTx.amount)}` : '-', topTx ? `${escapeHtml(topTx.name || topTx.user)} · ${formatDateLabel(getTransactionDateKey(topTx))}` : 'belum ada', 'var(--amber)')}
          ${renderMonthlyStatCard('Closing', totals.closingCount, `total Rp ${formatRupiah(totals.closingBonus)}`, 'var(--amber)')}
        </div>
      </div>
      <div class="card page-in s3" style="padding:13px 14px;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:9px">
          <p class="label-xs" style="margin:0">Rekap Per User</p>
          <span class="user-chip">${userRows.length} user</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px;max-height:360px;overflow-y:auto">
          ${userRows.map((row, idx) => `<div style="border:1px solid var(--border);border-radius:13px;background:var(--surface);padding:10px 11px">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;margin-bottom:8px">
              <div style="min-width:0"><div style="font-size:12.5px;font-weight:850;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">#${idx + 1} ${escapeHtml(row.name)}</div><div style="font-size:10px;color:var(--text-soft);margin-top:2px">@${escapeHtml(row.user)} · ${getRoleDisplayName(row.role)} · ${row.transaksi} trx · ${row.hadir} hadir</div></div>
              <div style="text-align:right;flex-shrink:0"><div style="font-family:var(--num-font);font-size:13px;font-weight:900;color:var(--green)">Rp ${formatRupiah(row.omzet)}</div><div style="font-size:9px;color:var(--text-ghost)">omzet</div></div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:10.5px;color:var(--text-soft)">
              <div>Bonus trx: <b style="color:var(--text)">Rp ${formatRupiah(row.trxBonus)}</b></div>
              <div>Closing: <b style="color:var(--text)">Rp ${formatRupiah(row.closingBonus)}</b></div>
              <div>Manual: <b style="color:${row.manualBonus < 0 ? 'var(--red)' : 'var(--text)'}">Rp ${formatRupiah(row.manualBonus)}</b></div>
              <div>Gaji harian: <b style="color:var(--text)">Rp ${formatRupiah(row.dailySalary)}</b></div>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);margin-top:8px;padding-top:8px"><span style="font-size:10px;color:var(--text-ghost)">${row.hariTransaksi} hari transaksi · avg Rp ${formatRupiah(row.avgTransaction)}</span><strong style="font-family:var(--num-font);font-size:12px;color:var(--amber)">Total Rp ${formatRupiah(row.totalBonus)}</strong></div>
          </div>`).join('') || `<div style="font-size:12px;color:var(--text-soft);padding:12px;text-align:center;border:1px dashed var(--border);border-radius:12px">Belum ada data user untuk bulan ini.</div>`}
        </div>
      </div>
      <div class="card page-in s3" style="padding:13px 14px;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:9px">
          <p class="label-xs" style="margin:0">Rekap Harian 1 Bulan</p>
          <span class="user-chip">${meta.days} hari</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px;max-height:330px;overflow-y:auto">
          ${dailyRows.filter(d => d.trxCount || d.hadirCount || d.closingCount).map(d => `<div style="display:grid;grid-template-columns:86px 1fr auto;gap:7px;align-items:center;padding:8px 9px;border:1px solid var(--border);border-radius:11px;background:var(--surface)">
            <div style="font-size:10.5px;color:var(--text-soft);font-weight:700">${formatDateLabel(d.dateKey)}</div>
            <div style="min-width:0"><div style="font-family:var(--num-font);font-size:12px;font-weight:850;color:var(--text)">Rp ${formatRupiah(d.omzet)}</div><div style="font-size:9.5px;color:var(--text-ghost)">${d.trxCount} trx · ${d.userCount} user · ${d.hadirCount} hadir</div></div>
            <div style="font-size:9.5px;color:var(--amber);text-align:right">${d.closingBonus ? `+Rp ${formatRupiah(d.closingBonus)}` : ''}</div>
          </div>`).join('') || `<div style="font-size:12px;color:var(--text-soft);padding:12px;text-align:center;border:1px dashed var(--border);border-radius:12px">Belum ada aktivitas pada bulan ini.</div>`}
        </div>
      </div>
      <div class="card page-in s4" style="padding:13px 14px;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:9px">
          <p class="label-xs" style="margin:0">Detail Pendukung</p>
          <span class="user-chip">manual / top trx</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:9px">
          <div>
            <div style="font-size:11px;font-weight:800;color:var(--amber);margin-bottom:6px"><i class="fas fa-pen-to-square"></i> Bonus Manual</div>
            ${manualBonuses.slice(0, 12).map(b => `<div style="display:flex;justify-content:space-between;gap:8px;padding:7px 0;border-bottom:1px solid var(--border);font-size:11px"><span>${escapeHtml(b.name || b.user)} · ${escapeHtml(b.note || b.reason || 'Bonus manual')}</span><b style="font-family:var(--num-font);color:${Number(b.amount || 0) < 0 ? 'var(--red)' : 'var(--text)'}">Rp ${formatRupiah(b.amount)}</b></div>`).join('') || `<div style="font-size:11px;color:var(--text-soft)">Belum ada bonus manual bulan ini.</div>`}
          </div>
          <div>
            <div style="font-size:11px;font-weight:800;color:var(--accent);margin-bottom:6px"><i class="fas fa-arrow-trend-up"></i> Top 10 Transaksi</div>
            ${[...transactions].sort((a, b) => Number(b.amount || 0) - Number(a.amount || 0)).slice(0, 10).map(t => `<div style="display:flex;justify-content:space-between;gap:8px;padding:7px 0;border-bottom:1px solid var(--border);font-size:11px"><span style="min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${formatDateLabel(getTransactionDateKey(t))} · ${escapeHtml(t.name || t.user)} · ${getTransactionPaymentLabel(t)} · ${escapeHtml(t.note || 'Transaksi')}</span><b style="font-family:var(--num-font);white-space:nowrap">Rp ${formatRupiah(t.amount)}</b></div>`).join('') || `<div style="font-size:11px;color:var(--text-soft)">Belum ada transaksi bulan ini.</div>`}
          </div>
        </div>
      </div>
    `;
  }

  async function syncMonthlyReportData(monthKey = getReportMonthKey()) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    const meta = getMonthMeta(monthKey);
    const mergeById = (current, incoming) => {
      const map = new Map();
      (current || []).forEach(item => { if (item?.id) map.set(String(item.id), item); });
      (incoming || []).forEach(item => { if (item?.id) map.set(String(item.id), item); });
      return sortByCreatedDesc(Array.from(map.values()));
    };
    setLoading(true);
    try {
      const maxRows = 10000;
      const txMonthSnap = await getDocs(query(collection(db, 'transactions'), where('monthKey', '==', meta.key), limit(maxRows)));
      const txDateSnap = await getDocs(query(collection(db, 'transactions'), where('dateKey', '>=', meta.start), where('dateKey', '<=', meta.end), limit(maxRows)));
      const attSnap = await getDocs(query(collection(db, 'attendance'), where('dateKey', '>=', meta.start), where('dateKey', '<=', meta.end), limit(maxRows)));
      const closingMonthSnap = await getDocs(query(collection(db, 'closings'), where('monthKey', '==', meta.key), limit(maxRows)));
      const closingDateSnap = await getDocs(query(collection(db, 'closings'), where('dateKey', '>=', meta.start), where('dateKey', '<=', meta.end), limit(maxRows)));
      const manualMonthSnap = await getDocs(query(collection(db, 'manualBonuses'), where('monthKey', '==', meta.key), limit(maxRows)));
      const manualDateSnap = await getDocs(query(collection(db, 'manualBonuses'), where('dateKey', '>=', meta.start), where('dateKey', '<=', meta.end), limit(maxRows)));
      cachedTransactions = mergeById(cachedTransactions, [...txMonthSnap.docs, ...txDateSnap.docs].map(d => ({ id: d.id, ...d.data() })));
      cachedAttendance = mergeById(cachedAttendance, attSnap.docs.map(d => ({ id: d.id, ...d.data() })));
      cachedClosings = mergeById(cachedClosings, [...closingMonthSnap.docs, ...closingDateSnap.docs].map(d => ({ id: d.id, ...d.data() })).filter(isClosingDataRecord));
      cachedManualBonuses = dedupeManualBonusRecords(mergeById(cachedManualBonuses, [...manualMonthSnap.docs, ...manualDateSnap.docs].map(d => ({ id: d.id, ...d.data() }))));
      showToast(`✓ Data ${meta.label} disinkronkan`);
      await renderReport();
    } catch (e) {
      console.error(e);
      showToast('Gagal sinkron data bulanan. Cek koneksi / policy Supabase.', true);
    }
    setLoading(false);
  }

  async function renderReport() {
    const rv = $('report-view'); if (!rv) return;
    if (reportFilter === 'monthly') {
      rv.innerHTML = renderMonthlyReport();
      if ($('admin-report-user')) $('admin-report-user').value = selectedUserFilter;
      if ($('report-month-picker')) $('report-month-picker').value = getReportMonthKey();
      return;
    }
    const visibleTransactions = getVisibleTransactions();
    const visibleAttendance = getVisibleAttendance();
    const sourceTransactions = isAdmin() && selectedUserFilter !== 'all' ? visibleTransactions.filter(t => t.user === selectedUserFilter) : visibleTransactions;
    const sourceAttendance = isAdmin() && selectedUserFilter !== 'all' ? visibleAttendance.filter(a => a.user === selectedUserFilter) : visibleAttendance;
    const today = toDateKey(nowDate()), month = toMonthKey(nowDate()), year = getBusinessYear(nowDate());
    let ft = [], fa = [], title = '';
    if (reportFilter === 'daily') {
      title = `${isAdmin() ? 'Global' : 'Hari Ini'} (${today})`;
      ft = sourceTransactions.filter(t => getTransactionDateKey(t) === today);
      fa = sourceAttendance.filter(a => extractDateKey(a) === today);
    } else {
      title = `Tahun ${year}`;
      ft = sourceTransactions.filter(t => String(getTransactionDateKey(t) || '').startsWith(year));
      fa = sourceAttendance.filter(a => String(extractDateKey(a) || '').startsWith(year));
    }
    const omzet = ft.reduce((a,b)=>a+Number(b.amount||0),0);
    const bonusPeriod = reportFilter === 'daily'
      ? { type:'daily', dateKey: today }
      : { type:'yearly', year };
    const bonusBreakdown = getBonusBreakdown(ft, isAdmin() && selectedUserFilter !== 'all' ? selectedUserFilter : (!isAdmin() ? currentUser.username : null), bonusPeriod);
    const bonus = bonusBreakdown.totalBonus;
    const hadir = new Set(fa.map(a => `${sanitizeUsername(a.user)}-${extractDateKey(a)}`)).size;
    const userAktif = new Set(ft.map(t => t.user)).size;
    rv.innerHTML = `
      ${isAdmin() ? `<div style="margin-bottom:10px" class="page-in s1"><select id="admin-report-user" class="g-input" onchange="setSelectedUserFilter(this.value)">${getUserOptionsHtml(true)}</select></div>` : ''}
      <div class="stat-hero page-in">
        <p class="stat-label">${isAdmin() ? 'Laporan Global' : 'Total Omzet'} · ${title}</p>
        <p class="stat-value">Rp ${formatRupiah(omzet)}</p>
        <p class="stat-sub">${ft.length} transaksi · ${isAdmin() ? getSelectedUserLabel() : currentUser.name}</p>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px" class="page-in s1">
        <div class="stat-mini">
          <p class="stat-mini-lbl">${isAdmin() ? 'User Aktif' : 'Hadir'}</p>
          <p class="stat-mini-num" style="color:var(--green)">${isAdmin() ? userAktif : hadir}</p>
          <p style="font-size:9.5px;color:var(--text-ghost);margin-top:3px">${isAdmin() ? 'user' : 'hari'}</p>
        </div>
        <div class="stat-mini">
          <p class="stat-mini-lbl">Bonus</p>
          <p class="stat-mini-num" style="color:var(--amber)">${formatRupiah(bonus)}</p>
          <p style="font-size:9.5px;color:var(--text-ghost);margin-top:3px">FEE</p>
        </div>
      </div>
      ${isAdmin() ? `
      <div class="card page-in s2" style="padding:13px 14px;margin-top:10px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:9px">
          <p class="label-xs" style="margin:0">Ranking Omzet User</p>
          <span class="user-chip">${title}</span>
        </div>
        <div style="display:flex;flex-direction:column;gap:7px">
          ${Object.values(ft.reduce((acc, t) => {
            const key = sanitizeUsername(t.user);
            if (!acc[key]) acc[key] = { user:key, name:t.name || key, omzet:0, transaksi:0 };
            acc[key].omzet += Number(t.amount || 0);
            acc[key].transaksi += 1;
            return acc;
          }, {})).sort((a,b)=>b.omzet-a.omzet).slice(0,5).map((row, idx) => `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border:1px solid var(--border);border-radius:12px;background:var(--surface)"><div><div style="font-size:12px;font-weight:750">#${idx+1} ${escapeHtml(row.name)}</div><div style="font-size:10px;color:var(--text-soft)">${row.transaksi} transaksi</div></div><div style="font-family:var(--num-font);font-size:12px;font-weight:800">Rp ${formatRupiah(row.omzet)}</div></div>`).join('') || `<div style="font-size:12px;color:var(--text-soft);padding:4px 0">Belum ada transaksi untuk ranking.</div>`}
        </div>
      </div>` : ''}
      <div class="card page-in s3" style="padding:13px 14px;margin-top:10px">
        <p class="label-xs">${isAdmin() ? 'Absensi Terbaru' : 'Daftar Hadir'}</p>
        <div style="max-height:180px;overflow-y:auto">
          ${sortByCreatedDesc(fa).slice(0, 30).map(a => `<div style="display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid var(--border);font-size:12px;gap:10px"><span style="color:var(--text);font-weight:500">${isAdmin() ? `${escapeHtml(a.name || a.user)} · ` : ''}${formatDateLabel(extractDateKey(a))}</span><span style="font-family:var(--num-font);font-size:10px;color:var(--text-soft)">${formatAttendanceTime(a)}</span></div>`).join('') || '<p style="text-align:center;font-size:12px;color:var(--text-ghost);padding:10px 0">Belum ada absen</p>'}
        </div>
      </div>
    `;
    if ($('admin-report-user')) $('admin-report-user').value = selectedUserFilter;
  }

  function setReportMonth(value) {
    reportMonthKey = String(value || '').slice(0, 7) || toMonthKey(nowDate());
    reportFilter = 'monthly';
    ['daily','monthly','yearly'].forEach(tab => {
      const b = $('f-' + tab); if (b) b.classList.toggle('active', tab === 'monthly');
    });
    renderReport();
  }

  function getMonthlyReportExportRows(data = buildMonthlyReportData(getReportMonthKey())) {
    const selectedLabel = isAdmin() ? getSelectedUserLabel() : (currentUser?.name || 'Data Saya');
    const rupiahText = (value) => `Rp ${formatRupiah(Number(value || 0))}`;
    const cleanText = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();
    const bestDay = data.totals.bestDay;
    const topUser = data.userRows.find(u => Number(u.omzet || 0) > 0) || null;
    const topBonusUser = [...data.userRows].sort((a, b) => Number(b.totalBonus || 0) - Number(a.totalBonus || 0))[0] || null;
    const topTransaction = data.totals.topTransaction;
    const rows = [];
    const base = (bagian, keterangan = '') => ({
      bulan: data.meta.key,
      periode: `${data.meta.start} s/d ${data.meta.end}`,
      filter_user: selectedLabel,
      bagian,
      nama: '',
      username: '',
      role: '',
      omzet: '',
      transaksi: '',
      hari_transaksi: '',
      hari_hadir: '',
      user_aktif: '',
      absensi_user_hari: '',
      hari_jualan: '',
      rata_rata_transaksi: '',
      rata_rata_hari_jualan: '',
      bonus_transaksi_staff: '',
      gaji_bonus_harian: '',
      bonus_closing: '',
      bonus_manual: '',
      total_bonus_gaji: '',
      omzet_bersih: '',
      keterangan
    });

    rows.push({
      ...base('RINGKASAN TOTAL', 'Angka total bulan ini, sudah dijumlahkan otomatis'),
      nama: 'TOTAL BULANAN',
      omzet: data.totals.omzet,
      transaksi: data.totals.trxCount,
      user_aktif: data.totals.activeUserCount,
      absensi_user_hari: data.totals.uniqueAttendance,
      hari_jualan: data.totals.daysWithSales,
      rata_rata_transaksi: data.totals.avgPerTransaction,
      rata_rata_hari_jualan: data.totals.avgPerSalesDay,
      bonus_transaksi_staff: data.totals.staffTrxBonus,
      gaji_bonus_harian: data.totals.dailySalary,
      bonus_closing: data.totals.closingBonus,
      bonus_manual: data.totals.manualBonus,
      total_bonus_gaji: data.totals.totalBonus,
      omzet_bersih: Number(data.totals.omzet || 0) - Number(data.totals.totalBonus || 0)
    });

    rows.push({
      ...base('RINGKASAN RUPIAH', 'Format siap baca'),
      nama: 'TOTAL BULANAN',
      omzet: rupiahText(data.totals.omzet),
      rata_rata_transaksi: rupiahText(data.totals.avgPerTransaction),
      rata_rata_hari_jualan: rupiahText(data.totals.avgPerSalesDay),
      bonus_transaksi_staff: rupiahText(data.totals.staffTrxBonus),
      gaji_bonus_harian: rupiahText(data.totals.dailySalary),
      bonus_closing: rupiahText(data.totals.closingBonus),
      bonus_manual: rupiahText(data.totals.manualBonus),
      total_bonus_gaji: rupiahText(data.totals.totalBonus),
      omzet_bersih: rupiahText(Number(data.totals.omzet || 0) - Number(data.totals.totalBonus || 0))
    });

    rows.push({
      ...base('HIGHLIGHT', topUser ? `Omzet tertinggi: ${rupiahText(topUser.omzet)}` : 'Belum ada omzet'),
      nama: 'USER OMZET TERTINGGI',
      username: topUser?.user || '',
      role: topUser ? getRoleDisplayName(topUser.role) : '',
      omzet: topUser ? topUser.omzet : 0,
      transaksi: topUser ? topUser.transaksi : 0
    });
    rows.push({
      ...base('HIGHLIGHT', topBonusUser ? `Bonus/gaji tertinggi: ${rupiahText(topBonusUser.totalBonus)}` : 'Belum ada bonus/gaji'),
      nama: 'USER BONUS/GAJI TERTINGGI',
      username: topBonusUser?.user || '',
      role: topBonusUser ? getRoleDisplayName(topBonusUser.role) : '',
      total_bonus_gaji: topBonusUser ? topBonusUser.totalBonus : 0
    });
    rows.push({
      ...base('HIGHLIGHT', bestDay ? `Hari terbaik ${bestDay.dateKey}` : 'Belum ada hari jualan'),
      nama: 'HARI OMZET TERTINGGI',
      omzet: bestDay ? bestDay.omzet : 0,
      transaksi: bestDay ? bestDay.trxCount : 0,
      user_aktif: bestDay ? bestDay.userCount : 0,
      hari_hadir: bestDay ? bestDay.hadirCount : 0,
      keterangan: bestDay ? `Tanggal ${bestDay.dateKey} · ${rupiahText(bestDay.omzet)}` : 'Belum ada data'
    });
    rows.push({
      ...base('HIGHLIGHT', topTransaction ? cleanText(topTransaction.note || '') : 'Belum ada transaksi'),
      nama: 'TRANSAKSI TERTINGGI',
      username: topTransaction ? sanitizeUsername(topTransaction.user) : '',
      omzet: topTransaction ? Number(topTransaction.amount || 0) : 0,
      keterangan: topTransaction ? `${getTransactionDateKey(topTransaction) || '-'} · ${topTransaction.name || topTransaction.user || '-'} · ${rupiahText(topTransaction.amount)}` : 'Belum ada data'
    });

    data.userRows.forEach((row, idx) => {
      rows.push({
        ...base('REKAP PER USER', `Ranking #${idx + 1}`),
        nama: row.name,
        username: row.user,
        role: getRoleDisplayName(row.role),
        omzet: row.omzet,
        transaksi: row.transaksi,
        hari_transaksi: row.hariTransaksi,
        hari_hadir: row.hadir,
        rata_rata_transaksi: row.avgTransaction,
        bonus_transaksi_staff: row.trxBonus,
        gaji_bonus_harian: row.dailySalary,
        bonus_closing: row.closingBonus,
        bonus_manual: row.manualBonus,
        total_bonus_gaji: row.totalBonus,
        omzet_bersih: Number(row.omzet || 0) - Number(row.totalBonus || 0)
      });
    });

    data.dailyRows.filter(d => d.omzet || d.trxCount || d.hadirCount || d.closingCount || d.closingBonus).forEach(d => {
      rows.push({
        ...base('REKAP HARIAN', d.dateKey),
        nama: d.dateKey,
        omzet: d.omzet,
        transaksi: d.trxCount,
        user_aktif: d.userCount,
        hari_hadir: d.hadirCount,
        bonus_closing: d.closingBonus,
        keterangan: `${d.closingCount} closing`
      });
    });

    return rows;
  }

  function exportMonthlyReportCsv() {
    const data = buildMonthlyReportData(getReportMonthKey());
    const rows = getMonthlyReportExportRows(data);
    if (!rows.length) return showToast('Belum ada data untuk CSV', true);
    const headers = [
      'bulan', 'periode', 'filter_user', 'bagian', 'nama', 'username', 'role',
      'omzet', 'transaksi', 'hari_transaksi', 'hari_hadir', 'user_aktif', 'absensi_user_hari', 'hari_jualan',
      'rata_rata_transaksi', 'rata_rata_hari_jualan', 'bonus_transaksi_staff', 'gaji_bonus_harian',
      'bonus_closing', 'bonus_manual', 'total_bonus_gaji', 'omzet_bersih', 'keterangan'
    ];
    const csv = '\ufeff' + toCsv(rows, headers);
    downloadTextFile(csv, `ringkasan-totalan-bulanan-${data.meta.key}-${sanitizeUsername(getSelectedUserLabel()) || 'semua-user'}.csv`, 'text/csv;charset=utf-8');
    showToast('✓ CSV ringkasan totalan diunduh');
  }

  async function exportMonthlyReportXlsx() {
    let XLSX;
    try {
      XLSX = await ensureXlsxReady();
    } catch (e) {
      return showToast(e.message || 'Library Excel gagal dimuat', true);
    }
    const data = buildMonthlyReportData(getReportMonthKey());
    const selectedLabel = isAdmin() ? getSelectedUserLabel() : (currentUser?.name || 'data-saya');
    const wb = XLSX.utils.book_new();
    const rupiah = (value) => `Rp ${formatRupiah(Number(value || 0))}`;
    const pct = (value, total) => total ? `${((Number(value || 0) / Number(total || 1)) * 100).toFixed(1)}%` : '0%';
    const bestDay = data.totals.bestDay;
    const topUser = data.userRows.find(u => Number(u.omzet || 0) > 0) || null;
    const topBonusUser = [...data.userRows].sort((a, b) => Number(b.totalBonus || 0) - Number(a.totalBonus || 0))[0] || null;
    const topTransaction = data.totals.topTransaction;
    const bonusTotal = Number(data.totals.totalBonus || 0);

    const rows = [];
    const section = (title) => {
      rows.push([]);
      rows.push([title]);
    };
    const metric = (label, value, note = '') => rows.push([label, value, note]);

    rows.push([`LAPORAN BULANAN ROCKY HIJAB - ${data.meta.label}`]);
    rows.push([`Periode: ${data.meta.start} s/d ${data.meta.end}`]);
    rows.push([`Filter User: ${selectedLabel}`]);
    rows.push([`Dibuat: ${new Date().toLocaleString('id-ID')}`]);

    section('RINGKASAN UTAMA');
    metric('Total Omzet', rupiah(data.totals.omzet), `${data.totals.trxCount} transaksi`);
    metric('Total Bonus + Gaji', rupiah(data.totals.totalBonus), 'Akumulasi bonus transaksi, harian, closing, manual');
    metric('Omzet Bersih Setelah Bonus/Gaji', rupiah(Number(data.totals.omzet || 0) - bonusTotal), 'Omzet - total bonus/gaji');
    metric('User Aktif', data.totals.activeUserCount, 'User yang punya transaksi');
    metric('Absensi User-Hari', data.totals.uniqueAttendance, 'Total kehadiran unik per user per hari');
    metric('Hari Jualan', data.totals.daysWithSales, 'Hari yang memiliki transaksi');
    metric('Rata-rata per Transaksi', rupiah(data.totals.avgPerTransaction), 'Omzet / jumlah transaksi');
    metric('Rata-rata per Hari Jualan', rupiah(data.totals.avgPerSalesDay), 'Omzet / hari jualan');

    section('RINGKASAN BONUS / GAJI');
    metric('Bonus Transaksi Staff', rupiah(data.totals.staffTrxBonus), pct(data.totals.staffTrxBonus, bonusTotal));
    metric('Gaji / Bonus Harian', rupiah(data.totals.dailySalary), pct(data.totals.dailySalary, bonusTotal));
    metric('Bonus Closing', rupiah(data.totals.closingBonus), pct(data.totals.closingBonus, bonusTotal));
    metric('Bonus Manual', rupiah(data.totals.manualBonus), pct(data.totals.manualBonus, bonusTotal));
    metric('Total Bonus + Gaji', rupiah(data.totals.totalBonus), 'Total kewajiban bulan ini');

    section('HIGHLIGHT');
    metric('User Omzet Tertinggi', topUser ? `${topUser.name} (${topUser.user})` : '-', topUser ? rupiah(topUser.omzet) : '');
    metric('User Bonus/Gaji Tertinggi', topBonusUser ? `${topBonusUser.name} (${topBonusUser.user})` : '-', topBonusUser ? rupiah(topBonusUser.totalBonus) : '');
    metric('Hari Omzet Tertinggi', bestDay?.dateKey || '-', bestDay ? `${rupiah(bestDay.omzet)} · ${bestDay.trxCount} transaksi` : '');
    metric('Transaksi Tertinggi', topTransaction ? `${topTransaction.name || topTransaction.user || '-'} · ${getTransactionDateKey(topTransaction) || '-'}` : '-', topTransaction ? `${rupiah(topTransaction.amount)} · ${topTransaction.note || ''}` : '');

    section('RINGKASAN PER USER');
    rows.push(['No', 'Nama', 'Username', 'Role', 'Omzet', 'Transaksi', 'Hari Transaksi', 'Hari Hadir', 'Rata-rata/Transaksi', 'Bonus Transaksi', 'Gaji/Harian', 'Bonus Closing', 'Bonus Manual', 'Total Bonus/Gaji', 'Omzet Bersih']);
    data.userRows.forEach((row, idx) => {
      rows.push([
        idx + 1,
        row.name,
        row.user,
        getRoleDisplayName(row.role),
        rupiah(row.omzet),
        row.transaksi,
        row.hariTransaksi,
        row.hadir,
        rupiah(row.avgTransaction),
        rupiah(row.trxBonus),
        rupiah(row.dailySalary),
        rupiah(row.closingBonus),
        rupiah(row.manualBonus),
        rupiah(row.totalBonus),
        rupiah(Number(row.omzet || 0) - Number(row.totalBonus || 0))
      ]);
    });

    section('RINGKASAN HARIAN');
    rows.push(['Tanggal', 'Omzet', 'Transaksi', 'User Aktif', 'Hadir', 'Closing', 'Bonus Closing']);
    data.dailyRows.filter(d => d.omzet || d.trxCount || d.hadirCount || d.closingCount || d.closingBonus).forEach(d => {
      rows.push([d.dateKey, rupiah(d.omzet), d.trxCount, d.userCount, d.hadirCount, d.closingCount, rupiah(d.closingBonus)]);
    });

    section('CATATAN');
    rows.push(['File Excel ini sengaja dibuat dalam 1 sheet ringkasan supaya langsung kebaca tanpa buka banyak tab.']);
    rows.push(['Kalau butuh data mentah transaksi/absensi/closing, gunakan menu backup/export data terpisah.']);

    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = [
      { wch: 24 }, { wch: 24 }, { wch: 18 }, { wch: 14 }, { wch: 18 }, { wch: 12 }, { wch: 14 }, { wch: 12 },
      { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 18 }
    ];
    ws['!merges'] = [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }];
    XLSX.utils.book_append_sheet(wb, ws, 'Ringkasan Bulanan');
    XLSX.writeFile(wb, `ringkasan-bulanan-${data.meta.key}-${sanitizeUsername(selectedLabel) || 'semua-user'}.xlsx`);
    showToast('✓ Excel ringkasan bulanan diunduh');
  }

  function fillAdminUserForm(username = '') {
    if (!isAdmin()) return;
    const target = sanitizeUsername(username || $('admin-user-select')?.value || '');
    const data = getUserByUsername(target);
    if ($('admin-user-select')) $('admin-user-select').value = target || '';
    if ($('admin-user-username')) $('admin-user-username').value = data?.username || target || '';
    if ($('admin-user-name')) $('admin-user-name').value = data?.name || '';
    if ($('admin-user-pin')) $('admin-user-pin').value = data?.pin || '';
    if ($('admin-user-role')) {
      $('admin-user-role').value = normalizeRole(data?.role || 'staff');
      $('admin-user-role').dataset.initialRole = data ? normalizeRole(data.role || 'staff') : '';
    }
    if ($('admin-user-bonus-percent')) {
      const bonusPercentValue = data ? getUserTransactionBonusPercent(data.username) : '';
      $('admin-user-bonus-percent').value = data ? String(bonusPercentValue) : '';
    }
    if ($('admin-user-daily-percent')) {
      const bonusPercentValue = data ? getUserTransactionBonusPercent(data.username) : '';
      $('admin-user-daily-percent').value = data ? String(bonusPercentValue) : '';
    }
    if ($('admin-user-closing-minute')) {
      const closingValue = data ? getUserClosingBonusPerMinute(data.username) : '';
      $('admin-user-closing-minute').value = data ? String(closingValue) : '';
    }
    if ($('admin-user-dummy')) $('admin-user-dummy').checked = !!(data && isDummyUser(data));
    updateAdminUserClosingLock();
  }

  function updateAdminUserClosingLock() {
    const role = normalizeRole($('admin-user-role')?.value || 'staff');
    const input = $('admin-user-closing-minute');
    const note = $('admin-user-closing-note');
    if (!input) return;
    if (role === 'harian') {
      input.value = '0';
      input.disabled = true;
      input.dataset.lockedClosing = '1';
      input.placeholder = 'Terkunci untuk karyawan harian';
      if (note) note.innerHTML = '<i class="fas fa-lock"></i> Karyawan harian tidak mendapat bonus closing. Nilai otomatis 0.';
    } else if (role === 'admin') {
      input.value = '0';
      input.disabled = true;
      input.dataset.lockedClosing = '1';
      input.placeholder = 'Admin tidak mendapat bonus closing';
      if (note) note.innerHTML = '<i class="fas fa-lock"></i> Admin tidak dihitung bonus closing.';
    } else {
      input.disabled = false;
      if (input.dataset.lockedClosing === '1' && (!input.value || input.value === '0')) input.value = String(getClosingBonusPerMinute());
      input.dataset.lockedClosing = '0';
      input.placeholder = 'Bonus closing user / menit contoh 100';
      if (note) note.innerHTML = '<i class="fas fa-lock-open"></i> Staff bisa mendapat bonus closing per menit.';
    }
  }

  function clearAdminUserForm() {
    if ($('admin-user-select')) $('admin-user-select').value = '';
    if ($('admin-user-username')) $('admin-user-username').value = '';
    if ($('admin-user-name')) $('admin-user-name').value = '';
    if ($('admin-user-pin')) $('admin-user-pin').value = '';
    if ($('admin-user-role')) { $('admin-user-role').value = 'staff'; $('admin-user-role').dataset.initialRole = ''; }
    if ($('admin-user-bonus-percent')) $('admin-user-bonus-percent').value = '';
    if ($('admin-user-daily-percent')) $('admin-user-daily-percent').value = '';
    if ($('admin-user-closing-minute')) $('admin-user-closing-minute').value = '';
    if ($('admin-user-dummy')) $('admin-user-dummy').checked = false;
    updateAdminUserClosingLock();
  }

  async function saveAdminUser() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const username = sanitizeUsername($('admin-user-username')?.value);
    const name = String($('admin-user-name')?.value || '').trim();
    const pin = String($('admin-user-pin')?.value || '').trim();
    const role = normalizeRole($('admin-user-role')?.value || 'staff');
    const dummyMode = $('admin-user-dummy')?.checked === true;
    const bonusPercentRaw = String($('admin-user-bonus-percent')?.value || $('admin-user-daily-percent')?.value || '').replace(',', '.').trim();
    const closingRaw = String($('admin-user-closing-minute')?.value || '').replace(/\D/g, '').trim();
    const userBonusPercent = bonusPercentRaw === '' ? getTransactionBonusPercent() : Number(bonusPercentRaw);
    const userClosingPerMinute = (role === 'harian' || role === 'admin') ? 0 : (closingRaw === '' ? getClosingBonusPerMinute() : Number(closingRaw));
    if (!username || !name || !pin) return showToast('Lengkapi username, nama, dan PIN!', true);
    if (!/^[a-z0-9_-]{3,30}$/.test(username)) return showToast('Username hanya boleh huruf kecil, angka, _ atau - (min 3)', true);
    if (name.length < 2) return showToast('Nama terlalu pendek', true);
    if (pin.length < 3) return showToast('PIN minimal 3 digit/karakter', true);
    if (!['admin','staff','harian'].includes(role)) return showToast('Role tidak valid!', true);
    if (!Number.isFinite(userBonusPercent) || userBonusPercent < 0 || userBonusPercent > 100) return showToast('Persentase bonus transaksi tidak valid', true);
    if (role !== 'harian' && role !== 'admin' && (!Number.isFinite(userClosingPerMinute) || userClosingPerMinute < 0)) return showToast('Bonus closing per menit tidak valid', true);
    setLoading(true);
    try {
      const ref = doc(db, 'users', username);
      const snap = await getDocFreshSafe('cek user sebelum simpan', ref);
      const existing = snap && snap.exists() ? snap.data() : null;
      const wasInactive = existing && !isUserActive(existing);
      if (existing && isBlockedStaffDailyRoleSwitch(existing.role || 'staff', role)) {
        showToast('Role staff dan karyawan harian tidak bisa saling diubah. Buat user baru agar bonus tidak bercampur.', true);
        setLoading(false);
        return;
      }
      if ((role === 'staff' || role === 'harian') && bonusPercentRaw === '') {
        showToast('Isi bonus transaksi (%) untuk user ini.', true);
        setLoading(false);
        return;
      }
      await setDoc(ref, {
        username,
        name,
        pin,
        role,
        transactionBonusRate: role === 'admin' ? 0 : userBonusPercent / 100,
        transactionBonusPercent: role === 'admin' ? 0 : userBonusPercent,
        closingBonusPerMinute: (role === 'admin' || role === 'harian') ? 0 : userClosingPerMinute,
        dailyBonusRate: role === 'harian' ? userBonusPercent / 100 : 0,
        dailyBonusPercent: role === 'harian' ? userBonusPercent : 0,
        isDummy: dummyMode,
        trialMode: dummyMode,
        accountType: dummyMode ? 'dummy' : 'normal',
        excludeFromReports: dummyMode,
        trialTargetAmount: dummyMode ? Number(existing?.trialTargetAmount || 10000) : 0,
        trialBonusAmount: dummyMode ? Number(existing?.trialBonusAmount || 1000) : 0,
        bonusControlVersion: 3,
        active: true,
        deleted: false,
        deletedAt: null,
        deletedAtMs: null,
        deletedBy: null,
        deletedByName: null,
        restoredAt: wasInactive ? serverTimestamp() : (existing?.restoredAt || null),
        restoredAtMs: wasInactive ? Date.now() : (existing?.restoredAtMs || null),
        restoredBy: wasInactive ? currentUser.username : (existing?.restoredBy || null),
        restoredByName: wasInactive ? (currentUser.name || currentUser.username) : (existing?.restoredByName || null),
        updatedAt: serverTimestamp(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name || currentUser.username,
        createdAt: existing?.createdAt || serverTimestamp()
      }, { merge: true });
      await logAudit('user_upsert', { username, role, dummyMode, existed: !!existing, restored: !!wasInactive, transactionBonusPercent: role === 'admin' ? 0 : userBonusPercent, closingBonusPerMinute: (role === 'admin' || role === 'harian') ? 0 : userClosingPerMinute });
      showToast(existing ? '✓ User diperbarui' : '✓ User ditambahkan');
      selectedUserFilter = username;
      clearAdminUserForm();
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan user', true);
    }
    setLoading(false);
  }

  async function deleteAdminUser() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const username = sanitizeUsername($('admin-user-select')?.value || $('admin-user-username')?.value);
    if (!username) return showToast('Pilih user dulu!', true);
    if (sanitizeUsername(currentUser?.username) === username) return showToast('Tidak bisa nonaktifkan akun admin yang sedang dipakai!', true);
    const user = getUserByUsername(username);
    if (!confirm(`Nonaktifkan user ${user?.name || username} (@${username})? Data transaksi dan absensi tetap disimpan.`)) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'users', username), {
        active: false,
        deleted: true,
        deletedAt: serverTimestamp(),
        deletedAtMs: Date.now(),
        deletedBy: currentUser.username
      }, { merge: true });
      if (selectedUserFilter === username) selectedUserFilter = 'all';
      clearAdminUserForm();
      await logAudit('user_soft_delete', { username });
      showToast(`✓ User ${username} dinonaktifkan`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal nonaktifkan user', true);
    }
    setLoading(false);
  }

  async function restoreAdminUser(usernameRaw = '') {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const username = sanitizeUsername(usernameRaw || $('admin-user-select')?.value || $('admin-user-username')?.value);
    if (!username) return showToast('Pilih user dulu!', true);
    const user = getUserByUsername(username);
    if (!user) return showToast('User tidak ditemukan!', true);
    if (isUserActive(user)) return showToast('User sudah aktif');
    setLoading(true);
    try {
      await setDoc(doc(db, 'users', username), {
        active: true,
        deleted: false,
        deletedAt: null,
        deletedAtMs: null,
        deletedBy: null,
        deletedByName: null,
        restoredAt: serverTimestamp(),
        restoredAtMs: Date.now(),
        restoredBy: currentUser.username,
        restoredByName: currentUser.name || currentUser.username,
        updatedAt: serverTimestamp(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name || currentUser.username
      }, { merge: true });
      selectedUserFilter = username;
      clearAdminUserForm();
      await logAudit('user_restore', { username });
      showToast(`✓ User ${username} diaktifkan kembali`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal aktifkan user', true);
    }
    setLoading(false);
  }

  async function hardDeleteAdminUser() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const username = sanitizeUsername($('admin-user-select')?.value || $('admin-user-username')?.value);
    if (!username) return showToast('Pilih user dulu!', true);
    if (sanitizeUsername(currentUser?.username) === username) return showToast('Tidak bisa hapus permanen akun yang sedang dipakai!', true);
    const user = getUserByUsername(username);
    if (!user) return showToast('User tidak ditemukan!', true);
    if (isUserActive(user)) return showToast('Nonaktifkan user dulu sebelum hapus permanen!', true);
    const pin = await askPin(`HAPUS PERMANEN user ${user?.name || username} (@${username})?\nKetik PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm('Akun user akan dihapus permanen. Data transaksi dan absensi user tetap disimpan untuk arsip. Lanjutkan?')) return;
    setLoading(true);
    try {
      await deleteDoc(doc(db, 'users', username));
      if (selectedUserFilter === username) selectedUserFilter = 'all';
      clearAdminUserForm();
      await logAudit('user_hard_delete', { username });
      showToast(`✓ User ${username} dihapus permanen`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus permanen user', true);
    }
    setLoading(false);
  }


  function userDeviceExempt(user) {
    return isDailyRole(normalizeRole(user?.role || 'staff'));
  }
  function userDeviceLocked(user) {
    if (userDeviceExempt(user)) return false;
    return !!String(user?.deviceId || '').trim();
  }
  function shortDeviceId(id) {
    const s = String(id || '').trim();
    return s ? s.slice(-6).toUpperCase() : '-';
  }
  function userDeviceStatusText(user) {
    if (userDeviceExempt(user)) return 'Bebas login dimana saja';
    return userDeviceLocked(user) ? `Terkunci · ${shortDeviceId(user.deviceId)}` : 'Belum terkunci';
  }
  function renderDeviceLockRows() {
    const users = sortUsers(cachedUsers || []).filter(u => normalizeRole(u.role || 'staff') !== 'admin');
    const lockableUsers = users.filter(u => !userDeviceExempt(u));
    const lockedCount = lockableUsers.filter(userDeviceLocked).length;
    return `<div style="border:1px solid var(--border);border-radius:14px;background:var(--surface);padding:11px;margin-top:2px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:9px">
        <div style="min-width:0"><div style="font-size:12.5px;font-weight:900"><i class="fas fa-mobile-screen-button"></i> Kunci Perangkat User</div><div style="font-size:10.5px;color:var(--text-soft);margin-top:2px">Staff dikunci 1 perangkat. Karyawan harian bebas login di perangkat mana saja.</div></div>
        <span class="status-pill ${lockedCount ? 'status-ok' : 'status-warn'}" style="white-space:nowrap">${lockedCount}/${lockableUsers.length} staff lock</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:7px;max-height:240px;overflow:auto;padding-right:2px">
        ${users.length ? users.map(u => {
          const username = sanitizeUsername(u.username || '');
          const exempt = userDeviceExempt(u);
          const locked = userDeviceLocked(u);
          const statusColor = exempt ? 'var(--accent)' : (locked ? 'var(--green)' : 'var(--amber)');
          const statusIcon = exempt ? 'fa-person-walking-arrow-right' : (locked ? 'fa-lock' : 'fa-unlock');
          return `<div style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:12px;background:var(--bg2)">
            <div style="min-width:0;flex:1"><div style="font-size:12px;font-weight:850;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(u.name || username)} <span style="color:var(--text-soft)">@${escapeHtml(username)}</span></div><div style="font-size:10px;color:${statusColor};margin-top:3px"><i class="fas ${statusIcon}"></i> ${escapeHtml(userDeviceStatusText(u))}</div></div>
            <button onclick="resetUserDevice('${escapeHtml(username)}')" class="btn ${locked ? 'btn-danger' : 'btn-glass'}" style="padding:8px 10px;font-size:10.5px;border-radius:11px;white-space:nowrap" ${locked ? '' : 'disabled'}><i class="fas ${exempt ? 'fa-check' : 'fa-rotate-left'}"></i> ${exempt ? 'Bebas' : 'Reset'}</button>
          </div>`;
        }).join('') : `<div style="font-size:11px;color:var(--text-soft);padding:6px 0">Belum ada user staff/harian.</div>`}
      </div>
    </div>`;
  }

  async function resetUserDevice(username) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const safeUsername = sanitizeUsername(username || $('admin-user-select')?.value || $('admin-user-username')?.value);
    if (!safeUsername) return showToast('Pilih user dulu!', true);
    const user = getUserByUsername(safeUsername);
    if (!user) return showToast('User tidak ditemukan!', true);
    if (userDeviceExempt(user)) return showToast('Karyawan harian bebas login di perangkat mana saja');
    if (!userDeviceLocked(user)) return showToast('Device user ini belum terkunci');
    const pin = await askPin(`Reset device untuk ${user.name || safeUsername} (@${safeUsername})?

Setelah direset, session staff di HP lama akan otomatis keluar, lalu staff bisa login ulang di perangkat barunya.

Masukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin, 'PIN admin salah!'))) return;
    setLoading(true);
    try {
      const payload = {
        deviceId: '',
        deviceLocked: false,
        deviceUser: '',
        deviceApp: '',
        deviceLabel: '',
        deviceUserAgent: '',
        devicePlatform: '',
        deviceLockedAt: null,
        deviceLockedAtMs: 0,
        deviceLastLoginAt: null,
        deviceLastLoginAtMs: 0,
        deviceResetAt: serverTimestamp(),
        deviceResetAtMs: Date.now(),
        deviceResetBy: currentUser.username,
        deviceResetByName: currentUser.name || currentUser.username
      };
      await setDoc(doc(db, 'users', safeUsername), payload, { merge: true });
      upsertCachedUserFromServer(safeUsername, { ...user, ...payload, username: safeUsername });
      await logAudit('user_device_reset', { username: safeUsername, name: user.name || safeUsername, oldDevice: shortDeviceId(user.deviceId) });
      showToast('✓ Device user direset');
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal reset device user', true);
    }
    setLoading(false);
  }

  function serializeTimestamp(value) {
    if (!value) return null;
    if (value.toDate) return value.toDate().toISOString();
    if (typeof value === 'string') return value;
    if (typeof value === 'number' && Number.isFinite(value)) return new Date(value).toISOString();
    if (value && typeof value === 'object' && Number.isFinite(Number(value.seconds))) {
      return new Date(Number(value.seconds) * 1000 + Math.floor(Number(value.nanoseconds || 0) / 1000000)).toISOString();
    }
    return null;
  }

  function serializeBackupValue(value) {
    if (value === undefined) return null;
    if (value === null) return null;
    if (value?.toDate || (value && typeof value === 'object' && Number.isFinite(Number(value.seconds)))) return serializeTimestamp(value);
    if (value instanceof Date) return value.toISOString();
    if (Array.isArray(value)) return value.map(serializeBackupValue);
    if (value && typeof value === 'object') {
      const out = {};
      Object.keys(value).forEach(k => { out[k] = serializeBackupValue(value[k]); });
      return out;
    }
    return value;
  }

  function serializeBackupRecord(record = {}) {
    return serializeBackupValue(record) || {};
  }

  function backupSheetRows(rows = []) {
    return (rows || []).map(row => {
      const clean = serializeBackupRecord(row);
      const out = {};
      Object.entries(clean || {}).forEach(([key, value]) => {
        out[key] = value && typeof value === 'object' ? JSON.stringify(value) : value;
      });
      return out;
    });
  }

  function parseBackupCellValue(value) {
    if (typeof value !== 'string') return value;
    const clean = value.trim();
    if (!clean) return value;
    if (!/^[\[{]/.test(clean)) return value;
    try { return JSON.parse(clean); } catch (_) { return value; }
  }

  function parseBackupSheetRows(rows = []) {
    return (rows || []).map(row => {
      const out = {};
      Object.entries(row || {}).forEach(([key, value]) => {
        if (value === undefined || value === '') return;
        out[key] = parseBackupCellValue(value);
      });
      return out;
    }).filter(row => Object.keys(row).length);
  }

  function cleanFirestorePayload(obj = {}) {
    const out = {};
    Object.entries(obj || {}).forEach(([k, v]) => {
      if (v === undefined) out[k] = null;
      else if (Array.isArray(v)) out[k] = v.map(x => x === undefined ? null : x);
      else if (v && typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype && !(v?.toDate) && !Number.isFinite(Number(v?.seconds))) {
        out[k] = cleanFirestorePayload(v);
      } else out[k] = v;
    });
    return out;
  }

  function isBackupDeleted(rec) {
    return rec?.deleted === true || rec?.deleted === 'true';
  }
  function findBackupClosingDoc(rows, id, type = '') {
    return (rows || []).find(c => String(c.id || '') === id || String(c.dateKey || '') === id || (type && String(c.type || '') === type)) || null;
  }
  function normalizeBackupUserRecord(u = {}) {
    const username = sanitizeUsername(u.username || u.id);
    if (!username) return null;
    const role = normalizeRole(u.role || 'staff');
    const deleted = isBackupDeleted(u) && role !== 'admin' && !ADMIN_USERNAMES.includes(username);
    return {
      ...serializeBackupRecord(u),
      id: u.id || username,
      username,
      name: String(u.name || username),
      pin: String(u.pin || ''),
      role,
      transactionBonusRate: role === 'admin' ? 0 : getUserTransactionBonusRate(u),
      transactionBonusPercent: role === 'admin' ? 0 : getUserTransactionBonusPercent(u),
      closingBonusPerMinute: role === 'admin' ? 0 : getUserClosingBonusPerMinute(u),
      dailyBonusRate: Number(u.dailyBonusRate || 0),
      dailyBonusPercent: Number(u.dailyBonusPercent || 0),
      deviceId: userDeviceLocked(u) ? String(u.deviceId || '') : '',
      deviceLocked: userDeviceLocked(u),
      deviceLabel: userDeviceLocked(u) ? String(u.deviceLabel || '') : '',
      deviceLockedAtMs: userDeviceLocked(u) ? Number(u.deviceLockedAtMs || 0) : 0,
      deviceLastLoginAtMs: Number(u.deviceLastLoginAtMs || 0),
      deviceResetAtMs: Number(u.deviceResetAtMs || 0),
      active: role === 'admin' || ADMIN_USERNAMES.includes(username) ? true : (u.active !== false && u.active !== 'false' && !deleted),
      deleted,
      createdAt: serializeTimestamp(u.createdAt) || u.createdAt || null
    };
  }
  function normalizeBackupAttendanceRecord(a = {}) {
    const id = a.id || getAttendanceDocId(a.user, a.dateKey || extractDateKey(a));
    return {
      ...serializeBackupRecord(a),
      id,
      user: sanitizeUsername(a.user || a.username || ''),
      name: String(a.name || a.user || ''),
      dateKey: String(a.dateKey || extractDateKey(a) || '').slice(0, 10),
      lat: a.lat ?? a.loc?.lat ?? null,
      lng: a.lng ?? a.loc?.lng ?? null,
      createdAt: serializeTimestamp(a.createdAt) || a.createdAt || null,
      createdAtMs: a.createdAt?.toDate ? a.createdAt.toDate().getTime() : (Number(a.createdAtMs || 0) || getRecordTimeMs(a) || Date.now()),
      deleted: isBackupDeleted(a)
    };
  }
  function normalizeBackupTransactionRecord(t = {}) {
    const payment = normalizeTransactionPaymentMethod(t.paymentMethod || t.paymentLabel || t.paymentType || t.metodePembayaran) || 'cash';
    return {
      ...serializeBackupRecord(t),
      id: t.id || '',
      user: sanitizeUsername(t.user || t.username || ''),
      name: String(t.name || t.user || ''),
      note: String(t.note || 'Transaksi'),
      amount: Number(t.amount || 0),
      paymentMethod: payment,
      paymentLabel: getTransactionPaymentInfo(payment).label,
      paymentStatus: t.paymentStatus || 'success',
      paymentCashOutType: payment === 'qris_transfer' ? 'qris' : '',
      isNonCashPayment: payment === 'qris_transfer',
      dateKey: String(t.dateKey || extractDateKey(t) || '').slice(0, 10),
      monthKey: String(t.monthKey || getTransactionMonthKey(t) || '').slice(0, 7),
      userRole: t.userRole || t.role || '',
      bonusGroup: t.bonusGroup || '',
      bonusRate: Number(t.bonusRate ?? t.transactionBonusRate ?? NaN),
      bonusPercent: Number(t.bonusPercent ?? t.transactionBonusPercent ?? NaN),
      bonusLogicVersion: Number(t.bonusLogicVersion || 1),
      createdAt: serializeTimestamp(t.createdAt) || t.createdAt || null,
      createdAtMs: t.createdAt?.toDate ? t.createdAt.toDate().getTime() : (Number(t.createdAtMs || 0) || getRecordTimeMs(t) || Date.now()),
      deleted: isBackupDeleted(t)
    };
  }
  function createBackupPayloadFromRows(rows = {}) {
    const users = (rows.users || []).map(normalizeBackupUserRecord).filter(Boolean);
    const attendance = (rows.attendance || []).map(normalizeBackupAttendanceRecord).filter(a => a.user && a.dateKey);
    const transactions = (rows.transactions || []).map(normalizeBackupTransactionRecord).filter(t => t.user);
    const closings = rows.closings || [];
    const manualBonuses = rows.manualBonuses || [];
    const unlockRequests = rows.unlockRequests || [];
    const dailyTargets = rows.dailyTargets || [];
    const targetBonusRewards = rows.targetBonusRewards || [];
    const targetNotifications = rows.targetNotifications || [];
    const targetSettings = rows.targetSettings || [];
    const adminDeviceTokens = rows.adminDeviceTokens || [];
    const bonusSettings = findBackupClosingDoc(closings, '__bonus_settings', 'bonus_settings') || cachedBonusSettings || {};
    const headerGuideNote = findBackupClosingDoc(closings, HEADER_GUIDE_NOTE_DOC_ID, 'header_guide_note') || cachedHeaderGuideNote || { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE };
    const staffDailyHomeNote = findBackupClosingDoc(closings, STAFF_DAILY_NOTE_DOC_ID, 'staff_daily_home_note') || cachedStaffDailyHomeNote || { id: STAFF_DAILY_NOTE_DOC_ID, note: DEFAULT_STAFF_DAILY_NOTE, enabled: true };
    const receiptTextSettings = findBackupClosingDoc(closings, RECEIPT_TEXT_DOC_ID, 'receipt_text_settings') || getReceiptTextSettingsSafe();
    const rismaManualClosingConfig = findBackupClosingDoc(closings, RISMA_MANUAL_CLOSING_DOC_ID, 'closing_manual_config') || cachedRismaManualClosingConfig || { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
    return {
      version: 'supabase-admin-v11-full-server-backup',
      projectId: firebaseConfig.projectId,
      exportedAt: new Date().toISOString(),
      exportedBy: currentUser?.username || 'admin',
      data: {
        users: sortUsers(users),
        attendance: sortByCreatedDesc(attendance),
        transactions: sortByCreatedDesc(transactions),
        closings: sortByCreatedDesc((closings || []).filter(isClosingDataRecord)).map(c => serializeBackupRecord(c)),
        manualBonuses: sortByCreatedDesc(manualBonuses || []).map(b => serializeBackupRecord(b)),
        unlockRequests: sortByCreatedDesc(unlockRequests || []).map(r => serializeBackupRecord(r)),
        dailyTargets: sortByCreatedDesc(dailyTargets || []).map(r => serializeBackupRecord(r)),
        targetBonusRewards: sortByCreatedDesc(targetBonusRewards || []).map(r => serializeBackupRecord(r)),
        targetNotifications: sortByCreatedDesc(targetNotifications || []).map(r => serializeBackupRecord(r)),
        targetSettings: sortByCreatedDesc(targetSettings || []).map(r => serializeBackupRecord(r)),
        adminDeviceTokens: sortByCreatedDesc(adminDeviceTokens || []).map(r => serializeBackupRecord(r)),
        bonusSettings: serializeBackupRecord({ ...(bonusSettings || {}), transactionBonusRate: Number(bonusSettings.transactionBonusRate ?? getTransactionBonusRate()), transactionBonusPercent: Number(bonusSettings.transactionBonusPercent ?? getTransactionBonusPercent()), closingBonusPerMinute: Number(bonusSettings.closingBonusPerMinute ?? getClosingBonusPerMinute()), ...getClosingDeadlineSnapshot(bonusSettings || {}) }),
        headerGuideNote: serializeBackupRecord(headerGuideNote),
        staffDailyHomeNote: serializeBackupRecord(staffDailyHomeNote),
        receiptTextSettings: serializeBackupRecord(receiptTextSettings),
        rismaManualClosingConfig: serializeBackupRecord(rismaManualClosingConfig),
        auditLogs: sortByCreatedDesc(rows.auditLogs || []).map(a => serializeBackupRecord(a))
      }
    };
  }

  function getBackupPayload() {
    return createBackupPayloadFromRows({
      users: cachedUsers || [],
      attendance: cachedAttendance || [],
      transactions: cachedTransactions || [],
      closings: cachedClosings || [],
      manualBonuses: cachedManualBonuses || [],
      unlockRequests: cachedUnlockRequests || [],
      dailyTargets: cachedDailyTarget ? [{ id: cachedDailyTarget.id || serverTargetDocId(cachedDailyTarget.dateKey), ...cachedDailyTarget }] : [],
      targetBonusRewards: [],
      targetNotifications: cachedTargetNotification ? [{ ...cachedTargetNotification }] : [],
      targetSettings: (cachedTargetSettingRows || []).length ? cachedTargetSettingRows : (cachedTargetSettings && Object.keys(cachedTargetSettings).length ? [{ id: 'daily_target', ...cachedTargetSettings }] : []),
      adminDeviceTokens: [],
      auditLogs: cachedAuditLogs || []
    });
  }

  async function fetchAllServerRowsForBackup(collectionName, pageSize = 1000) {
    if (db?.type !== 'supabase') {
      const snap = await getDocs(query(collection(db, collectionName), limit(5000)));
      return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    }
    const rows = [];
    for (let from = 0; from < 200000; from += pageSize) {
      const to = from + pageSize - 1;
      const { data, error } = await supabase.from(collectionName).select('id,data').order('id', { ascending: true }).range(from, to);
      if (error) throw error;
      const batch = (data || []).map(normalizeRow);
      rows.push(...batch);
      if (batch.length < pageSize) break;
    }
    return rows;
  }

  async function fetchOptionalServerRowsForBackup(collectionName) {
    try {
      return await fetchAllServerRowsForBackup(collectionName);
    } catch (e) {
      if (isMissingSupabaseTableError(e)) {
        console.warn(`Tabel ${collectionName} belum ada, backup dilewati`);
        return [];
      }
      throw e;
    }
  }

  async function getBackupPayloadFresh() {
    const [users, attendance, transactions, closings, manualBonuses, unlockRequests, dailyTargets, targetBonusRewards, targetNotifications, targetSettings, adminDeviceTokens, auditLogs] = await Promise.all([
      fetchAllServerRowsForBackup('users'),
      fetchAllServerRowsForBackup('attendance'),
      fetchAllServerRowsForBackup('transactions'),
      fetchAllServerRowsForBackup('closings'),
      fetchAllServerRowsForBackup('manualBonuses'),
      fetchOptionalServerRowsForBackup(STAFF_UNLOCK_TABLE),
      fetchOptionalServerRowsForBackup(SERVER_DAILY_TARGETS_TABLE),
      fetchOptionalServerRowsForBackup(SERVER_TARGET_REWARDS_TABLE),
      fetchOptionalServerRowsForBackup(SERVER_TARGET_NOTIFICATIONS_TABLE),
      fetchOptionalServerRowsForBackup(SERVER_TARGET_SETTINGS_TABLE),
      fetchOptionalServerRowsForBackup('adminDeviceTokens'),
      fetchOptionalServerRowsForBackup('audit_logs')
    ]);
    return createBackupPayloadFromRows({ users, attendance, transactions, closings, manualBonuses, unlockRequests, dailyTargets, targetBonusRewards, targetNotifications, targetSettings, adminDeviceTokens, auditLogs });
  }


  function makeBackupFilename(prefix = 'rocky-emergency-before-restore') {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    return `${prefix}-${stamp}.json`;
  }

  async function saveEmergencyBackupBeforeRestore(label = 'restore') {
    try {
      let payload;
      try {
        payload = await getBackupPayloadFresh();
      } catch (freshError) {
        console.warn('Backup lengkap gagal, pakai cache sementara:', freshError?.message || freshError);
        payload = getBackupPayload();
        payload.backupSource = 'cache-fallback';
      }
      payload.version = `${payload.version || 'supabase-admin-backup'}-emergency-before-${label}`;
      payload.emergencyBackup = true;
      payload.reason = `Dibuat otomatis sebelum proses ${label}`;
      const filename = makeBackupFilename(`rocky-emergency-before-${label}`);
      downloadTextFile(JSON.stringify(payload, null, 2), filename, 'application/json;charset=utf-8');
      return filename;
    } catch (e) {
      console.error('Gagal membuat emergency backup sebelum restore:', e);
      return '';
    }
  }

  function isRestoreBackupShapeSafe(backup) {
    const data = backup?.data || {};
    const counts = ['users','attendance','transactions','closings','manualBonuses','unlockRequests','dailyTargets','targetBonusRewards','targetNotifications','targetSettings','adminDeviceTokens','auditLogs']
      .reduce((sum, key) => sum + (Array.isArray(data[key]) ? data[key].length : 0), 0);
    const hasSettings = !!(data.bonusSettings || data.headerGuideNote || data.staffDailyHomeNote || data.receiptTextSettings || data.rismaManualClosingConfig || data.targetSettings);
    return counts > 0 || hasSettings;
  }

  function getRestoreBackupSummaryText(backup, kind = 'backup') {
    const data = backup?.data || {};
    const count = (key) => Array.isArray(data[key]) ? data[key].length : 0;
    return [
      `File ${kind} akan di-restore dengan MODE AMAN / MERGE.`,
      '',
      `User: ${count('users')}`,
      `Absen: ${count('attendance')}`,
      `Transaksi: ${count('transactions')}`,
      `Closing: ${count('closings')}`,
      `Bonus manual: ${count('manualBonuses')}`,
      `Buka fitur: ${count('unlockRequests')}`,
      `Target harian: ${count('dailyTargets')}`,
      `Reward target: ${count('targetBonusRewards')}`,
      `Notifikasi target: ${count('targetNotifications')}`,
      `Setting target: ${count('targetSettings')}`,
      `Token notifikasi: ${count('adminDeviceTokens')}`,
      '',
      'Data yang sudah ada dan tidak ada di backup TIDAK akan dihapus otomatis.',
      'Aplikasi juga membuat backup darurat sebelum restore.'
    ].join('\n');
  }

  function getAndroidStorageBridge() {
    const bridges = [window.AndroidStorage, window.RockyStorage, window.RockyBridge, window.Android, window.NativeBridge];
    return bridges.find(b => b && typeof b.saveFileToDownloads === 'function') || null;
  }

  function textToBase64Utf8(text) {
    const input = String(text ?? '');
    try {
      const bytes = new TextEncoder().encode(input);
      let binary = '';
      const chunkSize = 0x8000;
      for (let i = 0; i < bytes.length; i += chunkSize) {
        binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
      }
      return btoa(binary);
    } catch (e) {
      return btoa(unescape(encodeURIComponent(input)));
    }
  }

  function saveBase64ToAndroidDownloads(filename, mimeType, base64Data) {
    const bridge = getAndroidStorageBridge();
    if (!bridge) return false;
    const safeFilename = String(filename || 'backup.txt');
    const safeMime = String(mimeType || 'application/octet-stream');
    const data = String(base64Data || '');
    try {
      // Disamakan dengan AdminRocky_APK yang backup-nya sudah terbukti muncul di File Manager:
      // panggil AndroidStorage.saveFileToDownloads langsung.
      if (typeof bridge.saveFileToDownloads === 'function') {
        const saved = bridge.saveFileToDownloads(safeFilename, safeMime, data);
        if (!(saved === false || String(saved) === 'false')) return true;
      }

      // Cadangan untuk file besar kalau perangkat/WebView butuh mode potongan.
      if (typeof bridge.beginSaveToDownloads === 'function' && typeof bridge.appendSaveChunk === 'function' && typeof bridge.finishSaveToDownloads === 'function') {
        const sessionId = String(bridge.beginSaveToDownloads(safeFilename, safeMime) || '');
        if (!sessionId) return false;
        const chunkSize = 64 * 1024;
        for (let i = 0; i < data.length; i += chunkSize) {
          const ok = bridge.appendSaveChunk(sessionId, data.slice(i, i + chunkSize));
          if (ok === false || String(ok) === 'false') {
            if (typeof bridge.cancelSaveToDownloads === 'function') bridge.cancelSaveToDownloads(sessionId);
            return false;
          }
        }
        const finished = bridge.finishSaveToDownloads(sessionId);
        return !(finished === false || String(finished) === 'false');
      }
      return false;
    } catch (e) {
      console.warn('Android native save gagal, fallback browser download:', e);
      return false;
    }
  }

  function downloadTextFile(content, filename, mimeType = 'text/plain;charset=utf-8') {
    if (saveBase64ToAndroidDownloads(filename, mimeType, textToBase64Utf8(content))) return;
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      try { document.body.removeChild(a); } catch (_) {}
      try { URL.revokeObjectURL(url); } catch (_) {}
    }, 1200);
  }

  function csvEscape(value) {
    const s = String(value ?? '');
    if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
    return s;
  }

  function toCsv(rows, headers) {
    const lines = [headers.join(',')];
    for (const row of rows) lines.push(headers.map(h => csvEscape(row[h])).join(','));
    return lines.join('\n');
  }

  function parseCsv(text) {
    const rows = [];
    let row = [], value = '', inQuotes = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      const next = text[i + 1];
      if (inQuotes) {
        if (c === '"' && next === '"') { value += '"'; i++; }
        else if (c === '"') inQuotes = false;
        else value += c;
      } else {
        if (c === '"') inQuotes = true;
        else if (c === ',') { row.push(value); value = ''; }
        else if (c === '\n') { row.push(value); rows.push(row); row = []; value = ''; }
        else if (c === '\r') { }
        else value += c;
      }
    }
    if (value.length || row.length) { row.push(value); rows.push(row); }
    if (!rows.length) return [];
    const headers = rows[0].map(x => String(x || '').trim());
    return rows.slice(1).filter(r => r.some(cell => String(cell || '').trim() !== '')).map(r => {
      const obj = {};
      headers.forEach((h, idx) => obj[h] = r[idx] ?? '');
      return obj;
    });
  }

  function normalizeBackupShape(raw) {
    if (!raw) throw new Error('Backup kosong');
    if (raw.data && typeof raw.data === 'object') return raw;
    return {
      version: raw.version || 'legacy-import',
      exportedAt: raw.exportedAt || new Date().toISOString(),
      data: {
        users: Array.isArray(raw.users) ? raw.users : [],
        attendance: Array.isArray(raw.attendance) ? raw.attendance : [],
        transactions: Array.isArray(raw.transactions) ? raw.transactions : [],
        closings: Array.isArray(raw.closings) ? raw.closings : [],
        manualBonuses: Array.isArray(raw.manualBonuses) ? raw.manualBonuses : [],
        unlockRequests: Array.isArray(raw.unlockRequests) ? raw.unlockRequests : [],
        dailyTargets: Array.isArray(raw.dailyTargets) ? raw.dailyTargets : [],
        targetBonusRewards: Array.isArray(raw.targetBonusRewards) ? raw.targetBonusRewards : [],
        targetNotifications: Array.isArray(raw.targetNotifications) ? raw.targetNotifications : [],
        targetSettings: Array.isArray(raw.targetSettings) ? raw.targetSettings : (raw.targetSettings ? [raw.targetSettings] : []),
        adminDeviceTokens: Array.isArray(raw.adminDeviceTokens) ? raw.adminDeviceTokens : [],
        bonusSettings: raw.bonusSettings || null,
        headerGuideNote: raw.headerGuideNote || raw.headerNote || null,
        staffDailyHomeNote: raw.staffDailyHomeNote || raw.staffDailyNote || null,
        receiptTextSettings: raw.receiptTextSettings || raw.receiptSettings || null,
        rismaManualClosingConfig: raw.rismaManualClosingConfig || null,
        auditLogs: Array.isArray(raw.auditLogs) ? raw.auditLogs : []
      }
    };
  }

  function parseBackupNumber(value, fallback = null) {
    if (value === undefined || value === null) return fallback;
    if (typeof value === 'string') {
      const cleaned = value.trim();
      if (cleaned === '' || cleaned.toLowerCase() === 'nan' || cleaned.toLowerCase() === 'null' || cleaned.toLowerCase() === 'undefined') return fallback;
      const normalized = cleaned.replace(/%/g, '').replace(/,/g, '.');
      const n = Number(normalized);
      return Number.isFinite(n) ? n : fallback;
    }
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  }

  function parseBackupPercent(value, fallback = null) {
    const n = parseBackupNumber(value, fallback);
    return n === null || n === undefined ? fallback : n;
  }

  function resolveBackupTransactionRate(rawUser = {}, role = 'staff') {
    const explicitRate = parseBackupNumber(rawUser.transactionBonusRate, null);
    if (explicitRate !== null && explicitRate >= 0) return explicitRate;
    const explicitPercent = parseBackupPercent(rawUser.transactionBonusPercent ?? rawUser.bonusPercent ?? rawUser.bonus_transaksi, null);
    if (explicitPercent !== null && explicitPercent >= 0) return explicitPercent / 100;
    if (isDailyRole(role)) {
      const dailyRate = parseBackupNumber(rawUser.dailyBonusRate, null);
      if (dailyRate !== null && dailyRate >= 0) return dailyRate;
      const dailyPercent = parseBackupPercent(rawUser.dailyBonusPercent ?? rawUser.daily_percent ?? rawUser.persen_harian, null);
      if (dailyPercent !== null && dailyPercent >= 0) return dailyPercent / 100;
    }
    return getTransactionBonusRate();
  }

  function resolveBackupTransactionPercent(rawUser = {}, role = 'staff') {
    const explicitPercent = parseBackupPercent(rawUser.transactionBonusPercent ?? rawUser.bonusPercent ?? rawUser.bonus_transaksi, null);
    if (explicitPercent !== null && explicitPercent >= 0) return explicitPercent;
    const explicitRate = parseBackupNumber(rawUser.transactionBonusRate, null);
    if (explicitRate !== null && explicitRate >= 0) return Number((explicitRate * 100).toFixed(3));
    if (isDailyRole(role)) {
      const dailyPercent = parseBackupPercent(rawUser.dailyBonusPercent ?? rawUser.daily_percent ?? rawUser.persen_harian, null);
      if (dailyPercent !== null && dailyPercent >= 0) return dailyPercent;
      const dailyRate = parseBackupNumber(rawUser.dailyBonusRate, null);
      if (dailyRate !== null && dailyRate >= 0) return Number((dailyRate * 100).toFixed(3));
    }
    return getTransactionBonusPercent();
  }

  function resolveBackupClosingBonusPerMinute(rawUser = {}, role = 'staff') {
    if (isDailyRole(role) || role === 'admin') return 0;
    const n = parseBackupNumber(rawUser.closingBonusPerMinute ?? rawUser.bonus_closing, null);
    return n !== null && n >= 0 ? n : getClosingBonusPerMinute();
  }

  function readBackupTransactionBonusRate(row = {}, fallbackRate = null) {
    const n = parseBackupNumber(row.bonusRate ?? row.transactionBonusRate, null);
    return n !== null && n >= 0 ? n : fallbackRate;
  }

  function readBackupTransactionBonusPercent(row = {}, fallbackPercent = null) {
    const n = parseBackupNumber(row.bonusPercent ?? row.transactionBonusPercent, null);
    return n !== null && n >= 0 ? n : fallbackPercent;
  }

  function parseBackupBoolean(value, fallback = true) {
    if (value === undefined || value === null || value === '') return fallback;
    if (typeof value === 'boolean') return value;
    const s = String(value).trim().toLowerCase();
    if (['false','0','no','tidak','off','mati'].includes(s)) return false;
    if (['true','1','yes','ya','on','hidup'].includes(s)) return true;
    return !!value;
  }

  function parseBackupJsonObject(value, fallback = {}) {
    if (!value) return fallback;
    if (typeof value === 'object') return value;
    try {
      const parsed = JSON.parse(String(value));
      return parsed && typeof parsed === 'object' ? parsed : fallback;
    } catch (_) {
      return fallback;
    }
  }

  function normalizeBackupReceiptSettings(raw) {
    if (!raw || typeof raw !== 'object') return null;
    return normalizeReceiptTextSettings({
      ...raw,
      id: RECEIPT_TEXT_DOC_ID,
      storeName: raw.storeName ?? raw.namaToko ?? raw.header ?? DEFAULT_RECEIPT_TEXT_SETTINGS.storeName,
      storeSubtext: raw.storeSubtext ?? raw.subtext ?? '',
      dailyTitle: raw.dailyTitle ?? raw.judulHarian ?? DEFAULT_RECEIPT_TEXT_SETTINGS.dailyTitle,
      dateLabel: raw.dateLabel ?? raw.labelTanggal ?? DEFAULT_RECEIPT_TEXT_SETTINGS.dateLabel,
      cashierLabel: raw.cashierLabel ?? raw.labelKasir ?? DEFAULT_RECEIPT_TEXT_SETTINGS.cashierLabel,
      productLabel: raw.productLabel ?? raw.labelProduk ?? DEFAULT_RECEIPT_TEXT_SETTINGS.productLabel,
      totalLabel: raw.totalLabel ?? raw.labelTotal ?? DEFAULT_RECEIPT_TEXT_SETTINGS.totalLabel,
      countLabel: raw.countLabel ?? raw.labelJumlah ?? DEFAULT_RECEIPT_TEXT_SETTINGS.countLabel,
      footerText: raw.footerText ?? raw.footer ?? DEFAULT_RECEIPT_TEXT_SETTINGS.footerText,
      bottomFeedLines: raw.bottomFeedLines ?? raw.feedLines ?? DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines
    });
  }



  function getRestoreProFileKind(file) {
    if (!file) return '';
    const name = String(file.name || '').toLowerCase();
    if (name.endsWith('.json') || file.type === 'application/json') return 'json';
    if (name.endsWith('.xlsx') || name.endsWith('.xls') || String(file.type || '').includes('spreadsheet') || String(file.type || '').includes('excel')) return 'excel';
    return '';
  }

  function updateRestoreProStatus() {
    const el = $('restore-pro-status');
    const btn = $('restore-pro-run-btn');
    if (!el || !btn) return;
    if (!selectedRestoreProFile) {
      el.innerHTML = `<span style="color:var(--text-soft)"><i class="fas fa-circle-info"></i> Belum ada file dipilih</span>`;
      btn.disabled = true;
      return;
    }
    const kind = getRestoreProFileKind(selectedRestoreProFile);
    const sizeKb = Math.max(1, Math.round(selectedRestoreProFile.size / 1024));
    if (!kind) {
      el.innerHTML = `<span style="color:var(--red)"><i class="fas fa-triangle-exclamation"></i> Format tidak didukung: ${escapeHtml(selectedRestoreProFile.name)}</span>`;
      btn.disabled = true;
      return;
    }
    el.innerHTML = `<span style="color:var(--green)"><i class="fas fa-circle-check"></i> ${escapeHtml(selectedRestoreProFile.name)} · ${kind.toUpperCase()} · ${sizeKb} KB</span>`;
    btn.disabled = false;
  }

  function handleRestoreProFile(event) {
    selectedRestoreProFile = event?.target?.files?.[0] || null;
    updateRestoreProStatus();
    if (selectedRestoreProFile) showToast(`✓ File siap: ${selectedRestoreProFile.name}`);
  }

  function clearRestoreProFile() {
    selectedRestoreProFile = null;
    if ($('restore-pro-file')) $('restore-pro-file').value = '';
    updateRestoreProStatus();
    showToast('File restore dibersihkan');
  }

  async function restoreProFromFile() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const file = selectedRestoreProFile || $('restore-pro-file')?.files?.[0];
    if (!file) return showToast('Pilih file backup dulu!', true);
    const kind = getRestoreProFileKind(file);
    if (!kind) return showToast('Format harus JSON, XLS, atau XLSX!', true);
    setLoading(true);
    try {
      let backup;
      if (kind === 'json') {
        const raw = await file.text();
        backup = normalizeBackupShape(JSON.parse(raw));
      } else {
        const XLSX = await ensureXlsxReady();
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const findSheetName = (candidates) => candidates.find(n => workbook.Sheets[n]) || candidates.find(n => workbook.Sheets[n.toLowerCase()]) || candidates.find(n => workbook.Sheets[n.toUpperCase()]) || '';
        const pickSheetRows = (names) => {
          const name = findSheetName(names);
          if (!name || !workbook.Sheets[name]) return [];
          return XLSX.utils.sheet_to_json(workbook.Sheets[name], { defval: '' });
        };
        backup = {
          version: 'restore-pro-excel-import',
          exportedAt: new Date().toISOString(),
          data: {
            users: pickSheetRows(['users','user','Users','User']).map(u => ({
              username: sanitizeUsername(u.username || u.user || u.Username || u.USERNAME),
              name: String(u.name || u.nama || u.Name || u.Nama || u.username || u.user || ''),
              pin: String(u.pin || u.PIN || u.password || ''),
              role: String(u.role || u.Role || 'staff'),
              transactionBonusPercent: Number(u.transactionBonusPercent || u.bonus_transaksi || u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0),
              transactionBonusRate: Number(u.transactionBonusRate || 0) || (Number(u.transactionBonusPercent || u.bonus_transaksi || u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0) / 100),
              closingBonusPerMinute: isDailyRole(String(u.role || u.Role || 'staff')) ? 0 : Number(u.closingBonusPerMinute || u.bonus_closing || 0),
              dailyBonusPercent: Number(u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0),
              dailyBonusRate: Number(u.dailyBonusRate || 0) || (Number(u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0) / 100),
              active: String(u.active ?? u.Active ?? 'true') !== 'false',
              deleted: parseBackupBoolean(u.deleted ?? u.Deleted, false),
              createdAt: u.createdAt || u.created_at || null
            })).filter(u => u.username),
            attendance: pickSheetRows(['attendance','absensi','absen','Attendance']).map(a => ({
              user: sanitizeUsername(a.user || a.username || a.User || a.Username),
              name: String(a.name || a.nama || a.Name || a.user || a.username || ''),
              dateKey: String(a.dateKey || a.date || a.tanggal || a.Date || '').slice(0, 10),
              lat: (a.lat ?? a.latitude ?? '') === '' ? null : Number(a.lat ?? a.latitude),
              lng: (a.lng ?? a.longitude ?? '') === '' ? null : Number(a.lng ?? a.longitude),
              createdAt: a.createdAt || a.time || a.waktu || null,
              createdAtMs: Number(a.createdAtMs || 0),
              deleted: parseBackupBoolean(a.deleted ?? a.Deleted, false),
              deletedAtMs: Number(a.deletedAtMs || 0),
              deletedBy: String(a.deletedBy || ''),
              deletedByName: String(a.deletedByName || '')
            })).filter(a => a.user),
            transactions: pickSheetRows(['transactions','transaction','transaksi','Transactions']).map(t => ({
              id: String(t.id || ''),
              user: sanitizeUsername(t.user || t.username || t.User || t.Username),
              name: String(t.name || t.nama || t.Name || t.user || t.username || ''),
              note: String(t.note || t.item || t.keterangan || t.barang || 'Transaksi'),
              amount: Number(t.amount || t.harga || t.nominal || t.total || 0),
              paymentMethod: normalizeTransactionPaymentMethod(t.paymentMethod || t.payment_method || t.paymentLabel || t.payment_label || t.metodePembayaran || t.metode_pembayaran) || 'cash',
              paymentLabel: getTransactionPaymentInfo(normalizeTransactionPaymentMethod(t.paymentMethod || t.payment_method || t.paymentLabel || t.payment_label || t.metodePembayaran || t.metode_pembayaran) || 'cash').label,
              dateKey: String(t.dateKey || t.date || t.tanggal || '').slice(0, 10),
              monthKey: String(t.monthKey || '').slice(0, 7),
              userRole: (t.userRole || t.role || t.Role) ? normalizeRole(t.userRole || t.role || t.Role) : '',
              bonusGroup: sanitizeUsername(t.bonusGroup || t.bonus_type || t.bonusType || t.role || t.userRole || ''),
              bonusRate: readBackupTransactionBonusRate(t, NaN),
              bonusPercent: readBackupTransactionBonusPercent(t, NaN),
              bonusLogicVersion: Number(t.bonusLogicVersion || 3),
              createdAt: t.createdAt || t.time || t.waktu || null,
              createdAtMs: Number(t.createdAtMs || 0),
              deleted: parseBackupBoolean(t.deleted ?? t.Deleted, false),
              deletedAtMs: Number(t.deletedAtMs || 0),
              deletedBy: String(t.deletedBy || ''),
              deletedByName: String(t.deletedByName || '')
            })).filter(t => t.user),
            closings: pickSheetRows(['closings','closing','Closing','riwayat_closing']).map(c => ({
              id: String(c.id || ''),
              dateKey: String(c.dateKey || c.date || c.tanggal || '').slice(0, 10),
              monthKey: String(c.monthKey || '').slice(0, 7),
              user: sanitizeUsername(c.user || c.username || ''),
              name: String(c.name || c.nama || c.user || ''),
              scope: String(c.scope || (c.user || c.username ? 'user' : 'global')),
              closed: String(c.closed ?? 'true') !== 'false',
              canceled: String(c.canceled ?? 'false') === 'true',
              closingTime: String(c.closingTime || c.jam || ''),
              actualClosingTime: String(c.actualClosingTime || ''),
              manualClosingTime: String(c.manualClosingTime || ''),
              deadline: String(c.deadline || c.deadlineTime || c.closingDeadlineTime || ''),
              deadlineTime: getClosingDeadlineTimeLabel(c),
              deadlineHour: getClosingDeadlineParts(c).hour,
              deadlineMinute: getClosingDeadlineParts(c).minute,
              deadlineMinutes: getClosingDeadlineMinutes(c),
              closingDeadlineTime: getClosingDeadlineTimeLabel(c),
              delayMinutes: Number(c.delayMinutes || c.telat || 0),
              totalBonus: Number(c.totalBonus || c.bonus_closing || 0),
              bonusPerUser: Number(c.bonusPerUser || 0),
              bonusByUser: parseBackupJsonObject(c.bonusByUser, {}),
              bonusPerMinuteByUser: parseBackupJsonObject(c.bonusPerMinuteByUser, {}),
              canceledUsers: parseBackupJsonObject(c.canceledUsers, {}),
              closedAtMs: Number(c.closedAtMs || 0),
              closedBy: String(c.closedBy || ''),
              closedByName: String(c.closedByName || '')
            })).filter(c => c.dateKey || c.id),
            manualBonuses: pickSheetRows(['manualBonuses','manual_bonus','Bonus Manual','bonus_manual']).map(b => ({
              id: String(b.id || ''),
              user: sanitizeUsername(b.user || b.username || ''),
              name: String(b.name || b.nama || b.user || ''),
              userRole: (b.userRole || b.role || b.Role) ? normalizeRole(b.userRole || b.role || b.Role) : '',
              role: (b.role || b.userRole || b.Role) ? normalizeRole(b.role || b.userRole || b.Role) : '',
              bonusGroup: sanitizeUsername(b.bonusGroup || b.bonus_type || b.bonusType || b.role || b.userRole || ''),
              amount: Number(b.amount || b.nominal || 0),
              note: String(b.note || b.keterangan || b.reason || 'Bonus manual'),
              dateKey: String(b.dateKey || b.date || b.tanggal || '').slice(0, 10),
              monthKey: String(b.monthKey || '').slice(0, 7),
              type: String(b.type || ''),
              action: String(b.action || ''),
              createdBy: String(b.createdBy || ''),
              createdByName: String(b.createdByName || ''),
              createdAtMs: Number(b.createdAtMs || 0),
              deleted: parseBackupBoolean(b.deleted ?? b.Deleted, false),
              deletedAtMs: Number(b.deletedAtMs || 0),
              deletedBy: String(b.deletedBy || ''),
              deletedByName: String(b.deletedByName || '')
            })).filter(b => b.user),
            unlockRequests: parseBackupSheetRows(pickSheetRows(['unlockRequests','staff_leave_requests','buka_fitur','Buka Fitur'])),
            dailyTargets: parseBackupSheetRows(pickSheetRows(['dailyTargets','daily_targets','target_harian','Target Harian'])),
            targetBonusRewards: parseBackupSheetRows(pickSheetRows(['targetBonusRewards','target_bonus_rewards','reward_target','Reward Target'])),
            targetNotifications: parseBackupSheetRows(pickSheetRows(['targetNotifications','target_notifications','notif_target','Notifikasi Target'])),
            targetSettings: parseBackupSheetRows(pickSheetRows(['targetSettings','target_settings','setting_target','Setting Target'])),
            adminDeviceTokens: parseBackupSheetRows(pickSheetRows(['adminDeviceTokens','admin_device_tokens','token_notifikasi','Token Notifikasi'])),
            bonusSettings: (pickSheetRows(['bonusSettings','bonus_settings','setting_bonus'])[0] || null),
            headerGuideNote: (() => {
              const row = pickSheetRows(['headerGuideNote','header_guide_note','catatan_header','panduan_header'])[0] || null;
              if (!row) return null;
              return { id: HEADER_GUIDE_NOTE_DOC_ID, note: String(row.note || row.catatan || DEFAULT_HEADER_GUIDE_NOTE), updatedAtMs: Number(row.updatedAtMs || 0), updatedBy: String(row.updatedBy || ''), updatedByName: String(row.updatedByName || '') };
            })(),
            staffDailyHomeNote: (() => {
              const row = pickSheetRows(['staffDailyHomeNote','staff_daily_home_note','catatan_home_staff','catatan_staff'])[0] || null;
              if (!row) return null;
              return { id: STAFF_DAILY_NOTE_DOC_ID, enabled: parseBackupBoolean(row.enabled, true), note: String(row.note || row.catatan || DEFAULT_STAFF_DAILY_NOTE), updatedAtMs: Number(row.updatedAtMs || 0), updatedBy: String(row.updatedBy || ''), updatedByName: String(row.updatedByName || '') };
            })(),
            receiptTextSettings: (() => {
              const row = pickSheetRows(['receiptTextSettings','receipt_text_settings','setting_struk','struk'])[0] || null;
              return row ? normalizeBackupReceiptSettings(row) : null;
            })(),
            rismaManualClosingConfig: (() => {
              const row = pickSheetRows(['rismaManualClosingConfig','risma_manual_closing','Closing Manual Risma'])[0] || null;
              if (!row) return null;
              const allowed = String(row.allowedUsers || '').split(/[|,]/).map(s => sanitizeUsername(s)).filter(Boolean);
              return { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: parseBackupBoolean(row.enabled, true), allowedUsers: allowed, allowedNames: parseBackupJsonObject(row.allowedNames, {}) };
            })(),
            auditLogs: pickSheetRows(['auditLogs','audit_logs','log_aktivitas']).map(a => ({
              id: String(a.id || ''),
              action: String(a.action || a.type || ''),
              user: sanitizeUsername(a.user || a.username || ''),
              name: String(a.name || ''),
              createdAtMs: Number(a.createdAtMs || 0),
              detail: (() => { try { return JSON.parse(a.detail || '{}'); } catch(e) { return { raw: String(a.detail || '') }; } })()
            })).filter(a => a.action || a.user)
          }
        };
      }
      if (!isRestoreBackupShapeSafe(backup)) throw new Error('Isi backup kosong / tidak terbaca');
      if (!confirm(getRestoreBackupSummaryText(backup, kind.toUpperCase()))) {
        setLoading(false);
        return;
      }
      const emergencyFile = await saveEmergencyBackupBeforeRestore(kind);
      if (emergencyFile) console.log('Emergency backup dibuat:', emergencyFile);
      muteAdminNotificationsForRestore(15 * 60 * 1000);
      stopRealtimeData();
      const result = await importBackupData(backup);
      markAdminKnownTransactions(result.transactions || []);
      adminNotifBootstrapped = true;
      unmuteAdminNotificationsForRestore();
      bindRealtimeData();
      selectedRestoreProFile = null;
      if ($('restore-pro-file')) $('restore-pro-file').value = '';
      if ($('restore-file')) $('restore-file').value = '';
      if ($('restore-excel-file')) $('restore-excel-file').value = '';
      await logAudit('restore_data', { format: kind, users: result.users.length, attendance: result.attendance.length, transactions: result.transactions.length, closings: result.closings.length, manualBonuses: result.manualBonuses.length, unlockRequests: result.unlockRequests.length, dailyTargets: result.dailyTargets.length, targetBonusRewards: result.targetBonusRewards.length, targetNotifications: result.targetNotifications.length, targetSettings: result.targetSettings.length, adminDeviceTokens: result.adminDeviceTokens.length });
      showToast(`✓ Restore ${kind.toUpperCase()} aman selesai: ${result.users.length} user, ${result.attendance.length} absen, ${result.transactions.length} transaksi, ${result.dailyTargets.length} target · tidak ada data lama yang dihapus`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      unmuteAdminNotificationsForRestore();
      if (currentUser) bindRealtimeData();
      console.error(e);
      showToast(e.message || 'Gagal restore file', true);
    }
    setLoading(false);
  }

  function clearLocalAppDataAfterReset() {
    try {
      const keysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key || key === SESSION_KEY || key === PAGE_KEY) continue;
        if (
          key.startsWith('rocky_attendance_cache_') ||
          key === 'rocky_admin_setting_panels_v1' ||
          key.startsWith('rocky_report_') ||
          key.startsWith('rocky_backup_') ||
          key.startsWith('rocky_restore_') ||
          key === ADMIN_NOTIF_SEEN_KEY ||
          key.startsWith(HEADER_GUIDE_HIDDEN)
        ) keysToRemove.push(key);
      }
      keysToRemove.forEach(key => localStorage.removeItem(key));
    } catch (e) {
      console.warn('Gagal membersihkan cache lokal:', e);
    }
  }

  async function deleteCollectionCompletely(collectionName, options = {}) {
    // Supabase mode: delete server-side dalam 1 request. Jauh lebih cepat daripada delete per dokumen.
    if (db?.type === 'supabase') {
      const keepIds = Array.isArray(options.keepIds) ? options.keepIds : [];
      return fastDeleteCollectionCompat(collectionName, { keepIds });
    }
    const snap = await getDocs(collection(db, collectionName));
    let deleted = 0;
    for (const item of snap.docs) {
      if (typeof options.skip === 'function' && options.skip(item)) continue;
      await deleteDoc(doc(db, collectionName, item.id));
      deleted++;
    }
    return deleted;
  }

  function isMissingSupabaseTableError(e) {
    const text = String(e?.code || e?.message || e || '').toLowerCase();
    return text.includes('42p01') || text.includes('pgrst205') || text.includes('does not exist') || text.includes('not found') || text.includes('schema cache');
  }

  async function deleteCollectionIfPresent(collectionName, options = {}) {
    try {
      return await deleteCollectionCompletely(collectionName, options);
    } catch (e) {
      if (isMissingSupabaseTableError(e)) {
        console.warn(`Tabel ${collectionName} belum ada, reset dilewati`);
        return 0;
      }
      throw e;
    }
  }

  function resetRuntimeStateAfterDataWipe() {
    selectedUserFilter = 'all';
    selectedRestoreProFile = null;
    recycleSearch = '';
    recycleUserFilter = 'all';
    recycleBinLimit = 20;
    historyDisplayLimit = HISTORY_PAGE_STEP;
    inactiveUserLimit = INACTIVE_USER_STEP;
    auditLogLimit = 10;
    adminMoreOpen = false;
    reportFilter = 'daily';
    reportMonthKey = '';
    cachedTransactions = [];
    cachedAttendance = [];
    cachedAuditLogs = [];
    cachedClosings = [];
    cachedManualBonuses = [];
    cachedUnlockRequests = [];
    cachedDailyTarget = null;
    cachedTargetNotification = null;
    cachedTargetSettings = {};
    cachedTargetSettingRows = [];
    cachedRismaManualClosingConfig = { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
    cachedHeaderGuideNote = { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
      cachedStaffDailyHomeNote = { id: STAFF_DAILY_NOTE_DOC_ID, note: DEFAULT_STAFF_DAILY_NOTE, enabled: true, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedReceiptTextSettings = { id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    cachedBonusSettings = getDefaultBonusSettings();
    cachedUsers = (cachedUsers && cachedUsers.length)
      ? sortUsers(cachedUsers)
      : (currentUser ? [{ ...currentUser, username: sanitizeUsername(currentUser.username || 'admin'), active: true, deleted: false }] : []);
    attendanceReady = false;
    adminClosingPanelHash = '';
    adminDashboardPanelsHash = '';
    try {
      if (typeof adminSettingPanels !== 'undefined') {
        ADMIN_PANEL_KEYS.forEach(k => adminSettingPanels[k] = false);
        saveAdminPanelState();
      }
    } catch (e) {}
    clearLocalAppDataAfterReset();
    clearAdminUserForm();
    if ($('restore-file')) $('restore-file').value = '';
    if ($('restore-excel-file')) $('restore-excel-file').value = '';
    if ($('restore-pro-file')) $('restore-pro-file').value = '';
  }

  async function resetAllAppData() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const pin = await askPin(`⚠️ Reset SEMUA data aplikasi?
Data transaksi, absen, closing, bonus manual, buka fitur, target harian, notifikasi, audit log, recycle bin, setting bonus, setting target, catatan header, catatan home staff, setting struk, dan config closing Risma akan dihapus/reset.

Semua akun user dan admin TIDAK ikut dihapus supaya aplikasi pusat tetap aman dan aplikasi lain tetap bisa login.

Ketik PIN admin untuk lanjut:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin, 'PIN admin salah!'))) return;
    if (!confirm('FINAL: reset akan menghapus semua data operasional dan cache lokal. Lanjutkan?')) return;

    const emergencyFile = await saveEmergencyBackupBeforeRestore('reset-data');
    if (!emergencyFile) {
      const lanjutTanpaBackup = confirm('Backup darurat otomatis gagal dibuat. Lanjut reset TANPA backup darurat?');
      if (!lanjutTanpaBackup) return;
    } else {
      console.log('Backup darurat sebelum reset dibuat:', emergencyFile);
      showToast('Backup darurat dibuat, reset dimulai...');
    }

    setLoading(true);
    try {
      muteAdminNotificationsForRestore(15 * 60 * 1000);
      stopRealtimeData();

      const deleted = {};
      deleted.transactions = await deleteCollectionIfPresent('transactions');
      deleted.attendance = await deleteCollectionIfPresent('attendance');
      deleted.closings = await deleteCollectionIfPresent('closings');
      deleted.manualBonuses = await deleteCollectionIfPresent('manualBonuses');
      deleted.staff_leave_requests = await deleteCollectionIfPresent(STAFF_UNLOCK_TABLE);
      deleted.dailyTargets = await deleteCollectionIfPresent(SERVER_DAILY_TARGETS_TABLE);
      deleted.targetBonusRewards = await deleteCollectionIfPresent(SERVER_TARGET_REWARDS_TABLE);
      deleted.targetNotifications = await deleteCollectionIfPresent(SERVER_TARGET_NOTIFICATIONS_TABLE);
      deleted.targetSettings = await deleteCollectionIfPresent(SERVER_TARGET_SETTINGS_TABLE);
      deleted.adminDeviceTokens = await deleteCollectionIfPresent('adminDeviceTokens');
      deleted.audit_logs = await deleteCollectionIfPresent('audit_logs');
      deleted.users = 0;

      resetRuntimeStateAfterDataWipe();
      bindRealtimeData();
      unmuteAdminNotificationsForRestore();
      showToast(`✓ Reset selesai: ${Object.values(deleted).reduce((sum, n) => sum + n, 0)} data operasional dihapus · semua user/admin tetap aman`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal reset semua data', true);
      unmuteAdminNotificationsForRestore();
      if (currentUser) bindRealtimeData();
    }
    setLoading(false);
  }


  async function downloadBackup(format = 'json') {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    setLoading(true);
    try {
      const backup = await getBackupPayloadFresh();
      const stamp = new Date().toISOString().slice(0,19).replace(/[:T]/g,'-');
      if (format === 'json') {
        downloadTextFile(JSON.stringify(backup, null, 2), `rocky-backup-${stamp}.json`, 'application/json');
        showToast('✓ Backup JSON diunduh');
      } else if (format === 'xlsx') {
        const XLSX = await ensureXlsxReady();
        const wb = XLSX.utils.book_new();
        const usersRows = backup.data.users.map(u => ({
          username: u.username || '',
          name: u.name || '',
          pin: u.pin || '',
          role: u.role || 'staff',
          transactionBonusRate: Number(u.transactionBonusRate ?? (Number(u.transactionBonusPercent || 0) / 100) ?? 0),
          transactionBonusPercent: Number(u.transactionBonusPercent ?? (Number(u.transactionBonusRate || 0) * 100) ?? 0),
          closingBonusPerMinute: isDailyRole(u.role || 'staff') ? 0 : Number(u.closingBonusPerMinute || 0),
          dailyBonusPercent: Number(u.dailyBonusPercent || (Number(u.dailyBonusRate || 0) * 100) || 0),
          deviceStatus: u.deviceLocked ? 'LOCKED' : 'UNLOCKED',
          deviceId: u.deviceId || '',
          deviceLabel: u.deviceLabel || '',
          deviceLastLoginAtMs: u.deviceLastLoginAtMs || '',
          active: u.active !== false,
          deleted: u.deleted === true,
          createdAt: u.createdAt || ''
        }));
        const attendanceRows = backup.data.attendance.map(a => ({
          id: a.id || '',
          user: a.user || '',
          name: a.name || '',
          dateKey: a.dateKey || '',
          lat: a.lat ?? '',
          lng: a.lng ?? '',
          createdAt: a.createdAt || '',
          createdAtMs: a.createdAtMs || '',
          deleted: a.deleted === true,
          deletedAtMs: a.deletedAtMs || '',
          deletedBy: a.deletedBy || '',
          deletedByName: a.deletedByName || ''
        }));
        const transactionRows = backup.data.transactions.map(t => ({
          id: t.id || '',
          user: t.user || '',
          name: t.name || '',
          note: t.note || '',
          amount: Number(t.amount || 0),
          dateKey: t.dateKey || '',
          monthKey: t.monthKey || '',
          userRole: t.userRole || t.role || '',
          bonusRate: Number.isFinite(Number(t.bonusRate)) ? Number(t.bonusRate) : '',
          bonusPercent: Number.isFinite(Number(t.bonusPercent)) ? Number(t.bonusPercent) : '',
          transactionBonusRate: Number.isFinite(Number(t.bonusRate ?? t.transactionBonusRate)) ? Number(t.bonusRate ?? t.transactionBonusRate) : '',
          transactionBonusPercent: Number.isFinite(Number(t.bonusPercent ?? t.transactionBonusPercent)) ? Number(t.bonusPercent ?? t.transactionBonusPercent) : '',
          bonusGroup: t.bonusGroup || '',
          bonusLogicVersion: t.bonusLogicVersion || '',
          createdAt: t.createdAt || '',
          createdAtMs: t.createdAtMs || '',
          deleted: t.deleted === true,
          deletedAtMs: t.deletedAtMs || '',
          deletedBy: t.deletedBy || '',
          deletedByName: t.deletedByName || ''
        }));
        const closingRows = (backup.data.closings || []).map(c => ({
          id: c.id || '', dateKey: c.dateKey || '', monthKey: c.monthKey || '', user: c.user || '', name: c.name || '', scope: c.scope || '', closed: c.closed === true, canceled: c.canceled === true, closingTime: c.closingTime || c.actualClosingTime || c.manualClosingTime || '', deadline: c.deadline || formatClosingDeadline(c), deadlineTime: getClosingDeadlineTimeLabel(c), deadlineHour: getClosingDeadlineParts(c).hour, deadlineMinute: getClosingDeadlineParts(c).minute, deadlineMinutes: getClosingDeadlineMinutes(c), closingDeadlineTime: getClosingDeadlineTimeLabel(c), delayMinutes: Number(c.delayMinutes || 0), totalBonus: Number(c.totalBonus || 0), bonusPerUser: Number(c.bonusPerUser || 0), bonusByUser: JSON.stringify(c.bonusByUser || {}), bonusPerMinuteByUser: JSON.stringify(c.bonusPerMinuteByUser || {}), canceledUsers: JSON.stringify(c.canceledUsers || {}), closedAtMs: c.closedAtMs || '', closedBy: c.closedBy || '', closedByName: c.closedByName || ''
        }));
        const manualBonusRows = (backup.data.manualBonuses || []).map(b => ({
          id: b.id || '',
          user: b.user || '',
          name: b.name || '',
          userRole: b.userRole || b.role || '',
          bonusGroup: b.bonusGroup || b.role || '',
          amount: Number(b.amount || 0),
          note: b.note || b.reason || '',
          dateKey: b.dateKey || '',
          monthKey: b.monthKey || '',
          type: b.type || '',
          action: b.action || '',
          createdBy: b.createdBy || '',
          createdByName: b.createdByName || '',
          createdAtMs: b.createdAtMs || '',
          deleted: b.deleted === true,
          deletedAtMs: b.deletedAtMs || '',
          deletedBy: b.deletedBy || '',
          deletedByName: b.deletedByName || ''
        }));
        const unlockRequestRows = backupSheetRows(backup.data.unlockRequests || []);
        const dailyTargetRows = backupSheetRows(backup.data.dailyTargets || []);
        const targetBonusRewardRows = backupSheetRows(backup.data.targetBonusRewards || []);
        const targetNotificationRows = backupSheetRows(backup.data.targetNotifications || []);
        const targetSettingRows = backupSheetRows(backup.data.targetSettings || []);
        const adminDeviceTokenRows = backupSheetRows(backup.data.adminDeviceTokens || []);
        const bonusSettingsRows = [{
          transactionBonusRate: backup.data.bonusSettings?.transactionBonusRate ?? '',
          transactionBonusPercent: Number(backup.data.bonusSettings?.transactionBonusRate || 0) * 100,
          closingBonusPerMinute: backup.data.bonusSettings?.closingBonusPerMinute ?? '',
          deadline: formatClosingDeadline(backup.data.bonusSettings || {}),
          deadlineTime: getClosingDeadlineTimeLabel(backup.data.bonusSettings || {}),
          deadlineHour: getClosingDeadlineParts(backup.data.bonusSettings || {}).hour,
          deadlineMinute: getClosingDeadlineParts(backup.data.bonusSettings || {}).minute,
          deadlineMinutes: getClosingDeadlineMinutes(backup.data.bonusSettings || {}),
          closingDeadlineTime: getClosingDeadlineTimeLabel(backup.data.bonusSettings || {}),
          updatedAtMs: backup.data.bonusSettings?.updatedAtMs ?? '',
          updatedBy: backup.data.bonusSettings?.updatedBy ?? '',
          updatedByName: backup.data.bonusSettings?.updatedByName ?? ''
        }];
        const headerGuideRows = [{
          id: HEADER_GUIDE_NOTE_DOC_ID,
          note: backup.data.headerGuideNote?.note || DEFAULT_HEADER_GUIDE_NOTE,
          updatedAtMs: backup.data.headerGuideNote?.updatedAtMs || '',
          updatedBy: backup.data.headerGuideNote?.updatedBy || '',
          updatedByName: backup.data.headerGuideNote?.updatedByName || ''
        }];
        const staffDailyRows = [{
          id: STAFF_DAILY_NOTE_DOC_ID,
          enabled: backup.data.staffDailyHomeNote?.enabled !== false,
          note: backup.data.staffDailyHomeNote?.note || DEFAULT_STAFF_DAILY_NOTE,
          updatedAtMs: backup.data.staffDailyHomeNote?.updatedAtMs || '',
          updatedBy: backup.data.staffDailyHomeNote?.updatedBy || '',
          updatedByName: backup.data.staffDailyHomeNote?.updatedByName || ''
        }];
        const receiptSettings = backup.data.receiptTextSettings || DEFAULT_RECEIPT_TEXT_SETTINGS;
        const receiptTextRows = [{
          id: RECEIPT_TEXT_DOC_ID,
          storeName: receiptSettings.storeName || DEFAULT_RECEIPT_TEXT_SETTINGS.storeName,
          storeSubtext: receiptSettings.storeSubtext || '',
          dailyTitle: receiptSettings.dailyTitle || DEFAULT_RECEIPT_TEXT_SETTINGS.dailyTitle,
          dateLabel: receiptSettings.dateLabel || DEFAULT_RECEIPT_TEXT_SETTINGS.dateLabel,
          cashierLabel: receiptSettings.cashierLabel || DEFAULT_RECEIPT_TEXT_SETTINGS.cashierLabel,
          productLabel: receiptSettings.productLabel || DEFAULT_RECEIPT_TEXT_SETTINGS.productLabel,
          totalLabel: receiptSettings.totalLabel || DEFAULT_RECEIPT_TEXT_SETTINGS.totalLabel,
          countLabel: receiptSettings.countLabel || DEFAULT_RECEIPT_TEXT_SETTINGS.countLabel,
          footerText: receiptSettings.footerText || DEFAULT_RECEIPT_TEXT_SETTINGS.footerText,
          bottomFeedLines: Number(receiptSettings.bottomFeedLines || DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines),
          updatedAtMs: receiptSettings.updatedAtMs || '',
          updatedBy: receiptSettings.updatedBy || '',
          updatedByName: receiptSettings.updatedByName || ''
        }];
        const rismaConfigRows = [{
          id: RISMA_MANUAL_CLOSING_DOC_ID,
          enabled: backup.data.rismaManualClosingConfig?.enabled !== false,
          allowedUsers: (backup.data.rismaManualClosingConfig?.allowedUsers || []).join('|'),
          updatedAtMs: backup.data.rismaManualClosingConfig?.updatedAtMs || '',
          updatedBy: backup.data.rismaManualClosingConfig?.updatedBy || '',
          updatedByName: backup.data.rismaManualClosingConfig?.updatedByName || ''
        }];
        const metaRows = [{ version: backup.version || '', projectId: backup.projectId || firebaseConfig.projectId, exportedAt: backup.exportedAt || '', exportedBy: backup.exportedBy || '', note: 'Backup lengkap: users, attendance, transactions, closings, manualBonuses, unlockRequests, dailyTargets, targetBonusRewards, targetNotifications, targetSettings, adminDeviceTokens, bonusSettings, headerGuideNote, staffDailyHomeNote, receiptTextSettings, rismaManualClosingConfig, auditLogs' }];
        const auditRows = (backup.data.auditLogs || []).map(a => ({ id: a.id || '', action: a.action || a.type || '', user: a.user || a.username || '', name: a.name || '', createdAtMs: a.createdAtMs || '', detail: JSON.stringify(a.detail || a.payload || {}) }));
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(metaRows), 'meta');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(usersRows), 'users');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(attendanceRows), 'attendance');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(transactionRows), 'transactions');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(closingRows), 'closings');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(manualBonusRows), 'manualBonuses');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(unlockRequestRows), 'unlockRequests');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(dailyTargetRows), 'dailyTargets');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(targetBonusRewardRows), 'targetBonusRewards');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(targetNotificationRows), 'targetNotifications');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(targetSettingRows), 'targetSettings');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(adminDeviceTokenRows), 'adminDeviceTokens');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(bonusSettingsRows), 'bonusSettings');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(headerGuideRows), 'headerGuideNote');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(staffDailyRows), 'staffDailyHomeNote');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(receiptTextRows), 'receiptTextSettings');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rismaConfigRows), 'rismaManualClosingConfig');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(auditRows), 'auditLogs');
        const excelName = `rocky-backup-${stamp}.xlsx`;
        const excelMime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        const excelBase64 = XLSX.write(wb, { bookType: 'xlsx', type: 'base64' });
        if (!saveBase64ToAndroidDownloads(excelName, excelMime, excelBase64)) {
          XLSX.writeFile(wb, excelName);
        }
        showToast('✓ Backup Excel diunduh');
      }
    } catch (e) {
      console.error('Backup gagal:', e);
      showToast('Gagal backup: ' + (e?.message || e?.code || 'cek console'), true);
    }
    setLoading(false);
  }

  async function importBackupData(backup) {
    const data = backup?.data || {};
    const users = Array.isArray(data.users) ? data.users : [];
    const attendance = Array.isArray(data.attendance) ? data.attendance : [];
    const transactions = Array.isArray(data.transactions) ? data.transactions : [];
    const closings = Array.isArray(data.closings) ? data.closings : [];
    const manualBonuses = Array.isArray(data.manualBonuses) ? data.manualBonuses : [];
    const unlockRequests = Array.isArray(data.unlockRequests) ? data.unlockRequests : [];
    const dailyTargets = Array.isArray(data.dailyTargets) ? data.dailyTargets : [];
    const targetBonusRewards = Array.isArray(data.targetBonusRewards) ? data.targetBonusRewards : [];
    const targetNotifications = Array.isArray(data.targetNotifications) ? data.targetNotifications : [];
    const targetSettings = Array.isArray(data.targetSettings) ? data.targetSettings : (data.targetSettings && typeof data.targetSettings === 'object' ? [data.targetSettings] : []);
    const adminDeviceTokens = Array.isArray(data.adminDeviceTokens) ? data.adminDeviceTokens : [];
    const auditLogs = Array.isArray(data.auditLogs) ? data.auditLogs : [];
    const headerGuideNote = data.headerGuideNote && typeof data.headerGuideNote === 'object' ? data.headerGuideNote : null;
    const staffDailyHomeNote = data.staffDailyHomeNote && typeof data.staffDailyHomeNote === 'object' ? data.staffDailyHomeNote : null;
    const receiptTextSettings = normalizeBackupReceiptSettings(data.receiptTextSettings);
    const cleanupResult = { attendanceRemoved: 0, transactionsRemoved: 0, closingsRemoved: 0, manualBonusesRemoved: 0, usersDeactivated: 0 };

    const restoreUsersByUsername = new Map();
    for (const rawUser of users) {
      const username = sanitizeUsername(rawUser?.username);
      if (!username) continue;
      const role = normalizeRole(rawUser.role || 'staff');
      const trxRate = resolveBackupTransactionRate(rawUser, role);
      const trxPercent = resolveBackupTransactionPercent(rawUser, role);
      restoreUsersByUsername.set(username, { role, transactionBonusRate: trxRate, transactionBonusPercent: trxPercent });
    }
    const restoredRoleForUser = (username, preferred = '') => {
      const p = normalizeRole(preferred || '');
      if (preferred && ['staff','harian','admin'].includes(p)) return p;
      return restoreUsersByUsername.get(sanitizeUsername(username))?.role || (isDailyEmployee(username) ? 'harian' : 'staff');
    };
    const restoredBonusForUser = (username) => restoreUsersByUsername.get(sanitizeUsername(username)) || null;
    const nowMs = Date.now();
    const restoredBy = currentUser?.username || 'admin';
    const restoredByName = currentUser?.name || 'Admin';

    const userRows = [];
    const attendanceRows = [];
    const transactionRows = [];
    const closingRows = [];
    const manualBonusRows = [];
    const unlockRequestRows = [];
    const dailyTargetRows = [];
    const targetBonusRewardRows = [];
    const targetNotificationRows = [];
    const targetSettingRows = [];
    const adminDeviceTokenRows = [];
    const auditRows = [];

    const pushGenericRestoreRows = (sourceRows, targetRows, fallbackId) => {
      (sourceRows || []).forEach((raw, index) => {
        const row = serializeBackupRecord(raw || {});
        const fallback = typeof fallbackId === 'function' ? fallbackId(row, index) : `${fallbackId || 'restore'}_${index + 1}_${nowMs}`;
        const id = safeRestoreDocId(row.id || row.docId || row.clientId || fallback);
        if (!id) return;
        targetRows.push({ id, data: cleanFirestorePayload({
          ...row,
          id,
          restoredAt: serverTimestamp(),
          restoredAtMs: nowMs,
          restoredBy,
          restoredByName,
          restoredFromBackup: true
        }) });
      });
    };

    // Settings tetap disimpan ke tabel closings karena logika lama membaca setting dari collection/dokumen ini.
    if (data.bonusSettings && typeof data.bonusSettings === 'object') {
      const s = data.bonusSettings;
      closingRows.push({ id: '__bonus_settings', data: cleanFirestorePayload({
        transactionBonusRate: (() => { const rate = parseBackupNumber(s.transactionBonusRate, null); if (rate !== null && rate >= 0) return rate; const pct = parseBackupNumber(s.transactionBonusPercent, null); return pct !== null && pct >= 0 ? pct / 100 : DEFAULT_TRANSACTION_BONUS_RATE; })(),
        transactionBonusPercent: (() => { const pct = parseBackupNumber(s.transactionBonusPercent, null); if (pct !== null && pct >= 0) return pct; const rate = parseBackupNumber(s.transactionBonusRate, null); return rate !== null && rate >= 0 ? Number((rate * 100).toFixed(3)) : Number((DEFAULT_TRANSACTION_BONUS_RATE * 100).toFixed(3)); })(),
        closingBonusPerMinute: (() => { const n = parseBackupNumber(s.closingBonusPerMinute, null); return n !== null && n >= 0 ? n : DEFAULT_CLOSING_BONUS_PER_MINUTE; })(),
        ...getClosingDeadlineSnapshot(s),
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: restoredBy,
        updatedByName: restoredByName,
        restoredFromBackup: true
      })});
    }

    if (data.rismaManualClosingConfig && typeof data.rismaManualClosingConfig === 'object') {
      const cfg = data.rismaManualClosingConfig;
      const allowedUsers = Array.isArray(cfg.allowedUsers) ? cfg.allowedUsers.map(sanitizeUsername).filter(Boolean) : [];
      closingRows.push({ id: RISMA_MANUAL_CLOSING_DOC_ID, data: cleanFirestorePayload({
        id: RISMA_MANUAL_CLOSING_DOC_ID,
        enabled: cfg.enabled !== false,
        allowedUsers: [...new Set(allowedUsers)],
        allowedNames: cfg.allowedNames && typeof cfg.allowedNames === 'object' ? cfg.allowedNames : {},
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: restoredBy,
        updatedByName: restoredByName,
        source: 'restore_backup',
        type: 'closing_manual_config',
        dateKey: RISMA_MANUAL_CLOSING_DOC_ID,
        title: 'Closing Manual Risma'
      })});
    }

    if (headerGuideNote) {
      const note = String(headerGuideNote.note || DEFAULT_HEADER_GUIDE_NOTE).trim() || DEFAULT_HEADER_GUIDE_NOTE;
      closingRows.push({ id: HEADER_GUIDE_NOTE_DOC_ID, data: cleanFirestorePayload({
        id: HEADER_GUIDE_NOTE_DOC_ID,
        type: 'header_guide_note',
        note: note.slice(0, 280),
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: restoredBy,
        updatedByName: restoredByName,
        restoredFromBackup: true
      })});
    }

    if (staffDailyHomeNote) {
      const note = String(staffDailyHomeNote.note || DEFAULT_STAFF_DAILY_NOTE).trim() || DEFAULT_STAFF_DAILY_NOTE;
      closingRows.push({ id: STAFF_DAILY_NOTE_DOC_ID, data: cleanFirestorePayload({
        id: STAFF_DAILY_NOTE_DOC_ID,
        type: 'staff_daily_home_note',
        note: note.slice(0, 500),
        enabled: staffDailyHomeNote.enabled !== false,
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: restoredBy,
        updatedByName: restoredByName,
        restoredFromBackup: true
      })});
    }

    if (receiptTextSettings) {
      const receiptPayload = normalizeReceiptTextSettings(receiptTextSettings);
      closingRows.push({ id: RECEIPT_TEXT_DOC_ID, data: cleanFirestorePayload({
        ...receiptPayload,
        id: RECEIPT_TEXT_DOC_ID,
        dateKey: RECEIPT_TEXT_DOC_ID,
        closed: false,
        type: 'receipt_text_settings',
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: restoredBy,
        updatedByName: restoredByName,
        restoredFromBackup: true
      })});
    }

    for (const u of users) {
      const username = sanitizeUsername(u.username);
      if (!username) continue;
      const role = normalizeRole(u.role || 'staff');
      const existingUser = getUserByUsername(username) || {};
      const adminProtected = role === 'admin' || ADMIN_USERNAMES.includes(username);
      const userDeleted = adminProtected ? false : isBackupDeleted(u);
      const userActive = adminProtected ? true : (u.active !== false && u.active !== 'false' && !userDeleted);
      const hasTrxBonusInBackup = hasBonusValue(u.transactionBonusRate) || hasBonusValue(u.transactionBonusPercent) || hasBonusValue(u.bonusPercent) || hasBonusValue(u.bonus_transaksi) || (isDailyRole(role) && (hasBonusValue(u.dailyBonusRate) || hasBonusValue(u.dailyBonusPercent)));
      const hasClosingBonusInBackup = hasBonusValue(u.closingBonusPerMinute) || hasBonusValue(u.bonus_closing);
      const userPayload = {
        username,
        name: String(u.name || existingUser.name || username),
        pin: String(u.pin || existingUser.pin || ''),
        role,
        active: userActive,
        deleted: userDeleted,
        deletedAt: userDeleted ? (u.deletedAt || existingUser.deletedAt || null) : null,
        deletedAtMs: userDeleted ? Number(u.deletedAtMs || existingUser.deletedAtMs || 0) : null,
        deletedBy: userDeleted ? (u.deletedBy || existingUser.deletedBy || null) : null,
        deletedByName: userDeleted ? (u.deletedByName || existingUser.deletedByName || null) : null,
        createdAt: u.createdAt ? Timestamp.fromMillis(new Date(u.createdAt).getTime()) : (existingUser.createdAt || serverTimestamp())
      };
      if (hasTrxBonusInBackup || !existingUser.username) {
        userPayload.transactionBonusRate = resolveBackupTransactionRate(u, role);
        userPayload.transactionBonusPercent = resolveBackupTransactionPercent(u, role);
      } else {
        userPayload.transactionBonusRate = Number(existingUser.transactionBonusRate || 0);
        userPayload.transactionBonusPercent = Number(existingUser.transactionBonusPercent || 0);
      }
      if (hasClosingBonusInBackup || !existingUser.username || isDailyRole(role) || role === 'admin') {
        userPayload.closingBonusPerMinute = resolveBackupClosingBonusPerMinute(u, role);
      } else {
        userPayload.closingBonusPerMinute = Number(existingUser.closingBonusPerMinute || 0);
      }
      if (isDailyRole(role)) {
        userPayload.dailyBonusRate = (() => { const r = parseBackupNumber(u.dailyBonusRate, null); if (r !== null && r >= 0) return r; const p = parseBackupNumber(u.dailyBonusPercent, null); return p !== null && p >= 0 ? p / 100 : Number(existingUser.dailyBonusRate || 0); })();
        userPayload.dailyBonusPercent = (() => { const p = parseBackupNumber(u.dailyBonusPercent, null); if (p !== null && p >= 0) return p; const r = parseBackupNumber(u.dailyBonusRate, null); return r !== null && r >= 0 ? Number((r * 100).toFixed(3)) : Number(existingUser.dailyBonusPercent || 0); })();
        userPayload.deviceId = '';
        userPayload.deviceLocked = false;
        userPayload.deviceLabel = 'Harian bebas login';
        userPayload.deviceLockedAtMs = 0;
      } else {
        userPayload.dailyBonusRate = hasBonusValue(u.dailyBonusRate) ? Number(u.dailyBonusRate || 0) : Number(existingUser.dailyBonusRate || 0);
        userPayload.dailyBonusPercent = hasBonusValue(u.dailyBonusPercent) ? Number(u.dailyBonusPercent || 0) : Number(existingUser.dailyBonusPercent || 0);
        userPayload.deviceId = String(u.deviceId || existingUser.deviceId || '');
        userPayload.deviceLocked = (!!String(userPayload.deviceId || '').trim() || u.deviceLocked === true || existingUser.deviceLocked === true);
        userPayload.deviceLabel = String(u.deviceLabel || existingUser.deviceLabel || '');
        userPayload.deviceLockedAtMs = Number(u.deviceLockedAtMs || existingUser.deviceLockedAtMs || 0);
      }
      userPayload.deviceLastLoginAtMs = Number(u.deviceLastLoginAtMs || existingUser.deviceLastLoginAtMs || 0);
      userRows.push({ id: username, data: cleanFirestorePayload(userPayload) });
    }

    for (const a of attendance) {
      const ms = Number(a.createdAtMs || (a.createdAt ? new Date(a.createdAt).getTime() : nowMs));
      const user = sanitizeUsername(a.user);
      const dateKey = String(a.dateKey || '').slice(0, 10);
      if (!user || !dateKey) continue;
      const attDocId = getAttendanceDocId(user, dateKey);
      const deleted = isBackupDeleted(a);
      attendanceRows.push({ id: attDocId, data: cleanFirestorePayload({
        user,
        name: String(a.name || a.user || ''),
        dateKey,
        lat: a.lat ?? null,
        lng: a.lng ?? null,
        createdAt: Timestamp.fromMillis(ms),
        createdAtMs: ms,
        deleted,
        deletedAt: deleted ? (a.deletedAt || null) : null,
        deletedAtMs: deleted ? Number(a.deletedAtMs || 0) : null,
        deletedBy: deleted ? (a.deletedBy || null) : null,
        deletedByName: deleted ? (a.deletedByName || null) : null,
        restoredAt: serverTimestamp(),
        restoredBy
      })});
    }

    for (const t of transactions) {
      const sourceCreatedAtMs = Number(t.createdAtMs || 0);
      const sourceCreatedAtParsed = t.createdAt ? new Date(t.createdAt).getTime() : 0;
      const restoreHasSourceTime = !!(sourceCreatedAtMs || sourceCreatedAtParsed);
      const ms = Number(sourceCreatedAtMs || sourceCreatedAtParsed || nowMs);
      const user = sanitizeUsername(t.user);
      if (!user) continue;
      const dateKey = String(t.dateKey || '').slice(0, 10) || toDateKey(new Date(ms));
      const monthKey = String(t.monthKey || '').slice(0, 7) || dateKey.slice(0, 7);
      const deleted = isBackupDeleted(t);
      const recordRole = restoredRoleForUser(user, t.userRole || t.role || '');
      const restoredBonus = restoredBonusForUser(user);
      const fallbackRate = Number.isFinite(Number(restoredBonus?.transactionBonusRate)) ? Number(restoredBonus.transactionBonusRate) : getUserTransactionBonusRate(t.user);
      const fallbackPercent = Number.isFinite(Number(restoredBonus?.transactionBonusPercent)) ? Number(restoredBonus.transactionBonusPercent) : Number((fallbackRate * 100).toFixed(3));
      const rawPayment = normalizeTransactionPaymentMethod(t.paymentMethod || t.payment_method || t.paymentLabel || t.payment_label || t.metodePembayaran || t.metode_pembayaran) || 'cash';
      const payload = {
        id: t.id || '',
        user,
        name: String(t.name || t.user || ''),
        note: String(t.note || 'Transaksi'),
        amount: Number(t.amount || 0),
        paymentMethod: rawPayment,
        paymentLabel: getTransactionPaymentInfo(rawPayment).label,
        paymentStatus: String(t.paymentStatus || 'success'),
        paymentCashOutType: rawPayment === 'qris_transfer' ? 'qris' : '',
        isNonCashPayment: rawPayment === 'qris_transfer',
        paymentConfirmed: true,
        paymentConfirmedAtMs: ms,
        dateKey,
        monthKey,
        userRole: recordRole,
        role: recordRole,
        bonusGroup: sanitizeUsername(t.bonusGroup || recordRole),
        bonusRate: (() => { const n = readBackupTransactionBonusRate(t, fallbackRate); return n !== null && Number.isFinite(Number(n)) ? Number(n) : fallbackRate; })(),
        bonusPercent: (() => { const n = readBackupTransactionBonusPercent(t, fallbackPercent); return n !== null && Number.isFinite(Number(n)) ? Number(n) : fallbackPercent; })(),
        bonusLogicVersion: Number(t.bonusLogicVersion || 3),
        createdAt: Timestamp.fromMillis(ms),
        createdAtMs: ms,
        deleted,
        deletedAt: deleted ? (t.deletedAt || null) : null,
        deletedAtMs: deleted ? Number(t.deletedAtMs || 0) : null,
        deletedBy: deleted ? (t.deletedBy || null) : null,
        deletedByName: deleted ? (t.deletedByName || null) : null,
        restoredAt: serverTimestamp(),
        restoredBy,
        restoredFromBackup: true,
        source: 'restore_backup',
        notifyAdmin: false,
        notificationStatus: 'skip'
      };
      const restorePayloadForCheck = { ...payload, restoreHasSourceTime };
      // Supabase fast restore: pakai id asli backup kalau ada, kalau tidak ada pakai stable id.
      // Ini menghindari ratusan query duplicate-check yang bikin restore sangat lama.
      const txDocId = safeRestoreDocId(t.id) || getStableTransactionRestoreId(restorePayloadForCheck);
      transactionRows.push({ id: txDocId, data: cleanFirestorePayload(payload) });
    }

    for (const c of closings) {
      const dateKey = String(c.dateKey || '').slice(0, 10);
      const user = sanitizeUsername(c.user || '');
      const scope = String(c.scope || (user ? 'user' : 'global'));
      const id = String(c.id || (dateKey ? (user ? `${dateKey}_${user}` : dateKey) : '')).replace(/[^a-zA-Z0-9_\-.]/g, '_').slice(0, 160);
      if (!id || id === '__bonus_settings' || id === RISMA_MANUAL_CLOSING_DOC_ID || id === HEADER_GUIDE_NOTE_DOC_ID || id === STAFF_DAILY_NOTE_DOC_ID || id === RECEIPT_TEXT_DOC_ID) continue;
      const payload = cleanFirestorePayload({
        ...c,
        id,
        dateKey: dateKey || String(c.dateKey || ''),
        monthKey: String(c.monthKey || (dateKey ? dateKey.slice(0, 7) : '')).slice(0, 7),
        user: user || null,
        name: String(c.name || c.user || ''),
        scope,
        closed: c.closed !== false,
        canceled: c.canceled === true || c.closed === false,
        delayMinutes: Number(c.delayMinutes || 0),
        totalBonus: Number(c.totalBonus || 0),
        bonusPerUser: Number(c.bonusPerUser || 0),
        restoredAt: serverTimestamp(),
        restoredBy
      });
      closingRows.push({ id, data: payload });
    }

    for (const b of manualBonuses) {
      const user = sanitizeUsername(b.user || '');
      if (!user) continue;
      const dateKey = String(b.dateKey || '').slice(0, 10) || toDateKey(new Date(Number(b.createdAtMs || nowMs)));
      const monthKey = String(b.monthKey || dateKey.slice(0, 7)).slice(0, 7);
      const id = safeRestoreDocId(b.id || `manual_${user}_${dateKey}_${Number(b.amount || 0)}_${Number(b.createdAtMs || nowMs)}_${stableRestoreHash(String(b.note || b.reason || 'Bonus manual'))}`);
      const bonusRole = restoredRoleForUser(user, b.userRole || b.role || b.bonusGroup || '');
      manualBonusRows.push({ id, data: cleanFirestorePayload({
        ...b,
        id,
        user,
        name: String(b.name || b.user || ''),
        userRole: bonusRole,
        role: bonusRole,
        bonusGroup: sanitizeUsername(b.bonusGroup || bonusRole),
        amount: Number(b.amount || 0),
        note: String(b.note || b.reason || 'Bonus manual'),
        dateKey,
        monthKey,
        deleted: b.deleted === true || b.deleted === 'true' ? true : false,
        restoredAt: serverTimestamp(),
        restoredBy
      })});
    }

    pushGenericRestoreRows(unlockRequests, unlockRequestRows, (row, index) => {
      const user = sanitizeUsername(row.user || row.username || row.targetUsername || 'user');
      return row.id || `unlock_${user}_${Number(row.createdAtMs || row.requestedAtMs || nowMs)}_${index + 1}`;
    });
    pushGenericRestoreRows(dailyTargets, dailyTargetRows, (row, index) => {
      const dk = String(row.dateKey || row.date || '').slice(0, 10);
      return row.id || (dk ? serverTargetDocId(dk) : `daily_target_restore_${nowMs}_${index + 1}`);
    });
    pushGenericRestoreRows(targetBonusRewards, targetBonusRewardRows, (row, index) => {
      const dk = String(row.dateKey || row.date || '').slice(0, 10);
      const user = sanitizeUsername(row.user || row.targetUsername || row.username || '');
      return row.id || (dk && user ? serverTargetRewardId(dk, user) : `targetreward_restore_${nowMs}_${index + 1}`);
    });
    pushGenericRestoreRows(targetNotifications, targetNotificationRows, (row, index) => {
      const dk = String(row.dateKey || row.date || '').slice(0, 10);
      return row.id || (dk ? serverTargetNotifId(dk) : `targetnotif_restore_${nowMs}_${index + 1}`);
    });
    pushGenericRestoreRows(targetSettings, targetSettingRows, (row, index) => {
      const dk = serverNormalizeTargetDateKey(row.effectiveDate || row.dateKey || row.startDate || row.targetDate || '', '');
      return row.id || (dk ? serverTargetSettingDocId(dk) : (index === 0 ? 'daily_target' : `target_setting_${index + 1}`));
    });
    pushGenericRestoreRows(adminDeviceTokens, adminDeviceTokenRows, (row, index) => row.id || row.token || row.deviceId || `admin_token_restore_${nowMs}_${index + 1}`);

    for (const a of auditLogs.slice(0, AUDIT_SYNC_LIMIT)) {
      const id = String(a.id || `restore_log_${nowMs}_${Math.random().toString(36).slice(2)}`).replace(/[^a-zA-Z0-9_\-.]/g, '_').slice(0, 160);
      auditRows.push({ id, data: cleanFirestorePayload({ ...a, id, restoredAt: serverTimestamp(), restoredBy }) });
    }

    await bulkUpsertCompat('users', userRows, 500, 'user');
    await bulkUpsertCompat('attendance', attendanceRows, 500, 'absen');
    await bulkUpsertCompat('transactions', transactionRows, 500, 'transaksi');
    await bulkUpsertCompat('closings', closingRows, 500, 'closing/settings');
    await bulkUpsertCompat('manualBonuses', manualBonusRows, 500, 'bonus manual');
    await bulkUpsertIfPresent(STAFF_UNLOCK_TABLE, unlockRequestRows, 500, 'buka fitur');
    await bulkUpsertIfPresent(SERVER_DAILY_TARGETS_TABLE, dailyTargetRows, 500, 'target harian');
    await bulkUpsertIfPresent(SERVER_TARGET_REWARDS_TABLE, targetBonusRewardRows, 500, 'reward target');
    await bulkUpsertIfPresent(SERVER_TARGET_NOTIFICATIONS_TABLE, targetNotificationRows, 500, 'notifikasi target');
    await bulkUpsertIfPresent(SERVER_TARGET_SETTINGS_TABLE, targetSettingRows, 500, 'setting target');
    cachedTargetSettingRows = targetSettingRows.map(r => ({ id: r.id, ...(r.data || {}) }));
    cachedTargetSettings = serverPickTargetSettings(cachedTargetSettingRows, toDateKey(nowDate())) || {};
    await bulkUpsertIfPresent('adminDeviceTokens', adminDeviceTokenRows, 500, 'token notifikasi');
    await bulkUpsertIfPresent('audit_logs', auditRows, 500, 'audit');

    // MODE AMAN: jangan hapus / soft-delete data aktif yang tidak ada di file backup.
    cleanupResult.attendanceRemoved = 0;
    cleanupResult.transactionsRemoved = 0;
    cleanupResult.closingsRemoved = 0;
    cleanupResult.manualBonusesRemoved = 0;
    cleanupResult.usersDeactivated = 0;

    return { users, attendance, transactions, closings, manualBonuses, unlockRequests, dailyTargets, targetBonusRewards, targetNotifications, targetSettings, adminDeviceTokens, auditLogs, headerGuideNote, staffDailyHomeNote, receiptTextSettings, cleanupResult };
  }

  async function restoreBackupFromFile() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const file = $('restore-file')?.files?.[0];
    if (!file) return showToast('Pilih file backup JSON dulu!', true);
    setLoading(true);
    try {
      const raw = await file.text();
      const backup = normalizeBackupShape(JSON.parse(raw));
      if (!isRestoreBackupShapeSafe(backup)) throw new Error('Isi backup kosong / tidak terbaca');
      if (!confirm(getRestoreBackupSummaryText(backup, 'JSON'))) {
        setLoading(false);
        return;
      }
      const emergencyFile = await saveEmergencyBackupBeforeRestore('json');
      if (emergencyFile) console.log('Emergency backup dibuat:', emergencyFile);
      muteAdminNotificationsForRestore(15 * 60 * 1000);
      stopRealtimeData();
      const result = await importBackupData(backup);
      markAdminKnownTransactions(result.transactions || []);
      adminNotifBootstrapped = true;
      unmuteAdminNotificationsForRestore();
      bindRealtimeData();
      if ($('restore-file')) $('restore-file').value = '';
      await logAudit('restore_data', { format: 'json', users: result.users.length, attendance: result.attendance.length, transactions: result.transactions.length, closings: result.closings.length, manualBonuses: result.manualBonuses.length, unlockRequests: result.unlockRequests.length, dailyTargets: result.dailyTargets.length, targetBonusRewards: result.targetBonusRewards.length, targetNotifications: result.targetNotifications.length, targetSettings: result.targetSettings.length, adminDeviceTokens: result.adminDeviceTokens.length });
      showToast(`✓ Restore aman selesai: ${result.users.length} user, ${result.attendance.length} absen, ${result.transactions.length} transaksi, ${result.dailyTargets.length} target · tidak ada data lama yang dihapus`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      unmuteAdminNotificationsForRestore();
      if (currentUser) bindRealtimeData();
      console.error(e);
      showToast('Gagal restore backup', true);
    }
    setLoading(false);
  }


  async function restoreExcelFromFile() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const file = $('restore-excel-file')?.files?.[0];
    if (!file) return showToast('Pilih file Excel dulu!', true);
    setLoading(true);
    try {
      const XLSX = await ensureXlsxReady();
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array' });

      const findExcelSheetName = (candidates) => candidates.find(n => workbook.Sheets[n]) || candidates.find(n => workbook.Sheets[String(n).toLowerCase()]) || candidates.find(n => workbook.Sheets[String(n).toUpperCase()]) || '';
      const pickSheetRows = (names) => {
        const candidates = Array.isArray(names) ? names : [names];
        const name = findExcelSheetName(candidates);
        const sheet = name ? workbook.Sheets[name] : null;
        if (!sheet) return [];
        return XLSX.utils.sheet_to_json(sheet, { defval: '' });
      };

      const backup = {
        version: 'excel-import',
        exportedAt: new Date().toISOString(),
        data: {
          users: pickSheetRows(['users','user','Users','User']).map(u => ({
            username: sanitizeUsername(u.username),
            name: String(u.name || ''),
            pin: String(u.pin || ''),
            role: String(u.role || 'staff'),
            transactionBonusPercent: Number(u.transactionBonusPercent || u.bonus_transaksi || u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0),
            transactionBonusRate: Number(u.transactionBonusRate || 0) || (Number(u.transactionBonusPercent || u.bonus_transaksi || u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0) / 100),
            closingBonusPerMinute: isDailyRole(String(u.role || u.Role || 'staff')) ? 0 : Number(u.closingBonusPerMinute || u.bonus_closing || 0),
            dailyBonusPercent: Number(u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0),
            dailyBonusRate: Number(u.dailyBonusRate || 0) || (Number(u.dailyBonusPercent || u.daily_percent || u.persen_harian || 0) / 100),
            active: String(u.active ?? u.Active ?? 'true') !== 'false',
            deleted: parseBackupBoolean(u.deleted ?? u.Deleted, false),
            createdAt: u.createdAt || null
          })).filter(u => u.username),
          attendance: pickSheetRows(['attendance','absensi','absen','Attendance']).map(a => ({
            id: String(a.id || ''),
            user: sanitizeUsername(a.user),
            name: String(a.name || a.user || ''),
            dateKey: String(a.dateKey || ''),
            lat: a.lat === '' ? null : Number(a.lat),
            lng: a.lng === '' ? null : Number(a.lng),
            createdAt: a.createdAt || null,
            createdAtMs: Number(a.createdAtMs || 0),
            deleted: parseBackupBoolean(a.deleted ?? a.Deleted, false),
            deletedAtMs: Number(a.deletedAtMs || 0),
            deletedBy: String(a.deletedBy || ''),
            deletedByName: String(a.deletedByName || '')
          })).filter(a => a.user),
          transactions: pickSheetRows(['transactions','transaction','transaksi','Transactions']).map(t => ({
            id: String(t.id || ''),
            user: sanitizeUsername(t.user || t.username || t.User || t.Username),
            name: String(t.name || t.nama || t.Name || t.user || t.username || ''),
            note: String(t.note || t.item || t.keterangan || t.barang || 'Transaksi'),
            amount: Number(t.amount || t.harga || t.nominal || t.total || 0),
            dateKey: String(t.dateKey || t.date || t.tanggal || '').slice(0, 10),
            monthKey: String(t.monthKey || '').slice(0, 7),
            userRole: (t.userRole || t.role || t.Role) ? normalizeRole(t.userRole || t.role || t.Role) : '',
            bonusGroup: sanitizeUsername(t.bonusGroup || t.bonus_type || t.bonusType || t.role || t.userRole || ''),
            bonusRate: readBackupTransactionBonusRate(t, NaN),
            bonusPercent: readBackupTransactionBonusPercent(t, NaN),
            bonusLogicVersion: Number(t.bonusLogicVersion || 3),
            createdAt: t.createdAt || t.time || t.waktu || null,
            createdAtMs: Number(t.createdAtMs || 0),
            deleted: parseBackupBoolean(t.deleted ?? t.Deleted, false),
            deletedAtMs: Number(t.deletedAtMs || 0),
            deletedBy: String(t.deletedBy || ''),
            deletedByName: String(t.deletedByName || '')
          })).filter(t => t.user),
          closings: pickSheetRows(['closings','closing','Closing','riwayat_closing']).map(c => ({
            id: String(c.id || ''),
            dateKey: String(c.dateKey || c.date || c.tanggal || '').slice(0, 10),
            monthKey: String(c.monthKey || '').slice(0, 7),
            user: sanitizeUsername(c.user || c.username || ''),
            name: String(c.name || c.nama || c.user || ''),
            scope: String(c.scope || (c.user || c.username ? 'user' : 'global')),
            closed: String(c.closed ?? 'true') !== 'false',
            canceled: String(c.canceled ?? 'false') === 'true',
            closingTime: String(c.closingTime || c.jam || ''),
            actualClosingTime: String(c.actualClosingTime || ''),
            manualClosingTime: String(c.manualClosingTime || ''),
            deadline: String(c.deadline || c.deadlineTime || c.closingDeadlineTime || ''),
            deadlineTime: getClosingDeadlineTimeLabel(c),
            deadlineHour: getClosingDeadlineParts(c).hour,
            deadlineMinute: getClosingDeadlineParts(c).minute,
            deadlineMinutes: getClosingDeadlineMinutes(c),
            closingDeadlineTime: getClosingDeadlineTimeLabel(c),
            delayMinutes: Number(c.delayMinutes || c.telat || 0),
            totalBonus: Number(c.totalBonus || c.bonus_closing || 0),
            bonusPerUser: Number(c.bonusPerUser || 0),
            bonusByUser: parseBackupJsonObject(c.bonusByUser, {}),
            bonusPerMinuteByUser: parseBackupJsonObject(c.bonusPerMinuteByUser, {}),
            canceledUsers: parseBackupJsonObject(c.canceledUsers, {}),
            closedAtMs: Number(c.closedAtMs || 0),
            closedBy: String(c.closedBy || ''),
            closedByName: String(c.closedByName || '')
          })).filter(c => c.dateKey || c.id),
          manualBonuses: pickSheetRows(['manualBonuses','manual_bonus','Bonus Manual','bonus_manual']).map(b => ({
            id: String(b.id || ''),
            user: sanitizeUsername(b.user || b.username || ''),
            name: String(b.name || b.nama || b.user || ''),
            userRole: (b.userRole || b.role || b.Role) ? normalizeRole(b.userRole || b.role || b.Role) : '',
            role: (b.role || b.userRole || b.Role) ? normalizeRole(b.role || b.userRole || b.Role) : '',
            bonusGroup: sanitizeUsername(b.bonusGroup || b.bonus_type || b.bonusType || b.role || b.userRole || ''),
            amount: Number(b.amount || b.nominal || 0),
            note: String(b.note || b.keterangan || b.reason || 'Bonus manual'),
            dateKey: String(b.dateKey || b.date || b.tanggal || '').slice(0, 10),
            monthKey: String(b.monthKey || '').slice(0, 7),
            type: String(b.type || ''),
            action: String(b.action || ''),
            createdBy: String(b.createdBy || ''),
            createdByName: String(b.createdByName || ''),
            createdAtMs: Number(b.createdAtMs || 0),
            deleted: parseBackupBoolean(b.deleted ?? b.Deleted, false),
            deletedAtMs: Number(b.deletedAtMs || 0),
            deletedBy: String(b.deletedBy || ''),
            deletedByName: String(b.deletedByName || '')
          })).filter(b => b.user),
          unlockRequests: parseBackupSheetRows(pickSheetRows(['unlockRequests','staff_leave_requests','buka_fitur','Buka Fitur'])),
          dailyTargets: parseBackupSheetRows(pickSheetRows(['dailyTargets','daily_targets','target_harian','Target Harian'])),
          targetBonusRewards: parseBackupSheetRows(pickSheetRows(['targetBonusRewards','target_bonus_rewards','reward_target','Reward Target'])),
          targetNotifications: parseBackupSheetRows(pickSheetRows(['targetNotifications','target_notifications','notif_target','Notifikasi Target'])),
          targetSettings: parseBackupSheetRows(pickSheetRows(['targetSettings','target_settings','setting_target','Setting Target'])),
          adminDeviceTokens: parseBackupSheetRows(pickSheetRows(['adminDeviceTokens','admin_device_tokens','token_notifikasi','Token Notifikasi'])),
          bonusSettings: (pickSheetRows(['bonusSettings','bonus_settings','setting_bonus'])[0] || null),
          headerGuideNote: (() => {
            const row = pickSheetRows(['headerGuideNote','header_guide_note','catatan_header','panduan_header'])[0] || null;
            if (!row) return null;
            return { id: HEADER_GUIDE_NOTE_DOC_ID, note: String(row.note || row.catatan || DEFAULT_HEADER_GUIDE_NOTE), updatedAtMs: Number(row.updatedAtMs || 0), updatedBy: String(row.updatedBy || ''), updatedByName: String(row.updatedByName || '') };
          })(),
          staffDailyHomeNote: (() => {
            const row = pickSheetRows(['staffDailyHomeNote','staff_daily_home_note','catatan_home_staff','catatan_staff'])[0] || null;
            if (!row) return null;
            return { id: STAFF_DAILY_NOTE_DOC_ID, enabled: parseBackupBoolean(row.enabled, true), note: String(row.note || row.catatan || DEFAULT_STAFF_DAILY_NOTE), updatedAtMs: Number(row.updatedAtMs || 0), updatedBy: String(row.updatedBy || ''), updatedByName: String(row.updatedByName || '') };
          })(),
          receiptTextSettings: (() => {
            const row = pickSheetRows(['receiptTextSettings','receipt_text_settings','setting_struk','struk'])[0] || null;
            return row ? normalizeBackupReceiptSettings(row) : null;
          })(),
          rismaManualClosingConfig: (() => {
            const row = pickSheetRows(['rismaManualClosingConfig','risma_manual_closing','Closing Manual Risma'])[0] || null;
            if (!row) return null;
            const allowed = String(row.allowedUsers || '').split(/[|,]/).map(s => sanitizeUsername(s)).filter(Boolean);
            return { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: parseBackupBoolean(row.enabled, true), allowedUsers: allowed, allowedNames: parseBackupJsonObject(row.allowedNames, {}) };
          })(),
          auditLogs: pickSheetRows(['auditLogs','audit_logs','log_aktivitas']).map(a => ({
            id: String(a.id || ''),
            action: String(a.action || a.type || ''),
            user: sanitizeUsername(a.user || a.username || ''),
            name: String(a.name || ''),
            createdAtMs: Number(a.createdAtMs || 0),
            detail: (() => { try { return JSON.parse(a.detail || '{}'); } catch(e) { return { raw: String(a.detail || '') }; } })()
          })).filter(a => a.action || a.user)
        }
      };

      if (!isRestoreBackupShapeSafe(backup)) throw new Error('Isi backup Excel kosong / tidak terbaca');
      if (!confirm(getRestoreBackupSummaryText(backup, 'EXCEL'))) {
        setLoading(false);
        return;
      }
      const emergencyFile = await saveEmergencyBackupBeforeRestore('excel');
      if (emergencyFile) console.log('Emergency backup dibuat:', emergencyFile);
      muteAdminNotificationsForRestore(15 * 60 * 1000);
      stopRealtimeData();
      const result = await importBackupData(backup);
      markAdminKnownTransactions(result.transactions || []);
      adminNotifBootstrapped = true;
      unmuteAdminNotificationsForRestore();
      bindRealtimeData();
      if ($('restore-excel-file')) $('restore-excel-file').value = '';
      await logAudit('restore_data', { format: 'excel', users: result.users.length, attendance: result.attendance.length, transactions: result.transactions.length, closings: result.closings.length, manualBonuses: result.manualBonuses.length, unlockRequests: result.unlockRequests.length, dailyTargets: result.dailyTargets.length, targetBonusRewards: result.targetBonusRewards.length, targetNotifications: result.targetNotifications.length, targetSettings: result.targetSettings.length, adminDeviceTokens: result.adminDeviceTokens.length });
      showToast(`✓ Restore Excel aman selesai: ${result.users.length} user, ${result.attendance.length} absen, ${result.transactions.length} transaksi, ${result.dailyTargets.length} target · tidak ada data lama yang dihapus`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      unmuteAdminNotificationsForRestore();
      if (currentUser) bindRealtimeData();
      console.error(e);
      showToast('Gagal restore Excel', true);
    }
    setLoading(false);
  }

  async function normalizeLegacyData() {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    if (!confirm('Normalisasi data lama? Ini akan menambah field tanggal dan membekukan snapshot bonus pada transaksi/closing lama yang belum punya snapshot.')) return;
    setLoading(true);
    try {
      let updated = 0;
      const userSnap = await getDocs(collection(db, 'users'));
      for (const item of userSnap.docs) {
        const data = item.data() || {};
        const patch = {};
        if (data.active === undefined) patch.active = true;
        if (data.username && data.username !== sanitizeUsername(data.username)) patch.username = sanitizeUsername(data.username);
        const role = normalizeRole(data.role || 'staff');
        if (isDailyRole(role) && Number(data.closingBonusPerMinute || 0) !== 0) patch.closingBonusPerMinute = 0;
        if (role === 'admin' && Number(data.closingBonusPerMinute || 0) !== 0) patch.closingBonusPerMinute = 0;
        if (Object.keys(patch).length) {
          await setDoc(doc(db, 'users', item.id), patch, { merge: true });
          updated++;
        }
      }

      const attSnap = await getDocs(collection(db, 'attendance'));
      for (const item of attSnap.docs) {
        const data = item.data() || {};
        const patch = {};
        const ms = getRecordTimeMs(data);
        const dk = extractDateKey(data);
        if (!data.user && data.username) patch.user = sanitizeUsername(data.username);
        if (!data.dateKey && dk) patch.dateKey = dk;
        if (!data.createdAtMs && ms) patch.createdAtMs = ms;
        if (Object.keys(patch).length) {
          await setDoc(doc(db, 'attendance', item.id), patch, { merge: true });
          updated++;
        }
      }

      const trxSnap = await getDocs(collection(db, 'transactions'));
      for (const item of trxSnap.docs) {
        const data = item.data() || {};
        const patch = {};
        const ms = getRecordTimeMs(data);
        const dk = extractDateKey(data);
        if (!data.dateKey && dk) patch.dateKey = dk;
        if (!data.monthKey && dk) patch.monthKey = dk.slice(0, 7);
        if (!data.createdAtMs && ms) patch.createdAtMs = ms;
        if (data.deleted === undefined) patch.deleted = false;
        const txUser = sanitizeUsername(data.user || data.username || '');
        if (txUser && (!hasBonusValue(data.bonusRate) && !hasBonusValue(data.bonusPercent))) {
          const user = getUserByUsername(txUser);
          const userRole = normalizeRole(data.userRole || data.role || user?.role || 'staff');
          const rate = getUserTransactionBonusRate(user || txUser);
          patch.userRole = userRole;
          patch.bonusGroup = userRole === 'harian' ? 'harian' : 'staff';
          patch.bonusRate = rate;
          patch.bonusPercent = Number((rate * 100).toFixed(3));
          patch.bonusLogicVersion = 3;
        }
        if (Object.keys(patch).length) {
          await setDoc(doc(db, 'transactions', item.id), patch, { merge: true });
          updated++;
        }
      }

      const closingSnap = await getDocs(collection(db, 'closings'));
      for (const item of closingSnap.docs) {
        const data = item.data() || {};
        if (data.type === 'bonus_settings' || item.id === '__bonus_settings' || data.dateKey === '__bonus_settings') continue;
        const patch = {};
        if (data.closed === true) {
          const delay = Number(data.delayMinutes || 0);
          const storedPerMinute = Number(data.bonusPerMinute);
          if (!Number.isFinite(storedPerMinute) || storedPerMinute < 0) patch.bonusPerMinute = getClosingBonusPerMinute();
          if (!data.bonusByUser || typeof data.bonusByUser !== 'object') {
            const totalUsers = Number(data.totalUsers || 0);
            const totalBonus = Number(data.totalBonus || 0);
            if (Number.isFinite(totalUsers) && totalUsers > 0 && Number.isFinite(totalBonus) && totalBonus > 0) {
              patch.bonusPerUser = Math.round(totalBonus / totalUsers);
            } else if (Number.isFinite(delay) && delay > 0) {
              patch.bonusPerUser = Math.round(delay * (Number.isFinite(storedPerMinute) && storedPerMinute >= 0 ? storedPerMinute : getClosingBonusPerMinute()));
            }
          }
          if (!data.bonusLogicVersion) patch.bonusLogicVersion = 3;
        }
        if (Object.keys(patch).length) {
          await setDoc(doc(db, 'closings', item.id), patch, { merge: true });
          updated++;
        }
      }

      await logAudit('normalize_legacy_data', { updated, bonusSnapshot: true });
      showToast(`✓ Normalisasi selesai (${updated} update)`);
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal normalisasi data', true);
    }
    setLoading(false);
  }



  function toggleAdminMoreMenu() {
    adminMoreOpen = !adminMoreOpen;
    renderSettingsSummary();
  }

  const ADMIN_PANEL_STATE_KEY = 'rocky_admin_setting_panels_v1';
  const ADMIN_PANEL_KEYS = ['attendance','manual_bonus','receipt_text','daily_employee','user_management','backup_restore','deleted_data'];
  let adminSettingPanels = (() => {
    try { return JSON.parse(localStorage.getItem(ADMIN_PANEL_STATE_KEY) || '{}') || {}; }
    catch (e) { return {}; }
  })();

  function isAdminSettingPanelOpen(key) {
    return adminSettingPanels[key] === true;
  }

  function saveAdminPanelState() {
    localStorage.setItem(ADMIN_PANEL_STATE_KEY, JSON.stringify(adminSettingPanels));
  }

  function toggleAdminSettingPanel(key) {
    const willOpen = !isAdminSettingPanelOpen(key);
    // Accordion mode: hanya satu panel berat yang dibuka supaya halaman admin tetap ringan.
    ADMIN_PANEL_KEYS.forEach(k => adminSettingPanels[k] = false);
    adminSettingPanels[key] = willOpen;
    saveAdminPanelState();
    renderSettingsSummary();
  }

  function closeAdminSettingPanels() {
    ADMIN_PANEL_KEYS.forEach(k => adminSettingPanels[k] = false);
    saveAdminPanelState();
    renderSettingsSummary();
  }

  function renderAdminToggleSection(key, title, badgeHtml = '', bodyRenderer = null, icon = 'fa-layer-group', subtitle = '') {
    const open = isAdminSettingPanelOpen(key);
    return `
      <div class="card" style="padding:0;margin-top:10px;overflow:hidden;border-color:${open ? 'rgba(91,143,255,.26)' : 'var(--border)'};box-shadow:${open ? '0 10px 28px rgba(0,0,0,.16)' : 'none'}">
        <button onclick="toggleAdminSettingPanel('${escapeHtml(key)}')" class="btn" style="width:100%;padding:13px 14px;background:${open ? 'var(--accent-dim)' : 'transparent'};color:var(--text);justify-content:space-between;text-align:left;border:none;border-radius:0">
          <span style="display:flex;align-items:center;gap:11px;min-width:0;flex:1">
            <span style="width:36px;height:36px;border-radius:12px;background:${open ? 'var(--accent)' : 'var(--surface)'};border:1px solid ${open ? 'rgba(255,255,255,.12)' : 'var(--border)'};display:flex;align-items:center;justify-content:center;color:${open ? 'white' : 'var(--accent)'};flex-shrink:0"><i class="fas ${icon}" style="font-size:13px"></i></span>
            <span style="min-width:0;flex:1">
              <span style="display:block;font-size:13px;font-weight:900;letter-spacing:-.01em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(title)}</span>
              <span style="display:block;font-size:10.5px;color:var(--text-soft);margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(subtitle || (open ? 'Terbuka · ketuk untuk tutup' : 'Tertutup · ketuk untuk buka'))}</span>
            </span>
          </span>
          <span style="display:flex;align-items:center;gap:8px;flex-shrink:0">${badgeHtml}<span style="width:27px;height:27px;border-radius:10px;background:var(--surface);border:1px solid var(--border);display:flex;align-items:center;justify-content:center"><i class="fas ${open ? 'fa-chevron-up' : 'fa-chevron-down'}" style="color:var(--text-soft);font-size:10px"></i></span></span>
        </button>
        ${open && typeof bodyRenderer === 'function' ? `<div style="padding:12px 14px 14px;border-top:1px solid var(--border);background:rgba(255,255,255,.015)">${bodyRenderer()}</div>` : ''}
      </div>`;
  }

  function renderAdminAttendancePerformanceBody() {
    const rows = getStaffBonusUsers().map(u => ({ user: u, perf: getMonthlyAttendancePerformance(u.username) }));
    return `
      <div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span class="status-pill status-ok">Batas 07:20</span></div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${rows.length ? rows.map(row => {
          const perf = row.perf;
          const good = perf ? perf.isGood : false;
          return `
            <div style="display:flex;align-items:center;gap:12px;padding:11px 12px;border:1px solid var(--border);border-radius:13px;background:var(--surface)">
              <div style="width:38px;height:38px;border-radius:12px;background:${perf ? (good ? 'var(--green-dim)' : 'var(--red-dim)') : 'var(--surface)'};display:flex;align-items:center;justify-content:center;flex-shrink:0;color:${perf ? (good ? 'var(--green)' : 'var(--red)') : 'var(--text-soft)'}"><i class="fas fa-user-clock"></i></div>
              <div style="min-width:0;flex:1">
                <div style="font-size:13px;font-weight:800;line-height:1.25">${escapeHtml(row.user.name || row.user.username)}</div>
                <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">${perf ? `${perf.count}x absen bulan ini · rata-rata ${perf.avgLabel}` : 'Belum ada data absen bulan ini'}</div>
              </div>
              <span class="status-pill ${perf && good ? 'status-ok' : 'status-warn'}" style="font-size:9.5px;padding:4px 8px;white-space:nowrap">${perf ? (good ? 'Baik' : 'Perlu ditingkatkan') : 'Belum ada'}</span>
            </div>`;
        }).join('') : `<div style="font-size:12px;color:var(--text-soft)">Belum ada staff aktif.</div>`}
      </div>
      <p style="font-size:11px;color:var(--text-soft);margin-top:10px">Perhitungan memakai rata-rata jam absen bulan berjalan. Jam 07:20 atau lebih awal = performa baik.</p>`;
  }

  async function saveUserBonusControl(username) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const safeUsername = sanitizeUsername(username || '');
    const user = getUserByUsername(safeUsername);
    if (!user) return showToast('User tidak ditemukan', true);
    const role = normalizeRole(user.role || 'staff');
    if (!['staff','harian'].includes(role)) return showToast('Kontrol bonus khusus hanya untuk staff/karyawan harian', true);
    const trxRaw = String($(`bonus-ctl-trx-${safeUsername}`)?.value || '').replace(',', '.').trim();
    const closingRaw = String($(`bonus-ctl-closing-${safeUsername}`)?.value || '').replace(/\D/g, '').trim();
    const trxPercent = Number(trxRaw);
    const closingPerMinute = role === 'harian' ? 0 : (closingRaw === '' ? getClosingBonusPerMinute() : Number(closingRaw));
    if (!Number.isFinite(trxPercent) || trxPercent < 0 || trxPercent > 100) return showToast('Persen bonus transaksi tidak valid', true);
    if (role !== 'harian' && (!Number.isFinite(closingPerMinute) || closingPerMinute < 0)) return showToast('Bonus closing per menit tidak valid', true);
    const pin = await askPin(`Simpan bonus khusus untuk ${user.name || safeUsername}?
Bonus transaksi: ${trxPercent}%
Bonus closing: ${role === 'harian' ? 'Terkunci 0' : 'Rp ' + formatRupiah(closingPerMinute) + '/menit'}

Masukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const payload = {
        transactionBonusRate: trxPercent / 100,
        transactionBonusPercent: trxPercent,
        closingBonusPerMinute: role === 'harian' ? 0 : closingPerMinute,
        dailyBonusRate: role === 'harian' ? trxPercent / 100 : 0,
        dailyBonusPercent: role === 'harian' ? trxPercent : 0,
        bonusControlVersion: 3,
        updatedAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, 'users', safeUsername), payload, { merge: true });
      upsertCachedUserFromServer(safeUsername, { ...user, ...payload, username: safeUsername, role });
      await logAudit('user_bonus_control_update', { username: safeUsername, name: user.name || safeUsername, role, transactionBonusPercent: trxPercent, closingBonusPerMinute: payload.closingBonusPerMinute });
      showToast('✓ Bonus khusus user disimpan');
      await renderSettingsSummary();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan bonus khusus user', true);
    }
    setLoading(false);
  }

  function renderDailyEmployeeControlBody() {
    const bonusUsers = realActiveUsers().filter(u => ['staff','harian'].includes(normalizeRole(u.role || 'staff')));
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px">
        <p style="font-size:11px;color:var(--text-soft);margin:0">Kontrol bonus transaksi langsung per user. Untuk karyawan harian, bonus closing otomatis terkunci 0 karena tidak dapat bonus closing.</p>
        <span class="status-pill status-ok">${bonusUsers.length} user</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:9px">
        ${bonusUsers.length ? bonusUsers.map(u => {
          const username = sanitizeUsername(u.username || '');
          const role = normalizeRole(u.role || 'staff');
          const daily = role === 'harian';
          const trxPercent = getUserTransactionBonusPercent(u);
          const closingMinute = daily ? 0 : getUserClosingBonusPerMinute(u);
          const todaySalary = daily ? getDailyEmployeeTodaySalary(username) : null;
          const sub = daily
            ? `${trxPercent}% dari omzet harian · gaji hari ini Rp ${formatRupiah(todaySalary.salary)} (${todaySalary.items.length} transaksi)`
            : `${trxPercent}% transaksi · closing Rp ${formatRupiah(closingMinute)}/menit`;
          return `<div style="padding:11px 12px;border:1px solid var(--border);border-radius:14px;background:var(--surface)">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:9px">
              <div style="min-width:0"><div style="font-size:13px;font-weight:850">${escapeHtml(u.name || username)}</div><div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">${escapeHtml(sub)}</div></div>
              <span class="status-pill ${daily ? 'status-warn' : 'status-ok'}" style="font-size:9.5px;padding:4px 8px;white-space:nowrap">${daily ? 'HARIAN' : 'STAFF'}</span>
            </div>
            <div class="bonus-control-compact-row">
              <div class="bonus-control-field">
                <label>Bonus Transaksi (%)</label>
                <input id="bonus-ctl-trx-${escapeHtml(username)}" class="g-input bonus-control-input" inputmode="decimal" value="${escapeHtml(trxPercent)}" placeholder="1.5" />
              </div>
              <div class="bonus-control-field">
                <label>Bonus Closing / Menit</label>
                <input id="bonus-ctl-closing-${escapeHtml(username)}" class="g-input bonus-control-input" inputmode="numeric" value="${escapeHtml(closingMinute)}" ${daily ? 'disabled' : ''} placeholder="${daily ? 'Terkunci' : '100'}" />
              </div>
              <button onclick="saveUserBonusControl('${escapeHtml(username)}')" class="btn btn-primary bonus-save-btn"><i class="fas fa-floppy-disk"></i> Simpan</button>
            </div>
            <div style="display:flex;align-items:center;gap:6px;margin-top:7px">
              <span style="font-size:10.5px;color:${daily ? 'var(--amber)' : 'var(--text-soft)'};line-height:1.3">${daily ? '<i class="fas fa-lock"></i> Closing terkunci untuk harian' : '<i class="fas fa-lock-open"></i> Closing aktif untuk staff'}</span>
            </div>
          </div>`;
        }).join('') : `<div style="font-size:12px;color:var(--text-soft);padding:10px 0">Belum ada user staff/karyawan harian aktif.</div>`}
      </div>`;
  }

  function renderUserManagementBody(userCount) {
    return `
      <div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span class="status-pill status-ok">${userCount} user aktif</span></div>
      <div style="display:grid;grid-template-columns:1fr;gap:9px">
        <select id="admin-user-select" class="g-input" onchange="fillAdminUserForm(this.value)">
          <option value="">Pilih user untuk edit / nonaktifkan</option>
          ${sortUsers(cachedUsers).map(u => `<option value="${escapeHtml(u.username)}">${escapeHtml(u.name)} (@${escapeHtml(u.username)}) · ${escapeHtml(getRoleDisplayName(u.role || 'staff').toUpperCase())}${isDummyUser(u) ? ' · TRIAL' : ''} ${isUserActive(u) ? '' : '· NONAKTIF'}</option>`).join('')}
        </select>
        <input id="admin-user-username" class="g-input" placeholder="username baru / username user" />
        <input id="admin-user-name" class="g-input" placeholder="nama user" />
        <input id="admin-user-pin" type="tel" class="g-input" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" placeholder="PIN user (min 3)" />
        <select id="admin-user-role" class="g-input" onchange="updateAdminUserClosingLock()">
          <option value="staff">staff</option>
          <option value="harian">karyawan harian</option>
          <option value="admin">admin</option>
        </select>
        <input id="admin-user-bonus-percent" class="g-input" inputmode="decimal" placeholder="Bonus transaksi user (%) contoh staff 1.5 / harian 10" />
        <input id="admin-user-closing-minute" class="g-input" inputmode="numeric" pattern="[0-9]*" placeholder="Bonus closing user / menit contoh 100" />
        <div id="admin-user-closing-note" style="font-size:10.5px;color:var(--text-soft);margin-top:-4px;line-height:1.35"></div>
        <label style="display:flex;align-items:flex-start;gap:9px;padding:10px 11px;border:1px solid rgba(245,158,11,.32);border-radius:12px;background:rgba(245,158,11,.10);font-size:11px;color:var(--text);line-height:1.35">
          <input id="admin-user-dummy" type="checkbox" style="margin-top:2px;accent-color:#f59e0b" />
          <span><b>Akun Dummy / Mode Trial</b><br><span style="color:var(--text-soft)">Data transaksi, absen, dan bonus dari akun ini diberi cap trial dan tidak masuk laporan utama/target real. Target trial bawaan Rp 10.000, bonus Rp 1.000.</span></span>
        </label>
        <div style="padding:9px 11px;border:1px solid var(--border);border-radius:12px;background:var(--surface);font-size:10.5px;color:var(--text-soft);line-height:1.35">Bonus sekarang <b>per user</b>. Setiap transaksi dan closing baru menyimpan snapshot persen/nominal saat dibuat, jadi update bonus berikutnya tidak mengubah hitungan transaksi/closing lama. Role <b>staff</b> dan <b>karyawan harian</b> tetap dikunci saling eksklusif. Untuk <b>karyawan harian</b>, bonus closing otomatis terkunci 0.</div>
        ${renderDeviceLockRows()}
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
          <button onclick="saveAdminUser()" class="btn btn-primary" style="padding:12px;font-size:12px">Simpan User</button>
          <button onclick="clearAdminUserForm()" class="btn btn-glass" style="padding:12px;font-size:12px">Kosongkan</button>
          <button onclick="deleteAdminUser()" class="btn btn-danger" style="padding:12px;font-size:12px">Nonaktifkan</button>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <button onclick="hardDeleteAdminUser()" class="btn btn-danger" style="padding:12px;font-size:12px">Hapus Permanen User</button>
          <button onclick="fillAdminUserForm('')" class="btn btn-glass" style="padding:12px;font-size:12px">Pilih dari daftar</button>
        </div>
      </div>
      <p style="font-size:11px;color:var(--text-soft);margin-top:10px">Default aman: user dinonaktifkan dulu. Hapus permanen hanya untuk akun yang memang sudah nonaktif.</p>`;
  }

  function renderBackupRestoreBody() {
    return `
      <div style="display:flex;justify-content:flex-end;margin-bottom:10px"><span class="status-pill status-warn">Restore Otomatis</span></div>
      <div style="display:flex;flex-direction:column;gap:9px">
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
          <button onclick="downloadBackup('json')" class="btn btn-primary" style="padding:12px;font-size:12px"><i class="fas fa-download"></i> Backup JSON</button>
          <button onclick="downloadBackup('xlsx')" class="btn btn-glass" style="padding:12px;font-size:12px"><i class="fas fa-file-excel"></i> Backup Excel</button>
          <button onclick="resetAllAppData()" class="btn btn-danger" style="padding:12px;font-size:12px"><i class="fas fa-trash"></i> Reset Data</button>
        </div>
        <div style="border:1px dashed var(--border);border-radius:14px;padding:12px;background:var(--surface)">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
            <div style="width:36px;height:36px;border-radius:11px;background:var(--amber-dim);display:flex;align-items:center;justify-content:center;color:var(--amber);flex-shrink:0"><i class="fas fa-wand-magic-sparkles"></i></div>
            <div style="min-width:0;flex:1"><div style="font-size:13px;font-weight:800">Restore Otomatis</div><div style="font-size:11px;color:var(--text-soft);margin-top:2px">Satu input baca JSON / XLS / XLSX, termasuk setting baru.</div></div>
          </div>
          <input id="restore-pro-file" type="file" class="g-input" accept=".json,.xlsx,.xls,application/json,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel" onchange="handleRestoreProFile(event)" />
          <div id="restore-pro-status" style="font-size:11.5px;font-weight:600;margin:9px 2px 0;display:flex;align-items:center;gap:6px"><span style="color:var(--text-soft)"><i class="fas fa-circle-info"></i> Belum ada file dipilih</span></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px">
            <button id="restore-pro-run-btn" onclick="restoreProFromFile()" disabled class="btn btn-primary" style="padding:12px;font-size:12px"><i class="fas fa-file-import"></i> Restore Otomatis</button>
            <button onclick="clearRestoreProFile()" class="btn btn-glass" style="padding:12px;font-size:12px"><i class="fas fa-xmark"></i> Bersihkan File</button>
          </div>
        </div>
        <button onclick="normalizeLegacyData()" class="btn btn-glass" style="padding:12px;font-size:12px"><i class="fas fa-wand-magic-sparkles"></i> Normalisasi Data Lama</button>
      </div>
      <p style="font-size:11px;color:var(--text-soft);margin-top:10px">Alur aman: backup lengkap dari server dulu → reset bila perlu → restore → cek hasil → normalisasi data lama. Reset menghapus data operasional, tetapi semua akun user/admin tetap disimpan.</p>`;
  }

  function renderDeletedDataBody(filteredDeletedTransactions, visibleDeletedTransactions, hasMoreDeleted, deletedTransactions) {
    return `
      <div style="display:flex;justify-content:flex-end;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px">
        <span class="status-pill status-warn">${filteredDeletedTransactions.length} hasil filter</span>
        <span class="user-chip">${deletedTransactions.length} total</span>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
        <input value="${escapeHtml(recycleSearch)}" oninput="setRecycleSearch(this.value)" class="g-input" placeholder="Cari note / user / id..." />
        <select id="recycle-user-filter" class="g-input" onchange="setRecycleUserFilter(this.value)">${getUserOptionsHtml(true)}</select>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:10px">
        <button onclick="bulkRestoreDeletedTransactions()" class="btn btn-glass" style="padding:11px;font-size:11px">Pulihkan Semua</button>
        <button onclick="bulkHardDeleteDeletedTransactions()" class="btn btn-danger" style="padding:11px;font-size:11px">Hapus Permanen Semua</button>
        <button onclick="resetRecycleFilters()" class="btn btn-glass" style="padding:11px;font-size:11px">Reset Filter</button>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;max-height:360px;overflow-y:auto">
        ${visibleDeletedTransactions.length ? visibleDeletedTransactions.map(t => `
          <div style="padding:10px 12px;border:1px solid var(--border);border-radius:12px;background:var(--surface)">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
              <div style="min-width:0">
                <div style="font-size:12px;font-weight:700">Rp ${formatRupiah(t.amount || 0)} · ${escapeHtml(t.name || t.user || '-')}</div>
                <div style="font-size:10px;color:var(--text-soft);margin-top:3px">${escapeHtml(t.note || 'Transaksi')} · ${escapeHtml(t.user || '-')}</div>
                <div style="font-size:10px;color:var(--text-ghost);margin-top:3px">ID: ${escapeHtml(t.id || '-')} · Hapus: ${escapeHtml(t.deletedByName || t.deletedBy || '-')}</div>
              </div>
              <div style="display:flex;flex-direction:column;gap:6px;flex-shrink:0">
                <button onclick="restoreDeletedTransaction('${escapeHtml(t.id || '')}')" class="btn btn-glass" style="padding:8px 10px;font-size:11px">Pulihkan</button>
                <button onclick="hardDeleteTransaction('${escapeHtml(t.id || '')}')" class="btn btn-danger" style="padding:8px 10px;font-size:11px">Permanen</button>
              </div>
            </div>
          </div>
        `).join('') : `<div style="font-size:12px;color:var(--text-soft)">Belum ada transaksi terhapus sesuai filter.</div>`}
      </div>
      ${hasMoreDeleted ? `<button onclick="increaseRecycleBinLimit()" class="btn btn-glass" style="width:100%;margin-top:10px;padding:11px;font-size:12px">Muat 20 data terhapus lagi</button>` : ''}
      <p style="font-size:11px;color:var(--text-soft);margin-top:10px">Hapus biasa hanya memindahkan data ke recycle bin. Gunakan filter untuk cari data tertentu, atau hapus/pulihkan semua hasil filter sekaligus.</p>`;
  }

  function isFeatureUnlockRequest(row) {
    return String(row?.requestKind || '') === 'unlock'
      || String(row?.action || row?.type || '') === 'feature_unlock_request'
      || row?.featureUnlockRequest === true;
  }
  function unlockStatus(row) {
    const status = sanitizeUsername(row?.status || 'pending');
    if (status === 'approved' || status === 'diterima') return 'approved';
    if (status === 'rejected' || status === 'ditolak') return 'rejected';
    if (status === 'cancelled' || status === 'batal') return 'cancelled';
    return 'pending';
  }
  function unlockStatusText(row) {
    const status = unlockStatus(row);
    if (status === 'approved') return 'Dibuka';
    if (status === 'rejected') return 'Ditolak';
    if (status === 'cancelled') return 'Dibatalkan';
    return 'Menunggu';
  }
  function unlockStatusClass(row) {
    const status = unlockStatus(row);
    return status === 'approved' ? 'status-ok' : 'status-warn';
  }
  function unlockTimeMs(row) {
    return Number(row?.createdAtMs || row?.updatedAtMs || row?.reviewedAtMs || row?.approvedAtMs || row?.rejectedAtMs || 0);
  }
  function formatUnlockTime(row) {
    const n = unlockTimeMs(row);
    if (!n) return '-';
    return new Date(n).toLocaleString('id-ID', { timeZone:'Asia/Jakarta', day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' }).replace(/\./g, ':');
  }
  function isMissedAttendanceUnlock(row) {
    const kind = sanitizeUsername(row?.lockKind || row?.reasonKind || row?.unlockKind || '');
    return isFeatureUnlockRequest(row) && (row?.missingAttendance === true || kind === 'missed_attendance' || kind === 'absen_kemarin' || String(row?.source || '') === 'staff_app_missed_attendance_unlock');
  }
  function unlockRequestRows() {
    return (cachedUnlockRequests || [])
      .filter(row => isFeatureUnlockRequest(row) && !isRecordDeleted(row))
      .sort((a, b) => unlockTimeMs(b) - unlockTimeMs(a));
  }
  function pendingUnlockCount() {
    return unlockRequestRows().filter(row => unlockStatus(row) === 'pending').length;
  }
  function unlockRequestMeta(row) {
    return {
      missed: String(row?.missedDate || row?.missingDate || row?.previousDate || '').slice(0, 10),
      target: String(row?.targetDate || row?.workDate || row?.dateKey || '').slice(0, 10)
    };
  }
  function mergeUnlockRequestCache(id, patch = {}) {
    const safeId = String(id || '');
    if (!safeId) return;
    const idx = (cachedUnlockRequests || []).findIndex(row => String(row.id) === safeId);
    if (idx >= 0) cachedUnlockRequests[idx] = { ...cachedUnlockRequests[idx], ...patch, id: safeId };
    else cachedUnlockRequests = [{ id: safeId, ...patch }, ...(cachedUnlockRequests || [])];
    cachedUnlockRequests = unlockRequestRows();
  }
  function renderUnlockRequestCard(row) {
    const meta = unlockRequestMeta(row);
    const pending = unlockStatus(row) === 'pending';
    const username = sanitizeUsername(row.user || row.username || '');
    const user = getUserByUsername(username);
    const title = isMissedAttendanceUnlock(row) ? 'Tidak absen hari sebelumnya' : 'Minta buka fitur';
    const reason = String(row.reason || row.note || '-');
    const name = row.name || user?.name || username || 'Staff';
    const id = escapeHtml(row.id || '');
    const actions = pending
      ? `<div style="display:flex;gap:6px;justify-content:flex-end;margin-top:8px;flex-wrap:wrap">
          <button onclick="reviewUnlockRequestFromServer('${id}','approved')" class="btn btn-primary" style="width:34px;height:34px;padding:0;border-radius:10px" title="Buka"><i class="fas fa-check"></i></button>
          <button onclick="reviewUnlockRequestFromServer('${id}','rejected')" class="btn btn-danger" style="width:34px;height:34px;padding:0;border-radius:10px" title="Tolak"><i class="fas fa-xmark"></i></button>
          <button onclick="deleteUnlockRequestFromServer('${id}')" class="btn btn-danger" style="width:34px;height:34px;padding:0;border-radius:10px" title="Hapus"><i class="fas fa-trash"></i></button>
        </div>`
      : `<div style="display:flex;gap:6px;justify-content:flex-end;margin-top:8px"><button onclick="deleteUnlockRequestFromServer('${id}')" class="btn btn-danger" style="width:34px;height:34px;padding:0;border-radius:10px" title="Hapus"><i class="fas fa-trash"></i></button></div>`;
    return `
      <div class="card" style="padding:11px 12px;margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start">
          <div style="min-width:0">
            <div style="font-size:13px;font-weight:850;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(name)}</div>
            <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">@${escapeHtml(username || '-')} - ${escapeHtml(title)}</div>
            <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">${meta.missed ? `Tidak absen ${escapeHtml(formatDateLabel(meta.missed))}` : ''}${meta.target ? `${meta.missed ? ' - ' : ''}Target ${escapeHtml(formatDateLabel(meta.target))}` : ''}</div>
            <div style="font-size:10.5px;color:var(--text-soft);margin-top:3px">Alasan: ${escapeHtml(reason)}</div>
            <div style="font-size:10px;color:var(--text-ghost);margin-top:3px">Dikirim: ${escapeHtml(formatUnlockTime(row))}</div>
          </div>
          <div style="flex-shrink:0;text-align:right;min-width:106px">
            <span class="status-pill ${unlockStatusClass(row)}" style="font-size:10px;padding:5px 9px">${escapeHtml(unlockStatusText(row))}</span>
            ${actions}
          </div>
        </div>
      </div>`;
  }
  function renderUnlockRequestsBody() {
    const rows = unlockRequestRows();
    const pending = rows.filter(row => unlockStatus(row) === 'pending').length;
    const approved = rows.filter(row => unlockStatus(row) === 'approved').length;
    const rejected = rows.filter(row => unlockStatus(row) === 'rejected').length;
    return `
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:10px">
        <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">Menunggu</p><p style="font-family:var(--num-font);font-size:18px;font-weight:850;color:var(--amber);line-height:1">${pending}</p></div>
        <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">Dibuka</p><p style="font-family:var(--num-font);font-size:18px;font-weight:850;color:var(--green);line-height:1">${approved}</p></div>
        <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">Ditolak</p><p style="font-family:var(--num-font);font-size:18px;font-weight:850;color:var(--red);line-height:1">${rejected}</p></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:8px;margin-bottom:10px">
        <button onclick="manualRefreshData()" class="btn btn-glass" style="padding:9px 11px;font-size:11px"><i class="fas fa-rotate"></i> Refresh</button>
      </div>
      ${rows.length ? rows.map(renderUnlockRequestCard).join('') : `<div class="card" style="padding:16px;color:var(--text-soft);font-size:12px">Belum ada permintaan buka fitur.</div>`}
      <p style="font-size:11px;color:var(--text-soft);margin-top:10px">Riwayat tetap tampil setelah dibuka atau ditolak. Tombol hapus hanya menyembunyikan riwayat request.</p>`;
  }
  async function reviewUnlockRequestFromServer(id, status) {
    const row = unlockRequestRows().find(item => String(item.id) === String(id));
    if (!row) return showToast('Request tidak ditemukan', true);
    const next = status === 'approved' ? 'approved' : 'rejected';
    const label = next === 'approved' ? 'Buka fitur' : 'Tolak request';
    const pin = await askPin(`${label} untuk ${row.name || getUserByUsername(row.user)?.name || row.user || 'staff'}?\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      const nowMs = Date.now();
      const patch = {
        status: next,
        adminRead: true,
        reviewedAt: serverTimestamp(),
        reviewedAtMs: nowMs,
        reviewedBy: currentUser.username,
        reviewedByName: currentUser.name,
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      if (next === 'approved') Object.assign(patch, { approvedAt: serverTimestamp(), approvedAtMs: nowMs, approvedBy: currentUser.username, approvedByName: currentUser.name, featureOpened: true });
      else Object.assign(patch, { rejectedAt: serverTimestamp(), rejectedAtMs: nowMs, rejectedBy: currentUser.username, rejectedByName: currentUser.name, featureOpened: false });
      await setDoc(doc(db, STAFF_UNLOCK_TABLE, id), patch, { merge: true });
      mergeUnlockRequestCache(id, { ...row, ...patch });
      await notifyStaffUnlockReviewFromServer({ ...row, ...patch, id }, next);
      showToast(next === 'approved' ? 'Fitur staff dibuka' : 'Request ditolak');
      openAdminProPage('unlock_requests');
    } catch (e) {
      showToast(e?.message || 'Gagal update request', true);
    } finally {
      setLoading(false);
    }
  }
  async function deleteUnlockRequestFromServer(id) {
    const row = (cachedUnlockRequests || []).find(item => String(item.id) === String(id));
    if (!row || isRecordDeleted(row)) return showToast('Request tidak ditemukan', true);
    const username = sanitizeUsername(row.user || row.username || '');
    const pin = await askPin(`Hapus riwayat buka fitur untuk ${row.name || getUserByUsername(username)?.name || username || 'staff'}?\nStatus: ${unlockStatusText(row)}\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    if (!confirm('Yakin hapus riwayat buka fitur ini? Status buka/tolak yang sudah dibuat tidak diubah.')) return;
    setLoading(true);
    try {
      const nowMs = Date.now();
      const patch = {
        deleted: true,
        adminRead: true,
        deletedAt: serverTimestamp(),
        deletedAtMs: nowMs,
        deletedBy: currentUser.username,
        deletedByName: currentUser.name,
        updatedAt: serverTimestamp(),
        updatedAtMs: nowMs,
        updatedBy: currentUser.username,
        updatedByName: currentUser.name
      };
      await setDoc(doc(db, STAFF_UNLOCK_TABLE, id), patch, { merge: true });
      mergeUnlockRequestCache(id, { ...row, ...patch });
      showToast('Riwayat buka fitur dihapus');
      openAdminProPage('unlock_requests');
    } catch (e) {
      showToast(e?.message || 'Gagal hapus request', true);
    } finally {
      setLoading(false);
    }
  }


  function renderAdminProPageBody(key) {
    if (key === 'attendance') return renderAdminAttendancePerformanceBody();
    if (key === 'manual_bonus') return renderManualBonusCard();
    if (key === 'unlock_requests') return renderUnlockRequestsBody();
    if (key === 'receipt_text') return renderReceiptTextSettingsBody();
    if (key === 'daily_employee') return renderDailyEmployeeControlBody();
    if (key === 'user_management') return renderUserManagementBody(activeUsers().length);
    if (key === 'backup_restore') return renderBackupRestoreBody();
    if (key === 'deleted_data') {
      const deletedTransactions = getDeletedTransactions();
      const filteredDeletedTransactions = getFilteredDeletedTransactions();
      const visibleDeletedTransactions = filteredDeletedTransactions.slice(0, recycleBinLimit);
      const hasMoreDeleted = filteredDeletedTransactions.length > visibleDeletedTransactions.length;
      return renderDeletedDataBody(filteredDeletedTransactions, visibleDeletedTransactions, hasMoreDeleted, deletedTransactions);
    }
    return '<div class="card" style="padding:16px;color:var(--text-soft)">Menu tidak ditemukan.</div>';
  }

  function openAdminProPage(key) {
    if (!isAdmin()) return router.navigate('home');
    const titles = {
      attendance:'Performa Absen Staff', manual_bonus:'Tambah Bonus Manual', unlock_requests:'Buka Fitur Staff', receipt_text:'Setting Tulisan Struk', daily_employee:'Kontrol Bonus Khusus User', user_management:'Manajemen User', backup_restore:'Backup, Reset & Restore', deleted_data:'Data Terhapus'
    };
    const safeKey = String(key || '').trim();
    if (!adminProCurrentPageKey) {
      const last = appPageHistoryStack[appPageHistoryStack.length - 1];
      if (last !== 'settings') appPageHistoryStack.push('settings');
      if (appPageHistoryStack.length > 20) appPageHistoryStack = appPageHistoryStack.slice(-20);
    }
    adminProCurrentPageKey = safeKey;
    currentPage = `adminPro:${safeKey}`;
    const content = $('page-content');
    const nav = $('bottom-nav');
    if (nav) nav.style.display = 'flex';
    setActiveNav('settings');
    content.innerHTML = `
      <div class="page-pad">
        <div style="padding:34px 0 14px;display:flex;align-items:center;gap:10px" class="page-in">
          <button onclick="router.navigate('settings')" class="btn btn-glass" style="width:38px;height:38px;padding:0;border-radius:12px"><i class="fas fa-arrow-left"></i></button>
          <div style="min-width:0;flex:1">
            <p class="page-title">${escapeHtml(titles[key] || 'Admin Pro')}</p>
            <p class="page-subtitle">Halaman terpisah supaya ringan dan tidak menumpuk.</p>
          </div>
        </div>
        <div class="page-in s1" style="padding-bottom:96px">${renderAdminProPageBody(safeKey)}</div>
      </div>`;
    if (safeKey === 'backup_restore') updateRestoreProStatus();
    if (safeKey === 'deleted_data' && $('recycle-user-filter')) $('recycle-user-filter').value = recycleUserFilter;
  }

  async function renderSettingsSummary() {
    const info = $('settings-summary');
    if (!info || !currentUser) return;
    const userCount = activeUsers().length;
    const inactiveUsers = sortUsers((cachedUsers || []).filter(u => !isUserActive(u)));
    const visibleInactiveUsers = inactiveUsers.slice(0, inactiveUserLimit);
    const hasMoreInactiveUsers = inactiveUsers.length > visibleInactiveUsers.length;
    const deletedTransactions = getDeletedTransactions();
    const filteredDeletedTransactions = getFilteredDeletedTransactions();
    const filteredLogs = getFilteredAuditLogs();
    const hasMoreLogs = cachedAuditLogs.length > filteredLogs.length;
    const visibleDeletedTransactions = filteredDeletedTransactions.slice(0, recycleBinLimit);
    const hasMoreDeleted = filteredDeletedTransactions.length > visibleDeletedTransactions.length;
    const adminAttendanceRows = isAdmin() ? realActiveUsers().map(u => ({ user: u, perf: getMonthlyAttendancePerformance(u.username) })) : [];

    const adminMenuCards = isAdmin() ? [
      ['attendance','Performa Absen Staff', 'Rata-rata jam absen bulanan staff', 'fa-user-clock'],
      ['manual_bonus','Tambah Bonus Manual', 'Tambah bonus ke staff/harian pilihan', 'fa-hand-holding-dollar'],
      ['unlock_requests','Buka Fitur Staff', `${pendingUnlockCount()} menunggu review`, 'fa-unlock-keyhole'],
      ['receipt_text','Setting Tulisan Struk', 'Ubah nama toko, label, footer, dan jarak sobek', 'fa-receipt'],
      ['daily_employee','Kontrol Bonus Khusus User', 'Atur bonus transaksi per user langsung', 'fa-user-tag'],
      ['user_management','Manajemen User', 'Tambah, edit, nonaktifkan user', 'fa-users-gear'],
      ['backup_restore','Backup, Reset & Restore', 'Backup, restore otomatis, normalisasi', 'fa-database'],
      ['deleted_data','Data Terhapus', 'Recycle bin transaksi', 'fa-trash-can-arrow-up']
    ].map(([key,title,sub,icon]) => `
      <button onclick="openAdminProPage('${key}')" class="setting-row" style="margin-bottom:8px;border-radius:14px!important">
        <div class="setting-ico" style="background:var(--accent-dim)"><i class="fas ${icon}" style="color:var(--accent)"></i></div>
        <span class="setting-label">${escapeHtml(title)}<small style="display:block;font-size:10px;color:var(--text-soft);font-weight:650;margin-top:2px">${escapeHtml(sub)}</small></span>
        <i class="fas fa-chevron-right setting-arrow"></i>
      </button>`).join('') : '';

    info.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:0">
        ${adminMenuCards}
      </div>
    `;
    if (isAdmin() && $('recycle-user-filter')) $('recycle-user-filter').value = recycleUserFilter;
    updateRestoreProStatus();
  }
  function escapeHtml(value) {
    return String(value || '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function getAttendanceAdminUsers() {
    return realActiveUsers().filter(u => {
      const username = sanitizeUsername(u.username || u.id || '');
      return username && !ADMIN_USERNAMES.includes(username) && normalizeRole(u.role || 'staff') !== 'admin';
    });
  }

  function getAttendanceUserOptionsHtml(selected = 'all', includeAll = true) {
    const sel = sanitizeUsername(selected || 'all');
    const opts = getAttendanceAdminUsers().map(u => {
      const username = sanitizeUsername(u.username || u.id || '');
      const label = `${u.name || username} (@${username}) · ${getRoleDisplayName(u.role || 'staff')}`;
      return `<option value="${escapeHtml(username)}" ${sel === username ? 'selected' : ''}>${escapeHtml(label)}</option>`;
    }).join('');
    return `${includeAll ? `<option value="all" ${sel === 'all' ? 'selected' : ''}>Semua User</option>` : ''}${opts}`;
  }

  function getTimeInputValueFromMs(msValue = Date.now()) {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Jakarta', hour: '2-digit', minute: '2-digit', hour12: false
    }).formatToParts(new Date(Number(msValue || Date.now()))).reduce((acc, part) => {
      if (part.type !== 'literal') acc[part.type] = part.value;
      return acc;
    }, {});
    return `${parts.hour || '00'}:${parts.minute || '00'}`;
  }

  function normalizeAttendancePageDate(value) {
    const v = String(value || '').slice(0, 10);
    return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : '';
  }

  function getFilteredAdminAttendance() {
    let items = (cachedAttendance || []).filter(a => attendancePageShowDeleted ? isRecordDeleted(a) : !isRecordDeleted(a));
    const user = sanitizeUsername(attendancePageUserFilter || 'all');
    const date = normalizeAttendancePageDate(attendancePageDateFilter);
    if (user && user !== 'all') items = items.filter(a => sanitizeUsername(a.user) === user);
    if (date) items = items.filter(a => extractDateKey(a) === date);
    return sortByCreatedDesc(items);
  }

  function setAttendanceUserFilter(value) {
    attendancePageUserFilter = sanitizeUsername(value || 'all') || 'all';
    attendancePageLimit = ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function setAttendanceDateFilter(value) {
    attendancePageDateFilter = normalizeAttendancePageDate(value) || '';
    attendancePageLimit = ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function setAttendanceDateToday() {
    attendancePageDateFilter = toDateKey(nowDate());
    attendancePageLimit = ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function clearAttendanceFilters() {
    attendancePageUserFilter = 'all';
    attendancePageDateFilter = toDateKey(nowDate());
    attendancePageShowDeleted = false;
    attendancePageLimit = ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function toggleAttendanceDeleted() {
    attendancePageShowDeleted = !attendancePageShowDeleted;
    attendancePageLimit = ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function increaseAttendanceLimit() {
    attendancePageLimit += ATTENDANCE_PAGE_STEP;
    renderAttendanceAdminPage();
  }

  function getAttendanceAdminStats() {
    const today = toDateKey(nowDate());
    const active = (cachedAttendance || []).filter(a => !isRecordDeleted(a));
    const todaySet = new Set(active.filter(a => extractDateKey(a) === today).map(a => sanitizeUsername(a.user)).filter(Boolean));
    const month = toMonthKey(nowDate());
    const monthCount = active.filter(a => String(extractDateKey(a) || '').startsWith(month)).length;
    return { todayCount: todaySet.size, monthCount, staffCount: getAttendanceAdminUsers().length };
  }

  function renderAttendanceItem(a) {
    const username = sanitizeUsername(a.user || '');
    const user = getUserByUsername(username);
    const name = user?.name || a.name || username || '-';
    const dateKey = extractDateKey(a) || a.dateKey || '';
    const timeLabel = formatAttendanceTime(a);
    const deletedCls = isRecordDeleted(a) ? 'status-warn' : 'status-ok';
    const deletedText = isRecordDeleted(a) ? 'Terhapus' : 'Aktif';
    return `
      <div class="trx-card" style="align-items:flex-start">
        <div class="trx-icon" style="background:${isRecordDeleted(a) ? 'var(--red-dim)' : 'var(--green-dim)'};color:${isRecordDeleted(a) ? 'var(--red)' : 'var(--green)'}"><i class="fas fa-user-clock"></i></div>
        <div style="min-width:0;flex:1">
          <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px">
            <div style="min-width:0;flex:1">
              <div style="font-size:13px;font-weight:850;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(name)}</div>
              <div style="font-size:10.5px;color:var(--text-soft);margin-top:2px">@${escapeHtml(username)} · ${escapeHtml(formatDateLabel(dateKey))} · ${escapeHtml(timeLabel)} WIB</div>
              <span class="status-pill ${deletedCls}" style="font-size:9px;padding:3px 7px;white-space:nowrap;margin-top:7px;display:inline-flex">${deletedText}</span>
            </div>
            <div style="display:flex;gap:6px;flex-shrink:0;align-items:flex-start">
              ${isRecordDeleted(a) ? `
                <button onclick="restoreAdminAttendance('${escapeHtml(a.id)}')" class="btn btn-glass" style="width:34px;height:34px;padding:0;font-size:11px;border-radius:10px" title="Pulihkan"><i class="fas fa-rotate-left"></i></button>
              ` : `
                <button onclick="openAdminAttendanceModal('${escapeHtml(a.id)}')" class="btn btn-glass icon-action-btn icon-edit-btn" style="width:34px;height:34px;padding:0;font-size:11px;border-radius:10px" title="Edit"><i class="fas fa-pen"></i></button>
                <button onclick="deleteAdminAttendance('${escapeHtml(a.id)}')" class="btn btn-danger icon-action-btn icon-trash-btn" style="width:34px;height:34px;padding:0;font-size:11px;border-radius:10px" title="Hapus"><i class="fas fa-trash"></i></button>
              `}
            </div>
          </div>
        </div>
      </div>`;
  }

  function renderAttendanceAdminPage() {
    const box = $('attendance-admin-page');
    if (!box) return;
    const stats = getAttendanceAdminStats();
    const items = getFilteredAdminAttendance();
    const shown = items.slice(0, attendancePageLimit);
    const deletedCount = (cachedAttendance || []).filter(isRecordDeleted).length;
    box.innerHTML = `
      <div class="summary-grid page-in s1" style="margin-bottom:8px">
        <div class="stat-mini"><div class="stat-mini-lbl">Hadir Hari Ini</div><div class="stat-mini-num" style="color:var(--green)">${stats.todayCount}</div></div>
        <div class="stat-mini"><div class="stat-mini-lbl">Absen Bulan Ini</div><div class="stat-mini-num" style="color:var(--accent)">${stats.monthCount}</div></div>
      </div>
      <div class="card" style="padding:12px 13px;margin-bottom:9px">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px">
          <div>
            <p class="label-xs" style="margin:0">Filter Absen</p>
            <p style="font-size:10.5px;color:var(--text-soft);margin-top:4px">Data aktif: ${getVisibleAttendance().length} · terhapus: ${deletedCount}</p>
          </div>
          <span class="status-pill ${attendancePageShowDeleted ? 'status-warn' : 'status-ok'}">${attendancePageShowDeleted ? 'Terhapus' : 'Aktif'}</span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <select class="g-input" onchange="setAttendanceUserFilter(this.value)">${getAttendanceUserOptionsHtml(attendancePageUserFilter, true)}</select>
          <input class="g-input" type="date" value="${escapeHtml(attendancePageDateFilter || '')}" onchange="setAttendanceDateFilter(this.value)">
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px;margin-top:8px">
          <button onclick="openAdminAttendanceModal()" class="btn btn-primary" style="padding:10px;font-size:11.5px"><i class="fas fa-plus"></i> Tambah</button>
          <button onclick="toggleAttendanceDeleted()" class="btn btn-glass" style="padding:10px;font-size:11.5px"><i class="fas fa-trash-can-arrow-up"></i> ${attendancePageShowDeleted ? 'Aktif' : 'Terhapus'}</button>
          <button onclick="clearAttendanceFilters()" class="btn btn-glass" style="padding:10px;font-size:11.5px"><i class="fas fa-calendar-day"></i> Hari Ini</button>
        </div>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin:2px 2px 8px">
        <p class="label-xs" style="margin:0">Daftar Absen</p>
        <span class="user-chip">${shown.length}/${items.length}</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${shown.length ? shown.map(renderAttendanceItem).join('') : `<div class="card" style="padding:18px;text-align:center;color:var(--text-soft);font-size:12px">Tidak ada data absen sesuai filter.</div>`}
      </div>
      ${items.length > shown.length ? `<button onclick="increaseAttendanceLimit()" class="btn btn-glass" style="width:100%;padding:12px;margin-top:10px;font-size:12px">Muat ${Math.min(ATTENDANCE_PAGE_STEP, items.length - shown.length)} lagi</button>` : ''}
    `;
  }

  function closeAdminAttendanceModal() {
    const old = document.getElementById('admin-attendance-modal');
    if (old) old.remove();
  }

  function openAdminAttendanceModal(id = '') {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    const rec = id ? cachedAttendance.find(a => String(a.id) === String(id)) : null;
    const selectedUser = sanitizeUsername(rec?.user || (attendancePageUserFilter !== 'all' ? attendancePageUserFilter : ''));
    const dateValue = extractDateKey(rec) || attendancePageDateFilter || toDateKey(nowDate());
    const timeValue = getTimeInputValueFromMs(getRecordTimeMs(rec) || Date.now());
    const old = document.getElementById('admin-attendance-modal');
    if (old) old.remove();
    const wrap = document.createElement('div');
    wrap.id = 'admin-attendance-modal';
    wrap.className = 'modal-wrap show';
    wrap.style.zIndex = '430';
    wrap.style.alignItems = 'center';
    wrap.style.justifyContent = 'center';
    wrap.innerHTML = `
      <div class="modal-sheet modal-sheet-wide" style="max-width:460px;border-radius:22px;padding:18px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px">
          <div style="min-width:0">
            <h3 style="font-size:15px;font-weight:900;letter-spacing:-.02em">${id ? 'Edit Absen' : 'Tambah Absen'}</h3>
            <p style="font-size:10.5px;color:var(--text-soft);margin-top:3px">Absen manual mengikuti zona WIB</p>
          </div>
          <button onclick="closeAdminAttendanceModal()" class="btn btn-glass" style="width:36px;height:36px;padding:0;border-radius:12px"><i class="fas fa-xmark"></i></button>
        </div>
        <div style="display:flex;flex-direction:column;gap:9px">
          <div><p class="label-xs">User</p><select id="admin-att-user" class="g-input">${getAttendanceUserOptionsHtml(selectedUser, false)}</select></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
            <div><p class="label-xs">Tanggal</p><input id="admin-att-date" type="date" class="g-input" value="${escapeHtml(dateValue)}"></div>
            <div><p class="label-xs">Jam WIB</p><input id="admin-att-time" type="time" class="g-input" value="${escapeHtml(timeValue)}"></div>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px">
          <button onclick="closeAdminAttendanceModal()" class="btn btn-glass" style="padding:11px;font-size:12px">Batal</button>
          <button onclick="saveAdminAttendance('${escapeHtml(id)}')" class="btn btn-primary" style="padding:11px;font-size:12px"><i class="fas fa-floppy-disk"></i> Simpan</button>
        </div>
      </div>`;
    document.body.appendChild(wrap);
    const sheet = wrap.querySelector('.modal-sheet');
    const modalControls = wrap.querySelectorAll('#admin-att-user,#admin-att-date,#admin-att-time');
    let backdropPointerStarted = false;
    let controlInteractionActive = false;
    const blockBackdropClose = (holdMs = 1400) => {
      wrap.__blockBackdropClose = true;
      clearTimeout(wrap.__blockBackdropTimer);
      wrap.__blockBackdropTimer = setTimeout(() => { wrap.__blockBackdropClose = false; }, holdMs);
    };
    const beginControlInteraction = () => {
      controlInteractionActive = true;
      blockBackdropClose(30000);
      clearTimeout(wrap.__controlInteractionTimer);
      wrap.__controlInteractionTimer = setTimeout(() => { controlInteractionActive = false; }, 30000);
    };
    const endControlInteraction = () => {
      blockBackdropClose(1400);
      clearTimeout(wrap.__controlInteractionTimer);
      wrap.__controlInteractionTimer = setTimeout(() => { controlInteractionActive = false; }, 1400);
    };
    const modalHasActiveControl = () => {
      const active = document.activeElement;
      return !!(active && wrap.contains(active) && active.matches && active.matches('input,select,textarea'));
    };
    if (sheet) {
      ['click','pointerdown','touchstart','touchend','mousedown','mouseup'].forEach(evt => sheet.addEventListener(evt, (ev) => ev.stopPropagation(), { passive: true }));
    }
    wrap.addEventListener('pointerdown', (e) => { backdropPointerStarted = e.target === wrap; }, true);
    wrap.addEventListener('touchstart', (e) => { backdropPointerStarted = e.target === wrap; }, true);
    wrap.addEventListener('mousedown', (e) => { backdropPointerStarted = e.target === wrap; }, true);
    modalControls.forEach(control => {
      ['pointerdown','touchstart','mousedown','focus','click'].forEach(evt => control.addEventListener(evt, beginControlInteraction));
      ['input','change','blur','keydown'].forEach(evt => control.addEventListener(evt, endControlInteraction));
    });
    wrap.addEventListener('click', (e) => {
      if (e.target !== wrap) return;
      if (!backdropPointerStarted) return;
      if (wrap.__blockBackdropClose) return;
      if (controlInteractionActive || modalHasActiveControl()) {
        blockBackdropClose();
        return;
      }
      closeAdminAttendanceModal();
    });
  }

  async function saveAdminAttendance(id = '') {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    if (isBusy) return showToast('Tunggu proses selesai', true);
    const username = sanitizeUsername($('admin-att-user')?.value || '');
    const user = getUserByUsername(username);
    const dateKey = normalizeAttendancePageDate($('admin-att-date')?.value || '');
    const timeValue = String($('admin-att-time')?.value || '').slice(0, 5);
    if (!username || !user) return showToast('User tidak valid', true);
    if (!dateKey) return showToast('Tanggal tidak valid', true);
    if (!/^\d{2}:\d{2}$/.test(timeValue)) return showToast('Jam tidak valid', true);
    const pin = await askPin(`${id ? 'Simpan edit' : 'Tambah'} absen untuk ${user.name || username}?\n${dateKey} ${timeValue} WIB\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    const createdAtMs = Date.parse(`${dateKey}T${timeValue}:00+07:00`);
    if (!Number.isFinite(createdAtMs)) return showToast('Jam absen tidak valid', true);
    const docId = id || getAttendanceDocId(username, dateKey);
    const payload = {
      user: username,
      name: user.name || username,
      dateKey,
      monthKey: dateKey.slice(0, 7),
      createdAt: Timestamp.fromMillis(createdAtMs),
      createdAtMs,
      manual: true,
      ...getTrialFlags(user),
      deleted: false,
      updatedAt: serverTimestamp(),
      updatedAtMs: Date.now(),
      updatedBy: currentUser.username,
      updatedByName: currentUser.name || currentUser.username
    };
    if (!id) {
      payload.createdBy = currentUser.username;
      payload.createdByName = currentUser.name || currentUser.username;
    }
    setLoading(true);
    try {
      await setDoc(doc(db, 'attendance', docId), payload, { merge: true });
      upsertAttendanceRecord({ id: docId, ...payload });
      await logAudit(id ? 'attendance_edit' : 'attendance_manual_add', { id: docId, user: username, dateKey, createdAtMs });
      closeAdminAttendanceModal();
      attendancePageDateFilter = dateKey;
      attendancePageUserFilter = username;
      attendancePageShowDeleted = false;
      showToast('✓ Absen tersimpan');
      renderAttendanceAdminPage();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal simpan absen', true);
    }
    setLoading(false);
  }

  async function deleteAdminAttendance(id) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    const rec = cachedAttendance.find(a => String(a.id) === String(id));
    if (!rec) return showToast('Data absen tidak ditemukan', true);
    const pin = await askPin(`Hapus absen ${rec.name || rec.user || ''}?\n${extractDateKey(rec) || '-'} ${formatAttendanceTime(rec)} WIB\n\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'attendance', id), {
        deleted: true,
        deletedAt: serverTimestamp(),
        deletedAtMs: Date.now(),
        deletedBy: currentUser.username,
        deletedByName: currentUser.name || currentUser.username
      }, { merge: true });
      cachedAttendance = cachedAttendance.map(a => String(a.id) === String(id) ? { ...a, deleted: true, deletedAtMs: Date.now(), deletedBy: currentUser.username, deletedByName: currentUser.name || currentUser.username } : a);
      await logAudit('attendance_soft_delete', { id, user: rec.user, dateKey: extractDateKey(rec) });
      showToast('✓ Absen dihapus');
      renderAttendanceAdminPage();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal hapus absen', true);
    }
    setLoading(false);
  }

  async function restoreAdminAttendance(id) {
    if (!isAdmin()) return showToast('Hanya admin!', true);
    const rec = cachedAttendance.find(a => String(a.id) === String(id));
    if (!rec) return showToast('Data absen tidak ditemukan', true);
    const pin = await askPin(`Pulihkan absen ${rec.name || rec.user || ''}?\nMasukkan PIN admin:`);
    if (!pin) return;
    if (!(await requireCurrentAdminPin(pin))) return;
    setLoading(true);
    try {
      await setDoc(doc(db, 'attendance', id), {
        deleted: false,
        deletedAt: null,
        deletedAtMs: null,
        deletedBy: null,
        deletedByName: null,
        restoredAt: serverTimestamp(),
        updatedAtMs: Date.now(),
        updatedBy: currentUser.username,
        updatedByName: currentUser.name || currentUser.username
      }, { merge: true });
      cachedAttendance = cachedAttendance.map(a => String(a.id) === String(id) ? { ...a, deleted: false, deletedAt: null, deletedAtMs: null, deletedBy: null, deletedByName: null } : a);
      await logAudit('attendance_restore', { id, user: rec.user, dateKey: extractDateKey(rec) });
      showToast('✓ Absen dipulihkan');
      attendancePageShowDeleted = false;
      renderAttendanceAdminPage();
      await refreshCurrentPage();
    } catch (e) {
      console.error(e);
      showToast('Gagal pulihkan absen', true);
    }
    setLoading(false);
  }


  function applyNavRoleLabels() {
    const labels = { home:'Admin', history:'Riwayat', attendance:'Absen', closing:'Closing', report:'Laporan', settings:'User' };
    if ($('nav-home-label')) $('nav-home-label').textContent = labels.home;
    if ($('nav-history-label')) $('nav-history-label').textContent = labels.history;
    if ($('nav-attendance-label')) $('nav-attendance-label').textContent = labels.attendance;
    if ($('nav-closing-label')) $('nav-closing-label').textContent = labels.closing;
    if ($('nav-report-label')) $('nav-report-label').textContent = labels.report;
    if ($('nav-settings-label')) $('nav-settings-label').textContent = labels.settings;
    const attendanceBtn = $('nav-attendance'), closingBtn = $('nav-closing'), reportBtn = $('nav-report'), settingsBtn = $('nav-settings');
    if (attendanceBtn) attendanceBtn.style.display = 'flex';
    if (closingBtn) closingBtn.style.display = 'flex';
    if (reportBtn) reportBtn.style.display = 'flex';
    if (settingsBtn) settingsBtn.style.display = 'flex';
  }

  function setActiveNav(page) {
    applyNavRoleLabels();
    const navEl = $('bottom-nav');
    if (navEl) {
      navEl.classList.remove('staff-nav');
      navEl.classList.toggle('admin-six-nav', !!currentUser);
    }
    ['home','history','attendance','closing','report','settings'].forEach(p => {
      const btn = $('nav-' + p); if (btn) btn.classList.toggle('active', p === page || (page === 'adminLogs' && p === 'settings'));
    });
    const fab = $('fab-pos');
    if (!fab) return;
    fab.classList.remove('staff-fab');
    fab.style.display = 'none';
  }

  function isBackSwipeIgnoredTarget(target) {
    const tag = (target && target.tagName ? target.tagName : '').toLowerCase();
    return ['input','textarea','select','button','a'].includes(tag) || !!(target && target.closest && target.closest('.modal-wrap,.tab-group,#bottom-nav,.fab-add,.btn,.theme-toggle'));
  }

  function appBackToPreviousPage() {
    if (!currentUser || currentPage === 'login') return false;
    const openModal = document.querySelector('.modal-wrap.show, .modal.show');
    if (openModal) {
      openModal.classList.remove('show');
      openModal.style.display = 'none';
      return true;
    }
    if (String(currentPage || '').startsWith('adminPro:')) {
      appBackNavigating = true;
      adminProCurrentPageKey = '';
      router.navigate('settings').finally(() => { appBackNavigating = false; });
      return true;
    }
    let prev = '';
    while (appPageHistoryStack.length) {
      prev = appPageHistoryStack.pop();
      if (prev && prev !== currentPage) break;
      prev = '';
    }
    if (!prev && currentPage === 'adminLogs') prev = 'settings';
    if (prev) {
      appBackNavigating = true;
      router.navigate(prev).finally(() => { appBackNavigating = false; });
      return true;
    }
    return false;
  }

  function handleAppBackSwipeStart(e) {
    appSwipeStartT = 0;
    const touch = e.touches && e.touches[0];
    if (!touch || isBackSwipeIgnoredTarget(e.target)) return;
    appSwipeStartX = touch.clientX;
    appSwipeStartY = touch.clientY;
    appSwipeStartT = Date.now();
  }

  function handleAppBackSwipeEnd(e) {
    const touch = e.changedTouches && e.changedTouches[0];
    if (!touch || !appSwipeStartT) return;
    if (isBackSwipeIgnoredTarget(e.target)) { appSwipeStartT = 0; return; }
    const dx = touch.clientX - appSwipeStartX;
    const dy = touch.clientY - appSwipeStartY;
    const dt = Date.now() - appSwipeStartT;
    appSwipeStartT = 0;
    if (appSwipeStartX > 42 || dx < 86 || Math.abs(dx) < Math.abs(dy) * 1.25 || dt > 850) return;
    if (appBackToPreviousPage()) {
      try { e.preventDefault(); } catch (_) {}
    }
  }

  window.__rockyNativeBack = appBackToPreviousPage;

  const router = {
    navigate: async (page) => {
      if (!appBackNavigating && currentPage && currentPage !== page && currentPage !== 'login' && RESTORABLE_PAGES.includes(currentPage)) {
        const last = appPageHistoryStack[appPageHistoryStack.length - 1];
        if (last !== currentPage) appPageHistoryStack.push(currentPage);
        if (appPageHistoryStack.length > 20) appPageHistoryStack = appPageHistoryStack.slice(-20);
      }
      if (RESTORABLE_PAGES.includes(page)) adminProCurrentPageKey = '';
      currentPage = page;
      const content = $('page-content');
      const nav = $('bottom-nav');
      const themeIcon = getTheme() === 'dark' ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
      const memberIcon = '<a href="https://idhamkhalid24.github.io/kode-khusus-member/" target="_blank" rel="noopener noreferrer" class="theme-toggle member-btn" title="Member" aria-label="Member"><i class="fas fa-id-card"></i></a>';
      const refreshIcon = '<button class="theme-toggle refresh-btn" onclick="manualRefreshData()" title="Refresh Data" aria-label="Refresh Data"><i class="fas fa-rotate"></i></button>';
      if (!window.__adminSwipeReady && content) {
        content.addEventListener('touchstart', handleAppBackSwipeStart, { passive:true });
        content.addEventListener('touchend', handleAppBackSwipeEnd, { passive:false });
        window.__adminSwipeReady = true;
      }

      if (page === 'login') {
        nav.style.display = 'none';
        if ($('fab-pos')) $('fab-pos').style.display = 'none';
        content.innerHTML = `
          <div style="min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px 22px;position:relative">
            <div style="position:absolute;top:22px;right:22px"><button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button></div>
            <h1 style="font-size:24px;font-weight:800;letter-spacing:-.02em;margin-bottom:4px;text-align:center" class="page-in s1">Rocky Hijab</h1>
            <p style="font-size:13px;color:var(--text-soft);margin-bottom:10px;text-align:center" class="page-in s1">Koleksi Terbaik Untuk Muslimah Hebat</p>
            <div style="width:100%;display:flex;flex-direction:column;gap:10px;max-width:360px" class="page-in s2">
              <input id="login-user" type="text" placeholder="Username" class="g-input" style="font-size:15px;padding:14px 15px">
              <input id="login-pin" type="password" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" placeholder="PIN" class="g-input" style="font-size:15px;padding:14px 15px;letter-spacing:.08em">
              <button onclick="login()" class="btn btn-primary" style="width:100%;padding:14px;font-size:14.5px;margin-top:4px;border-radius:13px">Masuk</button>
            </div>
            <p style="font-size:11px;color:var(--text-ghost);margin-top:14px;text-align:center" class="page-in s3">Hanya akun admin yang bisa masuk</p>
          </div>`;
      } else if (!currentUser) {
        return router.navigate('login');
      } else if (!isAdmin()) {
        localStorage.removeItem(SESSION_KEY);
        localStorage.removeItem(PAGE_KEY);
        currentUser = null;
        showToast('Akses ditolak. Aplikasi ini khusus admin.', true);
        return router.navigate('login');
      } else if (!RESTORABLE_PAGES.includes(page)) {
        return router.navigate('home');
      } else {
        try { localStorage.setItem(PAGE_KEY, page); } catch (_) {}
      }

      if (page === 'home') {
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad" style="padding-top:8px">
            <div style="padding:10px 0 8px;display:flex;justify-content:space-between;align-items:center" class="page-in">
              <div>
                <p style="font-size:10px;color:var(--text-ghost);font-weight:700;margin-bottom:2px">Panel Admin</p>
                <h2 style="font-size:18px;font-weight:850;letter-spacing:-.03em">Kontrol Data</h2>
              </div>
              <div class="header-actions">
                ${memberIcon}
                ${refreshIcon}
                <button class="theme-toggle theme-btn" onclick="toggleTheme()" style="width:34px;height:34px;border-radius:10px">${themeIcon}</button>
                <button class="theme-toggle logout-btn" onclick="logout()" title="Logout" style="width:34px;height:34px;border-radius:10px"><i class="fas fa-power-off"></i></button>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px" class="page-in s1">
              <div class="card" style="padding:10px 11px"><p class="label-xs" style="margin-bottom:5px;font-size:9px">Omzet Hari Ini</p><p id="today-income" style="font-family:var(--num-font);font-size:17px;font-weight:850;color:var(--text);line-height:1">Rp 0</p></div>
              <div id="home-cash-fisik-card" class="card" style="padding:10px 11px;background:#eff6ff;border-color:#bfdbfe">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:6px;margin-bottom:4px">
                  <p class="label-xs" style="margin:0;font-size:9px;color:#2563eb">Cash Fisik Hari Ini</p>
                  <span style="font-size:8px;font-weight:900;padding:2px 6px;border-radius:999px;background:#dbeafe;color:#1d4ed8;border:1px solid #bfdbfe;white-space:nowrap">HARI INI</span>
                </div>
                <p id="home-cash-fisik-total" style="font-family:var(--num-font);font-size:20px;font-weight:900;color:#2563eb;line-height:1.05;margin-top:3px">Rp 0</p>
                <p id="home-cash-fisik-info" style="display:none"></p>
              </div>
            </div>
            <div class="card page-in s2" style="padding:10px 11px;margin-bottom:8px">
              <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px"><p class="label-xs" style="margin:0;font-size:9px">Bonus Global</p><span id="scope-chip" class="user-chip" style="font-size:10px;padding:3px 7px">Semua User</span></div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:end">
                <div><p id="total-bonus" style="font-family:var(--num-font);font-size:21px;font-weight:850;color:var(--accent);line-height:1">Rp 0</p><p id="bonus-text" style="font-size:10px;color:var(--text-soft);margin-top:4px;line-height:1.25">Bonus ini sudah termasuk total bonus keseluruhan</p></div>
                <div style="text-align:right"><span style="font-size:10px;color:var(--text-soft)">Omzet Bulan</span><strong id="month-omzet" style="display:block;font-size:12px;color:var(--text);margin-top:3px">Rp 0</strong></div>
              </div>
            </div>
            <div class="card page-in s2" style="padding:10px 11px;margin-bottom:8px;border-color:rgba(82,216,158,.18);background:linear-gradient(135deg,var(--green-dim),var(--bg2))">
              <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:6px">
                <p class="label-xs" style="margin:0;font-size:9px;color:var(--green)">Total Bonus Harian</p>
                <span class="user-chip" style="font-size:10px;padding:3px 7px;color:var(--green);background:var(--green-dim);border-color:rgba(82,216,158,.2)">Hari Ini</span>
              </div>
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;align-items:end">
                <div>
                  <p id="today-bonus-total" style="font-family:var(--num-font);font-size:21px;font-weight:850;color:var(--green);line-height:1">Rp 0</p>
                  <p id="today-bonus-text" style="font-size:10px;color:var(--text-soft);margin-top:4px;line-height:1.25">Bonus semua user khusus tanggal hari ini</p>
                </div>
                <div style="text-align:right">
                  <span style="font-size:10px;color:var(--text-soft)">Omzet Hari Ini</span>
                  <strong id="today-bonus-omzet" style="display:block;font-size:12px;color:var(--text);margin-top:3px">Rp 0</strong>
                </div>
              </div>
            </div>
            <div id="admin-dashboard-panels"></div>
          </div>`;
        updateLocation(); updateHomeStatus(); updateHomeStats();
      } else if (page === 'history') {
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:34px 0 18px;display:flex;justify-content:space-between;align-items:center" class="page-in">
              <div><p class="page-title">Semua Transaksi</p><p class="page-subtitle">Pantau transaksi seluruh user</p></div>
              <div style="display:flex;gap:8px">
                ${memberIcon}
                ${refreshIcon}
                <button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button>
                <button class="theme-toggle logout-btn" onclick="logout()" title="Logout"><i class="fas fa-power-off"></i></button>
              </div>
            </div>
            <div id="history-list" style="display:flex;flex-direction:column;gap:9px;padding-bottom:22px"></div>
          </div>`;
        renderHistory();
      } else if (page === 'attendance') {
        if (!isAdmin()) return router.navigate('home');
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:34px 0 18px;display:flex;justify-content:space-between;align-items:center;gap:10px" class="page-in">
              <div style="min-width:0">
                <p class="page-title" style="font-size:21px">Halaman Absen</p>
                <p class="page-subtitle">Tambah, edit, hapus, dan pulihkan absen staff/harian</p>
              </div>
              <div class="header-actions">
                ${memberIcon}
                ${refreshIcon}
                <button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button>
                <button class="theme-toggle logout-btn" onclick="logout()" title="Logout"><i class="fas fa-power-off"></i></button>
              </div>
            </div>
            <div id="attendance-admin-page" class="page-in s1" style="padding-bottom:18px"></div>
          </div>`;
        renderAttendanceAdminPage();
      } else if (page === 'closing') {
        if (!isAdmin()) return router.navigate('home');
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:34px 0 18px;display:flex;justify-content:space-between;align-items:center;gap:10px" class="page-in">
              <div style="min-width:0">
                <p class="page-title" style="font-size:21px">Halaman Closing</p>
                <p class="page-subtitle">Closing Per User dan Closing Manual Risma</p>
              </div>
              <div class="header-actions">
                ${memberIcon}
                ${refreshIcon}
                <button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button>
                <button class="theme-toggle logout-btn" onclick="logout()" title="Logout"><i class="fas fa-power-off"></i></button>
              </div>
            </div>
            <div id="admin-closing-panel" class="page-in s1" style="padding-bottom:18px"></div>
          </div>`;
        renderAdminClosingPanelMaybe(true);
      } else if (page === 'report') {
        if (!isAdmin()) return router.navigate('home');
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:34px 0 18px;display:flex;justify-content:space-between;align-items:center" class="page-in">
              <div><p class="page-title">Laporan Global</p><p class="page-subtitle">Ringkasan semua user dalam satu panel</p></div>
              <div style="display:flex;gap:8px">
                ${memberIcon}
                ${refreshIcon}
                <button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button>
                <button class="theme-toggle logout-btn" onclick="logout()" title="Logout"><i class="fas fa-power-off"></i></button>
              </div>
            </div>
            <div class="tab-group page-in" style="margin-bottom:14px">
              <button id="f-daily" onclick="setReportFilter('daily')" class="tab-btn ${reportFilter==='daily'?'active':''}">Harian</button>
              <button id="f-monthly" onclick="setReportFilter('monthly')" class="tab-btn ${reportFilter==='monthly'?'active':''}">Bulanan</button>
              <button id="f-yearly" onclick="setReportFilter('yearly')" class="tab-btn ${reportFilter==='yearly'?'active':''}">Tahunan</button>
            </div>
            <div id="report-view" style="display:flex;flex-direction:column;gap:10px;padding-bottom:18px"></div>
          </div>`;
        renderReport();
      } else if (page === 'adminLogs') {
        if (!isAdmin()) return router.navigate('home');
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:50px 0 18px;display:flex;justify-content:space-between;align-items:center;gap:10px" class="page-in">
              <div style="display:flex;align-items:center;gap:10px;min-width:0">
                <button onclick="router.navigate('settings')" class="theme-toggle" style="width:38px;height:38px"><i class="fas fa-arrow-left"></i></button>
                <div style="min-width:0">
                  <p class="page-title" style="font-size:21px">Log Aktivitas Admin</p>
                  <p class="page-subtitle">Halaman khusus audit log</p>
                </div>
              </div>
              <div class="header-actions">${memberIcon}${refreshIcon}<button class="theme-toggle theme-btn" onclick="toggleTheme()">${themeIcon}</button></div>
            </div>
            <div id="admin-logs-list" class="page-in s1" style="padding-bottom:18px"></div>
          </div>`;
        renderAdminLogsPage();
      } else if (page === 'settings') {
        if (!isAdmin()) return router.navigate('home');
        nav.style.display = 'flex'; setActiveNav(page);
        content.innerHTML = `
          <div class="page-pad">
            <div style="padding:34px 0 14px;display:flex;justify-content:space-between;align-items:center" class="page-in">
              <div>
                <p class="page-title">User</p>
                <p class="page-subtitle">Menu admin dipisah per halaman agar tidak menumpuk.</p>
              </div>
            </div>
            <div id="settings-summary" style="padding-bottom:18px" class="page-in s1"></div>
          </div>`;
        renderSettingsSummary();
      }
    }
  };

  function setHistoryFilter(f) { historyFilter = f; resetHistoryDisplayLimit(); renderHistory(); }
  function filterHistoryByDateRange() {
    const s = $('history-range-start')?.value, e = $('history-range-end')?.value;
    if (s && e) { rangeStartDate = s; rangeEndDate = e; historyFilter = 'range'; resetHistoryDisplayLimit(); renderHistory(); }
    else showToast('Pilih tanggal!', true);
  }
  function resetHistoryFilter() { rangeStartDate = null; rangeEndDate = null; historyFilter = 'daily'; resetHistoryDisplayLimit(); renderHistory(); }
  function setReportFilter(f) {
    reportFilter = f;
    if (f === 'monthly' && !reportMonthKey) reportMonthKey = toMonthKey(nowDate());
    ['daily','monthly','yearly'].forEach(tab => {
      const b = $('f-' + tab); if (b) b.classList.toggle('active', tab === f);
    });
    renderReport();
  }


  function setSelectedUserFilter(value) {
    selectedUserFilter = value || 'all';
    // Filter user hanya untuk halaman yang memang punya filter.
    // Jangan update kartu Home dari filter Global/Riwayat supaya Bonus Global tetap global.
    if (currentPage === 'home') updateHomeStats();
    resetHistoryDisplayLimit();
    resetInactiveUserLimit();
    if (currentPage === 'history') renderHistory();
    if (currentPage === 'report') renderReport();
    if (currentPage === 'settings') renderSettingsSummary();
  }


  window.increaseAuditLogLimit = increaseAuditLogLimit;
  window.toggleTheme = toggleTheme;
  window.login = login;
  window.toggleAdminMoreMenu = toggleAdminMoreMenu;
  window.toggleAdminSettingPanel = toggleAdminSettingPanel;
  window.closeAdminSettingPanels = closeAdminSettingPanels;
  window.logout = logout;
  window.openTransactionModal = openTransactionModal;
  window.closeTransactionModal = closeTransactionModal;
  window.closeTransactionPaymentModal = closeTransactionPaymentModal;
  window.prepareTransactionPaymentFromModal = prepareTransactionPaymentFromModal;
  window.confirmTransactionPayment = confirmTransactionPayment;
  window.handleTransactionFromModal = handleTransactionFromModal;
  window.handleClosingDay = handleClosingDay;
  window.handleEditClosingTime = handleEditClosingTime;
  window.handleCancelClosingToday = handleCancelClosingToday;
  window.renderAdminClosingPanel = renderAdminClosingPanel;
  window.renderAdminClosingPanelMaybe = renderAdminClosingPanelMaybe;
  window.saveRismaManualClosingConfig = saveRismaManualClosingConfig;
  window.saveBonusSettings = saveBonusSettings;
  window.saveClosingDeadlineSettings = saveClosingDeadlineSettings;
  window.resetClosingDeadlineForm = resetClosingDeadlineForm;
  window.resetBonusSettingsForm = resetBonusSettingsForm;
  window.saveUserBonusControl = saveUserBonusControl;
  window.saveManualBonus = saveManualBonus;
  window.deleteManualBonus = deleteManualBonus;
  window.saveReceiptTextSettings = saveReceiptTextSettings;
  window.resetReceiptTextSettingsForm = resetReceiptTextSettingsForm;
  window.updateReceiptSettingsPreview = updateReceiptSettingsPreview;
  window.formatMoneyInputElement = formatMoneyInputElement;
  window.openAdminProPage = openAdminProPage;
  window.reviewUnlockRequestFromServer = reviewUnlockRequestFromServer;
  window.deleteUnlockRequestFromServer = deleteUnlockRequestFromServer;
  window.openEditTransactionModal = openEditTransactionModal;
  window.saveEditedTransaction = saveEditedTransaction;
  window.handleTransactionModalSave = handleTransactionModalSave;
  window.handleTransactionModalPrint = handleTransactionModalPrint;
  window.openReceiptPreview = openReceiptPreview;
  window.closeReceiptPreview = closeReceiptPreview;
  window.nativePrintReceiptText = nativePrintReceiptText;
  window.addModalTransactionItem = addModalTransactionItem;
  window.removeModalTransactionItem = removeModalTransactionItem;
  window.handleModalTransactionItemKey = handleModalTransactionItemKey;
  window.updateModalTransactionItemButton = updateModalTransactionItemButton;
  window.openTransactionDetail = openTransactionDetail;
  window.closeTransactionDetail = closeTransactionDetail;
  window.printTransactionReceipt = printTransactionReceipt;
  window.deleteTransaction = deleteTransaction;
  window.restoreDeletedTransaction = restoreDeletedTransaction;
  window.hardDeleteTransaction = hardDeleteTransaction;
  window.bulkRestoreDeletedTransactions = bulkRestoreDeletedTransactions;
  window.bulkHardDeleteDeletedTransactions = bulkHardDeleteDeletedTransactions;
  window.setRecycleSearch = setRecycleSearch;
  window.setRecycleUserFilter = setRecycleUserFilter;
  window.resetRecycleFilters = resetRecycleFilters;
  window.increaseRecycleBinLimit = increaseRecycleBinLimit;
  window.increaseHistoryDisplayLimit = increaseHistoryDisplayLimit;
  window.increaseInactiveUserLimit = increaseInactiveUserLimit;
  window.filterHistoryByDateRange = filterHistoryByDateRange;
  window.resetHistoryFilter = resetHistoryFilter;
  window.setHistoryFilter = setHistoryFilter;
  window.setReportFilter = setReportFilter;
  window.setReportMonth = setReportMonth;
  window.syncMonthlyReportData = syncMonthlyReportData;
  window.exportMonthlyReportXlsx = exportMonthlyReportXlsx;
  window.exportMonthlyReportCsv = exportMonthlyReportCsv;
  window.setSelectedUserFilter = setSelectedUserFilter;
  window.fillAdminUserForm = fillAdminUserForm;
  window.clearAdminUserForm = clearAdminUserForm;
  window.updateAdminUserClosingLock = updateAdminUserClosingLock;
  window.saveAdminUser = saveAdminUser;
  window.deleteAdminUser = deleteAdminUser;
  window.restoreAdminUser = restoreAdminUser;
  window.hardDeleteAdminUser = hardDeleteAdminUser;
  window.resetUserDevice = resetUserDevice;
  window.downloadBackup = downloadBackup;
  window.restoreBackupFromFile = restoreBackupFromFile;
  window.restoreExcelFromFile = restoreExcelFromFile;
  window.handleRestoreProFile = handleRestoreProFile;
  window.clearRestoreProFile = clearRestoreProFile;
  window.restoreProFromFile = restoreProFromFile;
  window.resetAllAppData = resetAllAppData;
  window.normalizeLegacyData = normalizeLegacyData;
  window.setAttendanceUserFilter = setAttendanceUserFilter;
  window.setAttendanceDateFilter = setAttendanceDateFilter;
  window.setAttendanceDateToday = setAttendanceDateToday;
  window.clearAttendanceFilters = clearAttendanceFilters;
  window.toggleAttendanceDeleted = toggleAttendanceDeleted;
  window.increaseAttendanceLimit = increaseAttendanceLimit;
  window.openAdminAttendanceModal = openAdminAttendanceModal;
  window.closeAdminAttendanceModal = closeAdminAttendanceModal;
  window.saveAdminAttendance = saveAdminAttendance;
  window.deleteAdminAttendance = deleteAdminAttendance;
  window.restoreAdminAttendance = restoreAdminAttendance;
  window.router = router;
  window.updateLocation = updateLocation;
  window.manualRefreshData = manualRefreshData;

  document.addEventListener('keydown', (event) => {
    if (currentPage !== 'login' || event.key !== 'Enter') return;
    const target = event.target;
    if (!target || !['INPUT', 'BUTTON'].includes(target.tagName)) return;
    event.preventDefault();
    login();
  });

  function setRefreshButtonLoading(active) {
    document.querySelectorAll('.refresh-btn').forEach(btn => {
      btn.classList.toggle('is-refreshing', !!active);
      btn.disabled = !!active;
    });
  }

  async function getDocsFreshSafe(label, qy) {
    try {
      return await getDocsFromServer(qy);
    } catch (serverErr) {
      console.warn(`${label} server refresh gagal, pakai cache bila ada:`, serverErr);
      try {
        return await getDocs(qy);
      } catch (cacheErr) {
        console.error(`${label} cache refresh gagal:`, cacheErr);
        return null;
      }
    }
  }

  async function getDocFreshSafe(label, ref) {
    try {
      return await getDocFromServer(ref);
    } catch (serverErr) {
      console.warn(`${label} server refresh gagal, pakai cache bila ada:`, serverErr);
      try {
        return await getDoc(ref);
      } catch (cacheErr) {
        console.error(`${label} cache refresh gagal:`, cacheErr);
        return null;
      }
    }
  }

  async function getDocsFreshWithFallback(label, primaryQ, fallbackQ = null) {
    const primarySnap = await getDocsFreshSafe(label, primaryQ);
    if (primarySnap || !fallbackQ) return primarySnap;
    return await getDocsFreshSafe(`${label} fallback`, fallbackQ);
  }

  function clearCashFisikCacheForRefresh() {
    cachedFinanceCashFetchedAt = 0;
    cachedFinanceCashDateKey = '';
    forceCashFisikNextRender = true;
  }

  async function refreshAllDataNow({ silent = false } = {}) {
    if (!currentUser) return { ok: false, errorCount: 0 };
    let errorCount = 0;
    const countError = (snap) => { if (!snap) errorCount++; return snap; };
    const txQueryFresh = query(collection(db, 'transactions'), orderBy('createdAtMs', 'desc'), limit(TX_SYNC_LIMIT_ADMIN));
    const txQueryFallback = query(collection(db, 'transactions'), limit(TX_SYNC_LIMIT_ADMIN));
    const attendanceQuery = query(collection(db, 'attendance'), limit(ATT_SYNC_LIMIT_ADMIN));
    const manualBonusQuery = query(collection(db, 'manualBonuses'), limit(MANUAL_BONUS_SYNC_LIMIT));
    const unlockRequestQuery = query(collection(db, STAFF_UNLOCK_TABLE), limit(160));

    const [txSnap, attSnap, closingSnap, bonusSnap, guideNoteSnap, receiptTextSnap, manualBonusSnap, unlockRequestSnap] = await Promise.all([
      getDocsFreshWithFallback('Transaksi terbaru', txQueryFresh, txQueryFallback).then(countError),
      getDocsFreshSafe('Absensi', attendanceQuery).then(countError),
      getDocsFreshSafe('Closing', query(collection(db, 'closings'), limit(CLOSING_SYNC_LIMIT))).then(countError),
      getDocFreshSafe('Setting bonus', doc(db, 'closings', '__bonus_settings')).then(countError),
      getDocFreshSafe('Catatan panduan header', doc(db, 'closings', HEADER_GUIDE_NOTE_DOC_ID)).then(countError),
      getDocFreshSafe('Setting tulisan struk', doc(db, 'closings', RECEIPT_TEXT_DOC_ID)).then(countError),
      getDocsFreshSafe('Bonus manual', manualBonusQuery).then(countError),
      getDocsFreshSafe('Buka fitur staff', unlockRequestQuery).then(countError)
    ]);

    if (txSnap) {
      cachedTransactions = sortByCreatedDesc(txSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    }

    if (attSnap) {
      stripCachedAttendance();
      cachedAttendance = dedupeAttendanceRecords(
        attSnap.docs.map(d => ({ id: d.id, ...d.data() })).filter(a => !isRecordDeleted(a))
      );
      attendanceReady = true;
    }

    if (closingSnap) {
      cachedClosings = sortByCreatedDesc(
        closingSnap.docs.map(d => ({ id: d.id, ...d.data() })).filter(isClosingDataRecord)
      );
    }

    if (bonusSnap) {
      if (bonusSnap.exists()) {
        const data = bonusSnap.data() || {};
        cachedBonusSettings = normalizeBonusSettings(data);
      } else {
        cachedBonusSettings = getDefaultBonusSettings();
      }
    }

    if (guideNoteSnap) {
      cachedHeaderGuideNote = guideNoteSnap.exists()
        ? { id: guideNoteSnap.id, note: DEFAULT_HEADER_GUIDE_NOTE, ...(guideNoteSnap.data() || {}) }
        : { id: HEADER_GUIDE_NOTE_DOC_ID, note: DEFAULT_HEADER_GUIDE_NOTE, updatedAtMs: 0, updatedBy: '', updatedByName: '' };
    }

    if (receiptTextSnap) {
      cachedReceiptTextSettings = receiptTextSnap.exists()
        ? normalizeReceiptTextSettings({ id: receiptTextSnap.id, ...(receiptTextSnap.data() || {}) })
        : normalizeReceiptTextSettings({ id: RECEIPT_TEXT_DOC_ID, ...DEFAULT_RECEIPT_TEXT_SETTINGS, updatedAtMs: 0, updatedBy: '', updatedByName: '' });
    }

    if (manualBonusSnap) {
      cachedManualBonuses = dedupeManualBonusRecords(
        manualBonusSnap.docs.map(d => ({ id: d.id, ...d.data() }))
      );
    }

    if (unlockRequestSnap) {
      cachedUnlockRequests = unlockRequestSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    }

    const [usersSnap, rismaSnap, auditSnap] = await Promise.all([
      getDocsFreshSafe('User', query(collection(db, 'users'), orderBy('name'))).then(countError),
      getDocFreshSafe('Closing manual Risma', doc(db, RISMA_MANUAL_CLOSING_COLLECTION, RISMA_MANUAL_CLOSING_DOC_ID)).then(countError),
      getDocsFreshSafe('Audit log', query(collection(db, 'audit_logs'), orderBy('createdAt', 'desc'), limit(AUDIT_SYNC_LIMIT))).then(countError)
    ]);
    if (usersSnap) cachedUsers = usersSnap.docs.map(d => ({ id: d.id, ...d.data() }));
    if (rismaSnap) {
      cachedRismaManualClosingConfig = rismaSnap.exists()
        ? { id: rismaSnap.id, enabled: true, allowedUsers: [], allowedNames: {}, ...(rismaSnap.data() || {}) }
        : { id: RISMA_MANUAL_CLOSING_DOC_ID, enabled: true, allowedUsers: [], allowedNames: {} };
    }
    if (auditSnap) cachedAuditLogs = sortByCreatedDesc(auditSnap.docs.map(d => ({ id: d.id, ...d.data() })));
    await serverApplyDailyTarget();

    applyNavRoleLabels();
    clearCashFisikCacheForRefresh();
    await refreshCurrentPage();
    if (!silent) {
      if (errorCount) showToast(`✓ Data direfresh sebagian (${errorCount} gagal, cache lama tetap aman)`, true);
      else showToast('✓ Data berhasil direfresh');
    }
    return { ok: errorCount === 0, errorCount };
  }

  async function manualRefreshData() {
    if (!currentUser) return;
    const now = Date.now();
    if (manualRefreshInFlight) return showToast('Refresh masih berjalan...');
    if (now - lastManualRefreshAt < 1200) return;
    manualRefreshInFlight = true;
    lastManualRefreshAt = now;
    setRefreshButtonLoading(true);
    setLoading(true);
    try {
      clearCashFisikCacheForRefresh();
      await refreshAllDataNow({ silent: false });
    } catch (e) {
      console.error('manualRefreshData gagal:', e);
      showToast('Gagal refresh data. Cek koneksi.', true);
    } finally {
      setLoading(false);
      setRefreshButtonLoading(false);
      manualRefreshInFlight = false;
    }
  }

  async function refreshTransactionsNow() {
    if (!currentUser) return;
    try {
      await refreshAllDataNow({ silent: true });
    } catch (e) {
      console.error('refreshTransactionsNow gagal:', e);
    }
  }

  window.addEventListener('online', () => { renderSettingsSummary(); if (currentUser) bindRealtimeData(); });
  window.addEventListener('offline', () => renderSettingsSummary());
  const FOREGROUND_REFRESH_MIN_MS = 60000;
  let lastForegroundRefreshAt = 0;
  async function refreshForegroundData() {
    if (!currentUser) return;
    const now = Date.now();
    if (now - lastForegroundRefreshAt < FOREGROUND_REFRESH_MIN_MS) {
      refreshCurrentPage();
      return;
    }
    lastForegroundRefreshAt = now;
    refreshCurrentPage();
    await refreshTransactionsNow();
  }

  document.addEventListener('visibilitychange', async () => {
    if (!document.hidden && currentUser) await refreshForegroundData();
  });
  window.addEventListener('focus', async () => {
    if (currentUser) await refreshForegroundData();
  });

  if (await restoreSession()) {
    let savedPage = 'home';
    try {
      const p = localStorage.getItem(PAGE_KEY);
      if (RESTORABLE_PAGES.includes(p)) savedPage = p;
    } catch (_) {}
    router.navigate(savedPage);
  } else router.navigate('login');
